import React, { createContext, useContext, useReducer, useEffect } from 'react';
import {
  initialPeople, initialCapabilities, initialBusinessUnits, initialProgrammes,
  initialMilestones, initialWeeklyUpdates, initialExecutiveSummary,
  initialOrgCharts, initialPartnerTimelines, initialCapexBudgets,
  initialBOMs, initialBudgets, initialCertifications, initialBDPipeline
} from '../data/mockData';

const STORAGE_KEY = 'programme_tracker_state';

const defaultState = {
  people: initialPeople,
  capabilities: initialCapabilities,
  businessUnits: initialBusinessUnits,
  programmes: initialProgrammes,
  milestones: initialMilestones,
  weeklyUpdates: initialWeeklyUpdates,
  executiveSummary: initialExecutiveSummary,
  orgCharts: initialOrgCharts,
  partnerTimelines: initialPartnerTimelines,
  capexBudgets: initialCapexBudgets,
  boms: initialBOMs,
  budgets: initialBudgets,
  certifications: initialCertifications,
  bdPipeline: initialBDPipeline,
  toasts: [],
};

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const loaded = JSON.parse(raw);
      // Merge with defaults to ensure all keys exist (handles schema upgrades)
      return { ...defaultState, ...loaded, toasts: [] };
    }
  } catch (e) { /* ignore */ }
  return null;
}

function saveState(state) {
  try {
    const { toasts, ...rest } = state;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rest));
  } catch (e) { /* ignore */ }
}

function reducer(state, action) {
  switch (action.type) {
    // ── Generic CRUD ──
    case 'SET_COLLECTION':
      return { ...state, [action.collection]: action.data };

    case 'ADD_TO_COLLECTION': {
      const col = state[action.collection];
      return { ...state, [action.collection]: Array.isArray(col) ? [...col, action.item] : col };
    }

    case 'UPDATE_IN_COLLECTION': {
      const col = state[action.collection];
      if (!Array.isArray(col)) return state;
      return {
        ...state,
        [action.collection]: col.map(x => x.id === action.item.id ? { ...x, ...action.item } : x)
      };
    }

    case 'DELETE_FROM_COLLECTION': {
      const col = state[action.collection];
      if (!Array.isArray(col)) return state;
      return { ...state, [action.collection]: col.filter(x => x.id !== action.id) };
    }

    // ── Nested data (keyed by programme ID) ──
    case 'SET_PROGRAMME_DATA': {
      const { collection, programmeId, data } = action;
      return {
        ...state,
        [collection]: { ...state[collection], [programmeId]: data }
      };
    }

    case 'ADD_TO_PROGRAMME_DATA': {
      const { collection, programmeId, item } = action;
      const existing = state[collection][programmeId] || [];
      return {
        ...state,
        [collection]: { ...state[collection], [programmeId]: [...existing, item] }
      };
    }

    case 'UPDATE_IN_PROGRAMME_DATA': {
      const { collection, programmeId, item } = action;
      const existing = state[collection][programmeId] || [];
      return {
        ...state,
        [collection]: {
          ...state[collection],
          [programmeId]: existing.map(x => x.id === item.id ? { ...x, ...item } : x)
        }
      };
    }

    case 'DELETE_FROM_PROGRAMME_DATA': {
      const { collection, programmeId, itemId } = action;
      const existing = state[collection][programmeId] || [];
      return {
        ...state,
        [collection]: {
          ...state[collection],
          [programmeId]: existing.filter(x => x.id !== itemId)
        }
      };
    }

    // ── Weekly Updates ──
    case 'SAVE_WEEKLY_UPDATE': {
      const { programmeId, weekKey, data } = action;
      return {
        ...state,
        weeklyUpdates: {
          ...state.weeklyUpdates,
          [programmeId]: {
            ...(state.weeklyUpdates[programmeId] || {}),
            [weekKey]: { ...data, weekLabel: weekKey, submittedAt: new Date().toISOString() }
          }
        }
      };
    }

    // ── Org Chart ──
    case 'SET_ORG_CHART':
      return {
        ...state,
        orgCharts: { ...state.orgCharts, [action.programmeId]: action.data }
      };

    // ── Toasts ──
    case 'ADD_TOAST':
      return { ...state, toasts: [...state.toasts, { id: Date.now(), ...action.toast }] };
    case 'REMOVE_TOAST':
      return { ...state, toasts: state.toasts.filter(t => t.id !== action.id) };

    // ── Reset ──
    case 'RESET_DATA':
      localStorage.removeItem(STORAGE_KEY);
      return { ...defaultState };

    default:
      return state;
  }
}

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, loadState() || defaultState);

  // Save to localStorage on every change (debounced conceptually via sync write)
  useEffect(() => {
    saveState(state);
  }, [state]);

  // Toast auto-remove
  useEffect(() => {
    if (state.toasts.length > 0) {
      const timer = setTimeout(() => {
        dispatch({ type: 'REMOVE_TOAST', id: state.toasts[0].id });
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [state.toasts]);

  const showToast = (message, type = 'success') => {
    dispatch({ type: 'ADD_TOAST', toast: { message, type } });
  };

  return (
    <AppContext.Provider value={{ state, dispatch, showToast }}>
      {children}
      {/* Toast Container */}
      {state.toasts.length > 0 && (
        <div className="toast-container">
          {state.toasts.map(t => (
            <div key={t.id} className={`toast toast-${t.type}`}>
              {t.type === 'success' && '✓'}
              {t.type === 'error' && '✗'}
              {t.type === 'info' && 'ℹ'}
              <span>{t.message}</span>
            </div>
          ))}
        </div>
      )}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be inside AppProvider');
  return ctx;
}
