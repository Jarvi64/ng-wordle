import React from 'react';
import { NavLink } from 'react-router-dom';
import { Icons } from '../svg/Icons';
import { useApp } from '../../context/AppContext';
import './Sidebar.css';

const mainNavItems = [
  { to: '/', icon: 'dashboard', label: 'Dashboard' },
  { to: '/ceo-review', icon: 'calendar', label: 'CEO Review' },
  { to: '/master-data', icon: 'hierarchy', label: 'Master Data' },
  { to: '/people', icon: 'people', label: 'People / POCs' },
];

const programmeNavItems = [
  { path: 'overview', icon: 'programme', label: 'Overview' },
  { path: 'milestones', icon: 'milestone', label: 'Key Milestones' },
  { path: 'weekly-status', icon: 'weekly', label: 'Weekly Status' },
  { path: 'executive-summary', icon: 'summary', label: 'Executive Summary' },
  { path: 'org-chart', icon: 'orgChart', label: 'Org Chart' },
  { path: 'partner-timeline', icon: 'partner', label: 'Partner Timeline' },
  { path: 'capex-budget', icon: 'budget', label: 'CAPEX Budget' },
  { path: 'bom', icon: 'bom', label: 'Programme BOM' },
  { path: 'budget', icon: 'budget', label: 'Programme Budget' },
  { path: 'certifications', icon: 'certificate', label: 'Certifications' },
  { path: 'bd-pipeline', icon: 'pipeline', label: 'BD Pipeline' },
];

export default function Sidebar({ collapsed, onToggle, activeProgrammeId }) {
  const { dispatch, showToast } = useApp();

  const handleReset = () => {
    if (window.confirm('Reset all data to defaults? This will clear all your changes.')) {
      dispatch({ type: 'RESET_DATA' });
      showToast('Data reset to defaults', 'info');
      window.location.reload();
    }
  };

  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-logo">
        <div className="sidebar-logo-icon">
          <Icons.target />
        </div>
        {!collapsed && (
          <div className="sidebar-logo-text">
            Programme<span>Tracker</span>
          </div>
        )}
      </div>

      <nav className="sidebar-nav">
        {!collapsed && <div className="sidebar-section-title">Main</div>}
        {mainNavItems.map(item => {
          const Icon = Icons[item.icon];
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            >
              <Icon />
              {!collapsed && <span className="sidebar-link-label">{item.label}</span>}
            </NavLink>
          );
        })}

        {activeProgrammeId && (
          <>
            {!collapsed && <div className="sidebar-section-title">Programme Sections</div>}
            {programmeNavItems.map(item => {
              const Icon = Icons[item.icon];
              return (
                <NavLink
                  key={item.path}
                  to={`/programmes/${activeProgrammeId}/${item.path}`}
                  className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
                >
                  <Icon />
                  {!collapsed && <span className="sidebar-link-label">{item.label}</span>}
                </NavLink>
              );
            })}
          </>
        )}
      </nav>

      <div className="sidebar-toggle" style={{ display: 'flex', gap: 4, justifyContent: 'center' }}>
        {!collapsed && (
          <button onClick={handleReset} title="Reset all data" style={{ color: 'var(--slate-400)' }}>
            <Icons.alert style={{ width: 16, height: 16 }} />
          </button>
        )}
        <button onClick={onToggle} title={collapsed ? 'Expand' : 'Collapse'}>
          <Icons.chevronRight style={collapsed ? {} : { transform: 'rotate(180deg)' }} />
        </button>
      </div>
    </aside>
  );
}
