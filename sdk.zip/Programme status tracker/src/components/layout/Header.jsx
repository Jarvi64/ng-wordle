import React from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { Icons } from '../svg/Icons';
import { useApp } from '../../context/AppContext';
import './Header.css';

export default function Header({ collapsed }) {
  const { state } = useApp();
  const location = useLocation();
  const params = useParams();

  // Build breadcrumbs
  const crumbs = [{ label: 'Home', to: '/' }];
  const path = location.pathname;

  if (path.startsWith('/master-data')) {
    crumbs.push({ label: 'Master Data' });
  } else if (path.startsWith('/people')) {
    crumbs.push({ label: 'People / POCs' });
  } else if (path.startsWith('/programmes') && params.id) {
    const prog = state.programmes.find(p => p.id === params.id);
    crumbs.push({ label: 'Programmes', to: '/' });
    if (prog) crumbs.push({ label: prog.name, to: `/programmes/${prog.id}/overview` });
    if (params.section) {
      const labels = {
        'overview': 'Overview',
        'milestones': 'Key Milestones',
        'weekly-status': 'Weekly Status',
        'executive-summary': 'Executive Summary',
        'org-chart': 'Org Chart',
        'partner-timeline': 'Partner Timeline',
        'capex-budget': 'CAPEX Budget',
        'bom': 'Programme BOM',
        'budget': 'Programme Budget',
        'certifications': 'Certifications',
        'bd-pipeline': 'BD Pipeline',
      };
      crumbs.push({ label: labels[params.section] || params.section });
    }
  }

  return (
    <header className={`app-header ${collapsed ? 'collapsed' : ''}`}>
      <div className="header-breadcrumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="separator">/</span>}
            {c.to && i < crumbs.length - 1 ? (
              <Link to={c.to}>{c.label}</Link>
            ) : (
              <span className={i === crumbs.length - 1 ? 'current' : ''}>{c.label}</span>
            )}
          </React.Fragment>
        ))}
      </div>

      <div className="header-actions">
        <div className="header-search">
          <Icons.search />
          <input type="text" placeholder="Search programmes..." />
        </div>
        <div className="header-avatar">VJ</div>
      </div>
    </header>
  );
}
