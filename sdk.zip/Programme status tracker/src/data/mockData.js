// Helper to generate IDs
let _counter = 100;
export const genId = () => `id_${Date.now()}_${_counter++}`;

// ═══════════════════════ People ═══════════════════════
export const initialPeople = [
  { id: 'p1', name: 'Rahul Sharma', email: 'rahul.sharma@company.com', role: 'Programme Director' },
  { id: 'p2', name: 'Priya Patel', email: 'priya.patel@company.com', role: 'Programme Manager' },
  { id: 'p3', name: 'Amit Kumar', email: 'amit.kumar@company.com', role: 'Senior Engineer' },
  { id: 'p4', name: 'Sneha Reddy', email: 'sneha.reddy@company.com', role: 'Supply Chain Lead' },
  { id: 'p5', name: 'Vikram Singh', email: 'vikram.singh@company.com', role: 'BD Head' },
  { id: 'p6', name: 'Anita Desai', email: 'anita.desai@company.com', role: 'Finance Controller' },
  { id: 'p7', name: 'Karan Mehta', email: 'karan.mehta@company.com', role: 'Quality Head' },
  { id: 'p8', name: 'Deepika Nair', email: 'deepika.nair@company.com', role: 'Operations Manager' },
  { id: 'p9', name: 'Rajesh Gupta', email: 'rajesh.gupta@company.com', role: 'Tech Lead' },
  { id: 'p10', name: 'Meera Joshi', email: 'meera.joshi@company.com', role: 'Procurement Head' },
];

// ═══════════════════════ Capabilities ═══════════════════════
export const initialCapabilities = [
  { id: 'cap1', name: 'Defence Systems', description: 'Advanced defence and security solutions' },
  { id: 'cap2', name: 'Aerospace', description: 'Aircraft and space technology programmes' },
  { id: 'cap3', name: 'Energy Solutions', description: 'Renewable and conventional energy systems' },
  { id: 'cap4', name: 'Digital & Electronics', description: 'Electronics, software and digital platforms' },
];

// ═══════════════════════ Business Units ═══════════════════════
export const initialBusinessUnits = [
  { id: 'bu1', name: 'Land Systems', capabilityId: 'cap1' },
  { id: 'bu2', name: 'Naval Systems', capabilityId: 'cap1' },
  { id: 'bu3', name: 'Missile & Weapon Systems', capabilityId: 'cap1' },
  { id: 'bu4', name: 'Fighter Aircraft', capabilityId: 'cap2' },
  { id: 'bu5', name: 'Helicopters', capabilityId: 'cap2' },
  { id: 'bu6', name: 'Space Systems', capabilityId: 'cap2' },
  { id: 'bu7', name: 'Solar Energy', capabilityId: 'cap3' },
  { id: 'bu8', name: 'Wind Energy', capabilityId: 'cap3' },
  { id: 'bu9', name: 'Radar & Sensors', capabilityId: 'cap4' },
  { id: 'bu10', name: 'Communication Systems', capabilityId: 'cap4' },
];

// ═══════════════════════ Programmes ═══════════════════════
export const initialProgrammes = [
  {
    id: 'prog1', name: 'Main Battle Tank - Mk II', businessUnitId: 'bu1',
    overview: 'Next-generation main battle tank with advanced armour, fire control and mobility systems. Designed for desert & plains warfare with NBC protection.',
    poc1Id: 'p1', poc2Id: 'p2', startDate: '2024-04-01', targetEndDate: '2027-03-31',
    status: 'active'
  },
  {
    id: 'prog2', name: 'Infantry Combat Vehicle', businessUnitId: 'bu1',
    overview: 'Amphibious ICV with anti-tank missile integration, modular armour kit and 30mm auto-cannon turret.',
    poc1Id: 'p3', poc2Id: 'p1', startDate: '2024-06-15', targetEndDate: '2027-12-31',
    status: 'active'
  },
  {
    id: 'prog3', name: 'Stealth Frigate - Project 18', businessUnitId: 'bu2',
    overview: 'Multi-role stealth frigate with integrated combat management system, VLS and advanced sonar suite.',
    poc1Id: 'p2', poc2Id: 'p4', startDate: '2023-01-10', targetEndDate: '2028-06-30',
    status: 'active'
  },
  {
    id: 'prog4', name: 'Cruise Missile System', businessUnitId: 'bu3',
    overview: 'Subsonic cruise missile with terrain-hugging capability, 1000km range and multi-platform launch compatibility.',
    poc1Id: 'p5', poc2Id: 'p9', startDate: '2024-01-01', targetEndDate: '2026-12-31',
    status: 'active'
  },
  {
    id: 'prog5', name: 'Advanced Medium Combat Aircraft', businessUnitId: 'bu4',
    overview: '5th gen single-engine stealth fighter with AESA radar, internal weapons bay and supercruise capability.',
    poc1Id: 'p1', poc2Id: 'p3', startDate: '2023-08-01', targetEndDate: '2030-12-31',
    status: 'active'
  },
  {
    id: 'prog6', name: 'Light Utility Helicopter', businessUnitId: 'bu5',
    overview: 'Multi-role light helicopter for reconnaissance, SAR, and troop transport with glass cockpit.',
    poc1Id: 'p8', poc2Id: 'p2', startDate: '2024-03-01', targetEndDate: '2027-06-30',
    status: 'active'
  },
  {
    id: 'prog7', name: 'Communication Satellite - GSAT-X', businessUnitId: 'bu6',
    overview: 'High-throughput geostationary communication satellite with Ka-band and optical inter-satellite links.',
    poc1Id: 'p9', poc2Id: 'p6', startDate: '2024-02-01', targetEndDate: '2026-09-30',
    status: 'active'
  },
  {
    id: 'prog8', name: 'Solar Giga Factory', businessUnitId: 'bu7',
    overview: '5GW integrated solar cell and module manufacturing facility with TOPCon and HJT technology lines.',
    poc1Id: 'p4', poc2Id: 'p10', startDate: '2024-07-01', targetEndDate: '2026-12-31',
    status: 'active'
  },
  {
    id: 'prog9', name: 'Offshore Wind Platform', businessUnitId: 'bu8',
    overview: '500MW offshore wind farm with floating platform technology, 15MW turbines and subsea cabling.',
    poc1Id: 'p6', poc2Id: 'p4', startDate: '2025-01-01', targetEndDate: '2028-12-31',
    status: 'planning'
  },
  {
    id: 'prog10', name: 'AESA Radar Suite', businessUnitId: 'bu9',
    overview: 'Multi-function AESA radar with simultaneous air-to-air tracking, ground mapping and electronic warfare modes.',
    poc1Id: 'p9', poc2Id: 'p7', startDate: '2024-05-01', targetEndDate: '2027-03-31',
    status: 'active'
  },
  {
    id: 'prog11', name: 'Software Defined Radio', businessUnitId: 'bu10',
    overview: 'Tactical SDR platform supporting multiple waveforms, MANET mesh networking and Link-16 compatibility.',
    poc1Id: 'p3', poc2Id: 'p8', startDate: '2024-09-01', targetEndDate: '2026-06-30',
    status: 'active'
  },
  {
    id: 'prog12', name: 'Anti-Ship Missile', businessUnitId: 'bu3',
    overview: 'Supersonic sea-skimming anti-ship missile with dual-mode seeker and 300km range.',
    poc1Id: 'p5', poc2Id: 'p1', startDate: '2023-11-01', targetEndDate: '2026-11-30',
    status: 'active'
  },
];

// ═══════════════════════ Key Milestones ═══════════════════════
export const initialMilestones = {
  prog1: [
    { id: 'ms1', milestone: 'Concept Design Review', startDate: '2024-04-01', endDate: '2024-06-30', responsibility: 'p1', remarks: 'Completed' },
    { id: 'ms2', milestone: 'Hull Prototype Fabrication', startDate: '2024-07-01', endDate: '2025-01-31', responsibility: 'p3', remarks: 'In progress' },
    { id: 'ms3', milestone: 'Fire Control Integration', startDate: '2025-02-01', endDate: '2025-09-30', responsibility: 'p9', remarks: 'Upcoming' },
    { id: 'ms4', milestone: 'Field Trials Phase 1', startDate: '2025-10-01', endDate: '2026-06-30', responsibility: 'p1', remarks: '' },
  ],
  prog5: [
    { id: 'ms5', milestone: 'Preliminary Design Review', startDate: '2023-08-01', endDate: '2024-03-31', responsibility: 'p1', remarks: 'Completed' },
    { id: 'ms6', milestone: 'Wind Tunnel Testing', startDate: '2024-04-01', endDate: '2024-12-31', responsibility: 'p3', remarks: 'Completed' },
    { id: 'ms7', milestone: 'Prototype Rollout', startDate: '2025-01-01', endDate: '2026-06-30', responsibility: 'p1', remarks: 'In progress' },
  ],
};

// ═══════════════════════ Weekly Status Updates ═══════════════════════
export const initialWeeklyUpdates = {
  prog1: {
    '2026-W12': {
      weekLabel: '2026-W12',
      submittedAt: '2026-03-20T09:15:00',
      categories: {
        organization: {
          positive: ['Cross-functional review completed'],
          challenges: ['2 senior engineers on extended leave', 'Hiring pipeline slow for structural analysts']
        },
        infraSupplyChain: {
          positive: ['Steel alloy shipment received on time'],
          challenges: ['Composite armour supplier delayed by 2 weeks', 'Warehouse space at 95% capacity']
        },
        partnerSupport: {
          positive: [],
          challenges: ['Foreign tech partner visa approvals pending', 'OFB production schedule uncertain']
        },
        assemblyIntegration: {
          positive: ['Hull welding 70% complete'],
          challenges: ['Turret ring alignment tolerance issue identified']
        },
        techAutomation: {
          positive: ['Digital twin simulation validated'],
          challenges: ['SCADA integration delayed due to protocol mismatch']
        },
        processOM: {
          positive: [],
          challenges: ['Training facility construction delayed by 2 weeks', 'SOP drafting behind schedule']
        },
        contractsCommercials: {
          positive: ['Phase 2 funding proposal submitted'],
          challenges: ['Vendor price escalation clause under negotiation']
        },
        workingCapitalCashflow: {
          positive: ['Q4 cash flow positive'],
          challenges: ['Payment to titanium supplier overdue by 10 days']
        }
      }
    },
    '2026-W13': {
      weekLabel: '2026-W13',
      submittedAt: '2026-03-27T10:30:00',
      categories: {
        organization: {
          positive: ['New team lead onboarded for turret sub-system', 'Cross-functional review completed'],
          challenges: ['2 senior engineers on extended leave', 'Need additional structural analysts']
        },
        infraSupplyChain: {
          positive: ['Steel alloy shipment received on time', 'New CNC machine commissioned'],
          challenges: ['Composite armour supplier delayed by 3 weeks']
        },
        partnerSupport: {
          positive: ['MoU signed with OFB for gun barrel supply'],
          challenges: ['Foreign tech partner visa approvals pending']
        },
        assemblyIntegration: {
          positive: ['Hull welding 80% complete'],
          challenges: ['Turret ring alignment tolerance issue identified']
        },
        techAutomation: {
          positive: ['Digital twin simulation validated', 'Automated weld inspection system tested'],
          challenges: ['SCADA integration delayed due to protocol mismatch']
        },
        processOM: {
          positive: ['Maintenance SOP draft completed'],
          challenges: ['Training facility construction delayed by 2 weeks']
        },
        contractsCommercials: {
          positive: ['Phase 2 funding sanctioned'],
          challenges: ['Vendor price escalation clause under negotiation']
        },
        workingCapitalCashflow: {
          positive: ['Q4 cash flow positive', 'Advance received for prototype delivery'],
          challenges: ['Payment to titanium supplier overdue by 15 days']
        }
      }
    }
  }
};

// ═══════════════════════ Executive Summary ═══════════════════════
export const initialExecutiveSummary = {
  prog1: [
    { id: 'es1', issueSummary: 'Composite armour supplier delay impacting hull completion', ownerName: 'p4', deadline: '2026-04-15', status: 'In Progress' },
    { id: 'es2', issueSummary: 'DRDO approval pending for reactive armour specs', ownerName: 'p1', deadline: '2026-04-30', status: 'Open' },
    { id: 'es3', issueSummary: 'Foreign collaboration clearance from MoD', ownerName: 'p5', deadline: '2026-03-31', status: 'Open' },
  ],
};

// ═══════════════════════ Org Chart ═══════════════════════
export const initialOrgCharts = {
  prog1: {
    id: 'org1', name: 'Rahul Sharma', title: 'Programme Director',
    children: [
      {
        id: 'org2', name: 'Amit Kumar', title: 'Lead - Hull & Structures',
        children: [
          { id: 'org3', name: 'Sanjay Rao', title: 'Sr. Engineer - Welding', children: [] },
          { id: 'org4', name: 'Ritu Verma', title: 'Sr. Engineer - Design', children: [] },
        ]
      },
      {
        id: 'org5', name: 'Priya Patel', title: 'Lead - Integration',
        children: [
          { id: 'org6', name: 'Arjun Das', title: 'Engineer - Electronics', children: [] },
        ]
      },
      {
        id: 'org7', name: 'Deepika Nair', title: 'Operations Manager',
        children: []
      }
    ]
  }
};

// ═══════════════════════ Partner Timeline ═══════════════════════
export const initialPartnerTimelines = {
  prog1: [
    { id: 'pt1', partnerName: 'OFB Kanpur', milestone: 'Gun barrel delivery', startDate: '2025-01-01', endDate: '2025-08-31', owner: 'p4' },
    { id: 'pt2', partnerName: 'CVRDE', milestone: 'Transmission system testing', startDate: '2025-03-01', endDate: '2025-12-31', owner: 'p3' },
    { id: 'pt3', partnerName: 'BEL', milestone: 'Fire control system integration', startDate: '2025-06-01', endDate: '2026-03-31', owner: 'p9' },
  ],
};

// ═══════════════════════ CAPEX Budget ═══════════════════════
export const initialCapexBudgets = {
  prog1: [
    { id: 'cx1', capexItem: 'CNC Machining Center', budget: 12.5, actual: 11.8, dateOfCommissioning: '2025-03-31', owner: 'p4' },
    { id: 'cx2', capexItem: 'Welding Robot Cell', budget: 8.0, actual: 7.5, dateOfCommissioning: '2025-06-30', owner: 'p3' },
    { id: 'cx3', capexItem: 'Test Range Equipment', budget: 25.0, actual: 0, dateOfCommissioning: '2026-01-31', owner: 'p1' },
    { id: 'cx4', capexItem: 'Environmental Test Chamber', budget: 5.5, actual: 5.2, dateOfCommissioning: '2025-02-28', owner: 'p7' },
  ],
};

// ═══════════════════════ Programme BOM ═══════════════════════
export const initialBOMs = {
  prog1: [
    { id: 'bom1', bomItem: 'Hull Armour Plates', supplier: 'SAIL', budgetCost: 18.0, targetCost: 16.5, dateOfOrder: '2024-08-01', dateOfDelivery: '2025-02-28', leadTime: '7 months', owner: 'p4' },
    { id: 'bom2', bomItem: 'Engine Assembly', supplier: 'CVRDE', budgetCost: 45.0, targetCost: 42.0, dateOfOrder: '2024-10-01', dateOfDelivery: '2025-09-30', leadTime: '12 months', owner: 'p3' },
    { id: 'bom3', bomItem: 'Fire Control Computer', supplier: 'BEL', budgetCost: 8.5, targetCost: 8.0, dateOfOrder: '2025-01-01', dateOfDelivery: '2025-12-31', leadTime: '12 months', owner: 'p9' },
  ],
};

// ═══════════════════════ Programme Budget ═══════════════════════
export const initialBudgets = {
  prog1: [
    { id: 'pb1', item: 'Design & Engineering', supplier: 'In-house', unitCost: 35.0, targetCost: 32.0, deadline: '2026-03-31', owner: 'p1' },
    { id: 'pb2', item: 'Prototype Manufacturing', supplier: 'OFB/CVRDE', unitCost: 120.0, targetCost: 110.0, deadline: '2026-12-31', owner: 'p3' },
    { id: 'pb3', item: 'Testing & Certification', supplier: 'DRDO Labs', unitCost: 25.0, targetCost: 22.0, deadline: '2027-03-31', owner: 'p7' },
    { id: 'pb4', item: 'Project Management', supplier: 'In-house', unitCost: 15.0, targetCost: 14.0, deadline: '2027-03-31', owner: 'p2' },
  ],
};

// ═══════════════════════ Certifications ═══════════════════════
export const initialCertifications = {
  prog1: [
    { id: 'cert1', certification: 'NBC Protection Compliance', status: 'Pending', owner: 'p7' },
    { id: 'cert2', certification: 'Ballistic Test Certification', status: 'Pending', owner: 'p1' },
    { id: 'cert3', certification: 'EMI/EMC Compliance', status: 'Obtained', owner: 'p9' },
    { id: 'cert4', certification: 'Environmental Clearance', status: 'Obtained', owner: 'p8' },
  ],
};

// ═══════════════════════ BD Pipeline ═══════════════════════
export const initialBDPipeline = {
  prog1: [
    { id: 'bd1', project: 'Army Order — 500 units', currentStatus: 'RFP Submitted', nextSteps: 'Technical evaluation', timeline: '2026-Q2', owner: 'p5' },
    { id: 'bd2', project: 'Export — Friendly Nation A', currentStatus: 'Initial discussions', nextSteps: 'Submit capability brief', timeline: '2026-Q3', owner: 'p5' },
    { id: 'bd3', project: 'Border Security Force variant', currentStatus: 'Requirements analysis', nextSteps: 'Design variant study', timeline: '2026-Q4', owner: 'p1' },
  ],
};

// ═══════════════════════ Week Categories ═══════════════════════
export const WEEKLY_CATEGORIES = [
  { key: 'organization', label: 'Organization', icon: 'people', color: '#6366F1' },
  { key: 'infraSupplyChain', label: 'Infra / Supply Chain Readiness', icon: 'building', color: '#8B5CF6' },
  { key: 'partnerSupport', label: 'Partner Support', icon: 'partner', color: '#EC4899' },
  { key: 'assemblyIntegration', label: 'Assembly & Integration Readiness', icon: 'bom', color: '#F59E0B' },
  { key: 'techAutomation', label: 'Tech / Automation Readiness', icon: 'target', color: '#10B981' },
  { key: 'processOM', label: 'Process / O&M Readiness', icon: 'milestone', color: '#3B82F6' },
  { key: 'contractsCommercials', label: 'Contracts & Commercials', icon: 'summary', color: '#EF4444' },
  { key: 'workingCapitalCashflow', label: 'Working Capital & Cash Flow', icon: 'budget', color: '#14B8A6' },
];

// ═══════════════════════ Status Options ═══════════════════════
export const STATUS_OPTIONS = ['Open', 'In Progress', 'Changed', 'Closed'];
export const CERT_STATUSES = ['Pending', 'Obtained', 'In Progress'];
