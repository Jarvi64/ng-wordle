export const genId = () => `id_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

export const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const formatCurrency = (val) => {
  if (val === null || val === undefined || val === '') return '—';
  return `₹ ${Number(val).toFixed(2)} Cr`;
};

export const getStatusColor = (status) => {
  const map = {
    'Open': 'badge-danger',
    'In Progress': 'badge-info',
    'Changed': 'badge-warning',
    'Closed': 'badge-success',
    'Pending': 'badge-warning',
    'Obtained': 'badge-success',
    'active': 'badge-success',
    'planning': 'badge-info',
    'on-hold': 'badge-warning',
    'completed': 'badge-neutral',
  };
  return map[status] || 'badge-neutral';
};

export const getCurrentWeek = () => {
  const now = new Date();
  const oneJan = new Date(now.getFullYear(), 0, 1);
  const days = Math.floor((now - oneJan) / 86400000);
  const weekNum = Math.ceil((days + oneJan.getDay() + 1) / 7);
  return `${now.getFullYear()}-W${String(weekNum).padStart(2, '0')}`;
};

export const getWeekLabel = (weekStr) => {
  if (!weekStr) return '';
  const [year, wPart] = weekStr.split('-W');
  return `Week ${parseInt(wPart)}, ${year}`;
};

export const getPersonName = (people, personId) => {
  const p = people.find(x => x.id === personId);
  return p ? p.name : '—';
};

export const getInitials = (name) => {
  if (!name) return '?';
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
};

export const debounce = (fn, ms = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
};
