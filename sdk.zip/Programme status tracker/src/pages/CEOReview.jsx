import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/svg/Icons';
import { formatCurrency } from '../utils/helpers';
import './CEOReview.css';

// Helper to calculate months between two dates
const getMonthsDiff = (start, end) => {
  return (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth()) + 1;
};

const getMonthOffset = (baseStart, targetDate) => {
  return (targetDate.getFullYear() - baseStart.getFullYear()) * 12 + (targetDate.getMonth() - baseStart.getMonth());
};

export default function CEOReview() {
  const { state } = useApp();
  const navigate = useNavigate();
  const [filterCap, setFilterCap] = useState('All');

  // Gather programs
  const programmes = useMemo(() => {
    let progs = state.programmes.filter(p => !['completed', 'on-hold'].includes(p.status));
    if (filterCap !== 'All') {
      const buIds = state.businessUnits.filter(b => b.capabilityId === filterCap).map(b => b.id);
      progs = progs.filter(p => buIds.includes(p.businessUnitId));
    }
    // Filter programs without start/end dates for timeline display
    return progs.filter(p => p.startDate && p.targetEndDate);
  }, [state.programmes, state.businessUnits, filterCap]);

  // Determine global timeline span
  const { minDate, maxDate, timelineMonths } = useMemo(() => {
    if (programmes.length === 0) return { minDate: new Date(), maxDate: new Date(), timelineMonths: [] };
    
    let min = new Date(programmes[0].startDate);
    let max = new Date(programmes[0].targetEndDate);

    programmes.forEach(p => {
      const d1 = new Date(p.startDate);
      const d2 = new Date(p.targetEndDate);
      if (d1 < min) min = d1;
      if (d2 > max) max = d2;
    });

    // Expand view slightly
    min.setMonth(min.getMonth() - 1);
    max.setMonth(max.getMonth() + 2);

    const totalMonths = getMonthsDiff(min, max);
    const months = [];
    for (let i = 0; i < totalMonths; i++) {
      const d = new Date(min.getFullYear(), min.getMonth() + i, 1);
      months.push({
        label: d.toLocaleString('default', { month: 'short' }) + " '" + d.getFullYear().toString().slice(2),
        date: d,
        isYearStart: d.getMonth() === 0
      });
    }

    return { minDate: min, maxDate: max, timelineMonths: months };
  }, [programmes]);

  // Total investment
  const totalCapex = state.programmes.reduce((sum, p) => {
    const pCapex = state.capexBudgets[p.id] || [];
    return sum + pCapex.reduce((s, cx) => s + (parseFloat(cx.budget) || 0), 0);
  }, 0);

  return (
    <div className="page-content ceo-review-page">
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 className="page-title">CEO Review Dashboard</h1>
          <p className="page-subtitle">Master timeline and health overview of all strategic capabilities.</p>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <select className="form-select" style={{ width: 220, background: 'var(--bg-primary)' }} value={filterCap} onChange={e => setFilterCap(e.target.value)}>
            <option value="All">All Capabilities</option>
            {state.capabilities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      </div>

      {programmes.length === 0 ? (
        <div className="empty-state card">
          <Icons.milestone style={{ width: 60, height: 60 }} />
          <h3>No timeline data</h3>
          <p>Active programmes with Start and Target End dates will appear here.</p>
        </div>
      ) : (
        <div className="card animate-fadeIn" style={{ overflow: 'hidden' }}>
          <div className="card-header" style={{ background: 'var(--slate-50)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icons.calendar style={{ width: 20, height: 20, color: 'var(--slate-500)' }} />
              <h3 className="card-title">Programme Execution Timeline</h3>
            </div>
            <div className="timeline-legend">
              <span className="legend-item"><span className="legend-color" style={{ background: 'var(--success-500)' }}></span> Active & Healthy</span>
              <span className="legend-item"><span className="legend-color" style={{ background: 'var(--warning-500)' }}></span> Needs Attention</span>
              <span className="legend-item"><span className="legend-color" style={{ background: 'var(--primary-300)' }}></span> Planning</span>
            </div>
          </div>
          <div className="timeline-container">
            <div className="timeline-grid" style={{ '--col-count': timelineMonths.length }}>
              
              {/* Header Row */}
              <div className="timeline-row timeline-header">
                <div className="timeline-label-col">Programme / Capability</div>
                <div className="timeline-months-wrap">
                  {timelineMonths.map((m, i) => (
                    <div key={i} className={`timeline-month-header ${m.isYearStart ? 'year-start' : ''}`}>
                      {m.isYearStart && <div className="year-label">{m.date.getFullYear()}</div>}
                      <div className="month-label">{m.date.toLocaleString('default', { month: 'short' })}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Data Rows */}
              {programmes.map(prog => {
                const bu = state.businessUnits.find(b => b.id === prog.businessUnitId);
                const cap = bu ? state.capabilities.find(c => c.id === bu.capabilityId) : null;
                const pStart = new Date(prog.startDate);
                const pEnd = new Date(prog.targetEndDate);
                
                // Calculate grid positions
                const startOff = getMonthOffset(minDate, pStart);
                const span = getMonthsDiff(pStart, pEnd);
                
                // Determine health logic based on latest weekly updates (mock logic: if there are challenges, orange it)
                const updates = state.weeklyUpdates[prog.id] || {};
                const latestWeek = Object.keys(updates).sort().reverse()[0];
                let hasChallenges = false;
                if (latestWeek) {
                  const ws = updates[latestWeek].categories;
                  hasChallenges = Object.values(ws).some(cat => cat.challenges.length > 0);
                }
                
                let barClass = 'bar-active';
                if (prog.status === 'planning') barClass = 'bar-planning';
                else if (hasChallenges) barClass = 'bar-attention';

                return (
                  <div key={prog.id} className="timeline-row" onClick={() => navigate(`/programmes/${prog.id}`)}>
                    <div className="timeline-label-col">
                      <div className="prog-name">{prog.name}</div>
                      <div className="prog-meta">{cap?.name || 'Unknown'} • {bu?.name || 'Unknown'}</div>
                    </div>
                    <div className="timeline-months-wrap grid-bg">
                      {timelineMonths.map((_, i) => <div key={i} className="grid-line"></div>)}
                      
                      {/* The Bar */}
                      <div 
                        className={`timeline-bar ${barClass}`} 
                        style={{ 
                          left: `calc((100% / ${timelineMonths.length}) * ${startOff})`,
                          width: `calc((100% / ${timelineMonths.length}) * ${span})`
                        }}
                      >
                        <span className="bar-text">{pStart.toLocaleString('default', { month: 'short' })} '{pStart.getFullYear().toString().slice(2)} — {pEnd.toLocaleString('default', { month: 'short' })} '{pEnd.getFullYear().toString().slice(2)}</span>
                      </div>
                      
                      {/* Milestones overlay */}
                      {state.milestones[prog.id] && state.milestones[prog.id].map(ms => {
                        const msDate = new Date(ms.endDate);
                        if (msDate >= minDate && msDate <= maxDate) {
                          const msOff = getMonthOffset(minDate, msDate);
                          return (
                            <div 
                              key={ms.id} 
                              className={`ms-marker ${ms.remarks === 'Completed' ? 'completed' : ''}`}
                              style={{ left: `calc((100% / ${timelineMonths.length}) * ${msOff + 0.5})` }}
                              title={`${ms.milestone} (${ms.endDate})`}
                            ></div>
                          );
                        }
                        return null;
                      })}
                    </div>
                  </div>
                );
              })}

            </div>
          </div>
        </div>
      )}

      {/* Highlights */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 24, marginTop: 24 }}>
        <div className="card animate-slideUp" style={{ animationDelay: '100ms' }}>
          <div className="card-body">
            <div style={{ color: 'var(--slate-500)', fontSize: 'var(--text-sm)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 8 }}>Active Portfolio</div>
            <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 800, color: 'var(--slate-800)' }}>{programmes.length} Programmes</div>
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--slate-500)', marginTop: 4 }}>Across {state.capabilities.length} capabilities</div>
          </div>
        </div>
        <div className="card animate-slideUp" style={{ animationDelay: '200ms' }}>
          <div className="card-body">
            <div style={{ color: 'var(--slate-500)', fontSize: 'var(--text-sm)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 8 }}>Total CAPEX Outlay</div>
            <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 800, color: 'var(--primary-600)' }}>{formatCurrency(totalCapex)}</div>
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--slate-500)', marginTop: 4 }}>Sanctioned budget tracker</div>
          </div>
        </div>
        <div className="card animate-slideUp" style={{ animationDelay: '300ms', cursor: 'pointer', background: 'var(--primary-50)' }} onClick={() => navigate('/master-data')}>
          <div className="card-body" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ color: 'var(--primary-600)', fontSize: 'var(--text-sm)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 8 }}>Configuration</div>
              <div style={{ fontSize: 'var(--text-lg)', fontWeight: 700, color: 'var(--primary-900)' }}>Manage Organizations</div>
            </div>
            <div style={{ background: 'var(--primary-100)', padding: 12, borderRadius: '50%', color: 'var(--primary-600)' }}>
              <Icons.hierarchy style={{ width: 24, height: 24 }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
