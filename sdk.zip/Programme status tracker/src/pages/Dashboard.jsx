import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/svg/Icons';
import { getPersonName, getStatusColor } from '../utils/helpers';
import './Dashboard.css';

export default function Dashboard() {
  const { state } = useApp();
  const navigate = useNavigate();
  const { programmes, capabilities, businessUnits, people, weeklyUpdates } = state;

  const activeProgrammes = programmes.filter(p => p.status === 'active');
  const totalWeeklySubmissions = Object.values(weeklyUpdates).reduce((acc, weeks) => acc + Object.keys(weeks).length, 0);
  const programmesWithUpdates = Object.keys(weeklyUpdates).length;

  const stats = [
    { label: 'Total Programmes', value: programmes.length, icon: 'programme', color: 'var(--primary-500)', bg: 'var(--primary-50)' },
    { label: 'Active Programmes', value: activeProgrammes.length, icon: 'target', color: 'var(--success-500)', bg: 'var(--success-50)' },
    { label: 'Capabilities', value: capabilities.length, icon: 'folder', color: 'var(--warning-500)', bg: 'var(--warning-50)' },
    { label: 'Weekly Updates', value: totalWeeklySubmissions, icon: 'weekly', color: 'var(--info-500)', bg: 'var(--info-50)' },
  ];

  const getCapabilityName = (progId) => {
    const prog = programmes.find(p => p.id === progId);
    if (!prog) return '';
    const bu = businessUnits.find(b => b.id === prog.businessUnitId);
    if (!bu) return '';
    const cap = capabilities.find(c => c.id === bu.capabilityId);
    return cap ? cap.name : '';
  };

  const getBUName = (progId) => {
    const prog = programmes.find(p => p.id === progId);
    if (!prog) return '';
    const bu = businessUnits.find(b => b.id === prog.businessUnitId);
    return bu ? bu.name : '';
  };

  // Group programmes by capability
  const progByCap = {};
  capabilities.forEach(cap => {
    const capBUs = businessUnits.filter(bu => bu.capabilityId === cap.id);
    const capProgs = programmes.filter(p => capBUs.some(bu => bu.id === p.businessUnitId));
    if (capProgs.length > 0) {
      progByCap[cap.id] = { cap, programmes: capProgs };
    }
  });

  return (
    <div className="page-content">
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Programme status overview for leadership</p>
      </div>

      {/* Stats */}
      <div className="stats-grid stagger-children">
        {stats.map((s, i) => {
          const Icon = Icons[s.icon];
          return (
            <div key={i} className="stat-card card">
              <div className="stat-icon" style={{ background: s.bg, color: s.color }}>
                <Icon />
              </div>
              <div className="stat-info">
                <div className="stat-value">{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Programme Cards by Capability */}
      {Object.values(progByCap).map(({ cap, programmes: progs }) => (
        <div key={cap.id} className="dashboard-section animate-slideUp">
          <div className="section-header">
            <div className="section-header-left">
              <Icons.folder style={{ width: 18, height: 18, color: 'var(--primary-500)' }} />
              <h2 className="section-title">{cap.name}</h2>
            </div>
            <span className="badge badge-neutral">{progs.length} programme{progs.length !== 1 ? 's' : ''}</span>
          </div>
          <div className="programme-grid">
            {progs.map(prog => {
              const bu = businessUnits.find(b => b.id === prog.businessUnitId);
              const poc1 = people.find(p => p.id === prog.poc1Id);
              const hasUpdates = weeklyUpdates[prog.id] && Object.keys(weeklyUpdates[prog.id]).length > 0;
              return (
                <div
                  key={prog.id}
                  className="programme-card card"
                  onClick={() => navigate(`/programmes/${prog.id}/overview`)}
                >
                  <div className="programme-card-top">
                    <span className={`badge ${getStatusColor(prog.status)}`}>{prog.status}</span>
                    {hasUpdates && (
                      <span className="badge badge-info" style={{ fontSize: '9px' }}>
                        {Object.keys(weeklyUpdates[prog.id]).length} updates
                      </span>
                    )}
                  </div>
                  <h3 className="programme-card-name">{prog.name}</h3>
                  <p className="programme-card-bu">{bu?.name || '—'}</p>
                  <div className="programme-card-footer">
                    <div className="programme-card-poc">
                      <div className="mini-avatar">{poc1 ? poc1.name.split(' ').map(w => w[0]).join('') : '?'}</div>
                      <span>{poc1?.name || 'Unassigned'}</span>
                    </div>
                    <Icons.chevronRight style={{ width: 16, height: 16, color: 'var(--slate-400)' }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
