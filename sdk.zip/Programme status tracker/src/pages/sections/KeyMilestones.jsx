import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { genId, formatDate, getPersonName } from '../../utils/helpers';

export default function KeyMilestones() {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const milestones = state.milestones[programme.id] || [];
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});

  const handleAdd = () => {
    const newItem = { id: genId(), milestone: '', startDate: '', endDate: '', responsibility: '', remarks: '' };
    dispatch({ type: 'ADD_TO_PROGRAMME_DATA', collection: 'milestones', programmeId: programme.id, item: newItem });
    setEditing(newItem.id);
    setForm(newItem);
  };

  const handleSave = () => {
    dispatch({ type: 'UPDATE_IN_PROGRAMME_DATA', collection: 'milestones', programmeId: programme.id, item: form });
    showToast('Milestone saved');
    setEditing(null);
  };

  const handleDelete = (itemId) => {
    dispatch({ type: 'DELETE_FROM_PROGRAMME_DATA', collection: 'milestones', programmeId: programme.id, itemId });
    showToast('Milestone removed', 'info');
  };

  return (
    <div className="section-card animate-slideUp">
      <div className="section-card-header">
        <h3>Key Milestones</h3>
        <button className="btn btn-primary btn-sm" onClick={handleAdd}>
          <Icons.plus style={{ width: 14, height: 14 }} /> Add Milestone
        </button>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Milestone</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Responsibility</th>
              <th>Remarks</th>
              <th style={{ width: 100 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {milestones.length === 0 && (
              <tr><td colSpan={6} style={{ textAlign: 'center', padding: 40, color: 'var(--slate-400)' }}>No milestones yet. Click "Add Milestone" to get started.</td></tr>
            )}
            {milestones.map(ms => (
              <tr key={ms.id}>
                {editing === ms.id ? (
                  <>
                    <td><input className="form-input" value={form.milestone} onChange={e => setForm({ ...form, milestone: e.target.value })} /></td>
                    <td><input className="form-input" type="date" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })} /></td>
                    <td><input className="form-input" type="date" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })} /></td>
                    <td>
                      <select className="form-select" value={form.responsibility} onChange={e => setForm({ ...form, responsibility: e.target.value })}>
                        <option value="">Select...</option>
                        {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </td>
                    <td><input className="form-input" value={form.remarks} onChange={e => setForm({ ...form, remarks: e.target.value })} /></td>
                    <td>
                      <div className="action-btns">
                        <button className="btn btn-success btn-icon btn-sm" onClick={handleSave}><Icons.check style={{ width: 14, height: 14 }} /></button>
                        <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setEditing(null)}><Icons.close style={{ width: 14, height: 14 }} /></button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    <td><strong>{ms.milestone || '—'}</strong></td>
                    <td>{formatDate(ms.startDate)}</td>
                    <td>{formatDate(ms.endDate)}</td>
                    <td>{getPersonName(state.people, ms.responsibility)}</td>
                    <td>{ms.remarks || '—'}</td>
                    <td>
                      <div className="action-btns">
                        <button className="btn btn-ghost btn-icon btn-sm" onClick={() => { setForm({ ...ms }); setEditing(ms.id); }}><Icons.edit style={{ width: 14, height: 14 }} /></button>
                        <button className="btn btn-danger btn-icon btn-sm" onClick={() => handleDelete(ms.id)}><Icons.trash style={{ width: 14, height: 14 }} /></button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
