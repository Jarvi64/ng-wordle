import React, { useState, useMemo } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { WEEKLY_CATEGORIES } from '../../data/mockData';
import { getCurrentWeek, getWeekLabel } from '../../utils/helpers';
import './WeeklyStatus.css';

const emptyCategories = () => {
  const obj = {};
  WEEKLY_CATEGORIES.forEach(c => { obj[c.key] = { positive: [''], challenges: [''] }; });
  return obj;
};

// Compute diff between previous and current week
function computeChanges(prevCategories, currCategories) {
  if (!prevCategories) return null;
  const changes = {};
  WEEKLY_CATEGORIES.forEach(cat => {
    const prev = prevCategories[cat.key] || { positive: [], challenges: [] };
    const curr = currCategories[cat.key] || { positive: [], challenges: [] };

    const added = {
      positive: curr.positive.filter(b => !prev.positive.includes(b)),
      challenges: curr.challenges.filter(b => !prev.challenges.includes(b)),
    };
    const removed = {
      positive: prev.positive.filter(b => !curr.positive.includes(b)),
      challenges: prev.challenges.filter(b => !curr.challenges.includes(b)),
    };
    const totalChanges = added.positive.length + added.challenges.length + removed.positive.length + removed.challenges.length;
    changes[cat.key] = { added, removed, totalChanges };
  });
  return changes;
}

export default function WeeklyStatus() {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const updates = state.weeklyUpdates[programme.id] || {};
  const weekKeys = Object.keys(updates).sort().reverse();

  const [selectedWeek, setSelectedWeek] = useState(() => {
    // Default to the latest submitted week or current week
    return weekKeys.length > 0 ? weekKeys[0] : getCurrentWeek();
  });
  const existingData = updates[selectedWeek];
  const [categories, setCategories] = useState(existingData?.categories || emptyCategories());
  const [viewMode, setViewMode] = useState(existingData ? 'view' : 'edit');
  const [showChanges, setShowChanges] = useState(false);

  // Find previous week's data for comparison
  const prevWeekKey = useMemo(() => {
    const sortedKeys = Object.keys(updates).sort();
    const idx = sortedKeys.indexOf(selectedWeek);
    return idx > 0 ? sortedKeys[idx - 1] : null;
  }, [updates, selectedWeek]);

  const prevData = prevWeekKey ? updates[prevWeekKey] : null;
  const changes = useMemo(() => {
    if (!prevData || !existingData) return null;
    return computeChanges(prevData.categories, existingData.categories);
  }, [prevData, existingData]);

  const totalChanges = changes ? Object.values(changes).reduce((s, c) => s + c.totalChanges, 0) : 0;

  const handleWeekChange = (weekKey) => {
    setSelectedWeek(weekKey);
    const data = updates[weekKey];
    if (data) {
      setCategories(data.categories);
      setViewMode('view');
    } else {
      setCategories(emptyCategories());
      setViewMode('edit');
    }
    setShowChanges(false);
  };

  const addBullet = (catKey, type) => {
    setCategories(prev => ({
      ...prev,
      [catKey]: { ...prev[catKey], [type]: [...prev[catKey][type], ''] }
    }));
  };

  const updateBullet = (catKey, type, idx, value) => {
    setCategories(prev => ({
      ...prev,
      [catKey]: {
        ...prev[catKey],
        [type]: prev[catKey][type].map((b, i) => i === idx ? value : b)
      }
    }));
  };

  const removeBullet = (catKey, type, idx) => {
    setCategories(prev => ({
      ...prev,
      [catKey]: {
        ...prev[catKey],
        [type]: prev[catKey][type].filter((_, i) => i !== idx)
      }
    }));
  };

  const handleSave = () => {
    const cleaned = {};
    Object.entries(categories).forEach(([key, val]) => {
      cleaned[key] = {
        positive: val.positive.filter(b => b.trim()),
        challenges: val.challenges.filter(b => b.trim()),
      };
    });
    dispatch({
      type: 'SAVE_WEEKLY_UPDATE',
      programmeId: programme.id,
      weekKey: selectedWeek,
      data: { categories: cleaned }
    });
    showToast('Weekly status saved!');
    setViewMode('view');
    setCategories(cleaned);
  };

  return (
    <div>
      {/* Week selector bar */}
      <div className="week-selector-bar">
        <div className="week-selector">
          <label className="form-label" style={{ marginBottom: 0, marginRight: 8 }}>Week:</label>
          <input
            type="week"
            className="form-input"
            style={{ width: 180 }}
            value={selectedWeek}
            onChange={e => handleWeekChange(e.target.value)}
          />
          <span className="week-label-text">{getWeekLabel(selectedWeek)}</span>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {/* Change comparison toggle */}
          {changes && viewMode === 'view' && (
            <button
              className={`btn btn-sm ${showChanges ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setShowChanges(!showChanges)}
              title={`Compare with ${getWeekLabel(prevWeekKey)}`}
            >
              <Icons.trendUp style={{ width: 14, height: 14 }} />
              {showChanges ? 'Hide Changes' : `Show Changes (${totalChanges})`}
            </button>
          )}
          {viewMode === 'view' && (
            <button className="btn btn-primary btn-sm" onClick={() => setViewMode('edit')}>
              <Icons.edit style={{ width: 14, height: 14 }} /> Edit
            </button>
          )}
          {viewMode === 'edit' && (
            <button className="btn btn-success btn-sm" onClick={handleSave}>
              <Icons.save style={{ width: 14, height: 14 }} /> Save Week
            </button>
          )}
        </div>
      </div>

      {/* Change summary banner */}
      {showChanges && changes && (
        <div className="change-summary-banner animate-slideDown">
          <div className="change-summary-icon">
            <Icons.trendUp style={{ width: 18, height: 18 }} />
          </div>
          <div className="change-summary-text">
            <strong>Changes from {getWeekLabel(prevWeekKey)} → {getWeekLabel(selectedWeek)}</strong>
            <span>{totalChanges} change{totalChanges !== 1 ? 's' : ''} detected across {Object.values(changes).filter(c => c.totalChanges > 0).length} categories</span>
          </div>
        </div>
      )}

      {/* History pills */}
      {weekKeys.length > 0 && (
        <div className="week-history">
          {weekKeys.map(wk => (
            <button
              key={wk}
              className={`week-pill ${wk === selectedWeek ? 'active' : ''}`}
              onClick={() => handleWeekChange(wk)}
            >
              {getWeekLabel(wk)}
            </button>
          ))}
        </div>
      )}

      {/* Category cards */}
      <div className="weekly-grid stagger-children">
        {WEEKLY_CATEGORIES.map(cat => {
          const data = categories[cat.key] || { positive: [], challenges: [] };
          const catChanges = showChanges && changes ? changes[cat.key] : null;

          return (
            <div key={cat.key} className="weekly-cat-card section-card">
              <div className="weekly-cat-header" style={{ borderLeft: `4px solid ${cat.color}` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {(() => { const Icon = Icons[cat.icon]; return <Icon style={{ width: 16, height: 16, color: cat.color }} />; })()}
                  <h4 style={{ fontSize: 'var(--text-sm)', fontWeight: 700, color: 'var(--slate-800)' }}>{cat.label}</h4>
                </div>
                {catChanges && catChanges.totalChanges > 0 && (
                  <span className="change-badge">{catChanges.totalChanges} change{catChanges.totalChanges !== 1 ? 's' : ''}</span>
                )}
              </div>

              <div className="weekly-cat-body">
                {/* Positive */}
                <div className="bullet-section bullet-positive">
                  <div className="bullet-section-title">
                    <span className="bullet-icon positive">+</span> Positive Developments
                  </div>
                  {viewMode === 'edit' ? (
                    <div className="bullet-list">
                      {data.positive.map((b, i) => (
                        <div key={i} className="bullet-row">
                          <span className="bullet-marker positive">+</span>
                          <input className="form-input bullet-input" value={b} onChange={e => updateBullet(cat.key, 'positive', i, e.target.value)} placeholder="Enter positive development..." />
                          <button className="btn btn-ghost btn-icon btn-sm" onClick={() => removeBullet(cat.key, 'positive', i)}>
                            <Icons.close style={{ width: 12, height: 12 }} />
                          </button>
                        </div>
                      ))}
                      <button className="btn btn-ghost btn-sm add-bullet-btn" onClick={() => addBullet(cat.key, 'positive')}>
                        <Icons.plus style={{ width: 12, height: 12 }} /> Add
                      </button>
                    </div>
                  ) : (
                    <ul className="bullet-display">
                      {data.positive.length === 0 && <li className="empty-bullet">No entries</li>}
                      {data.positive.map((b, i) => {
                        const isNew = catChanges && catChanges.added.positive.includes(b);
                        return (
                          <li key={i} className={`positive-item ${isNew ? 'change-new' : ''}`}>
                            {b}
                            {isNew && <span className="change-tag new-tag">NEW</span>}
                          </li>
                        );
                      })}
                      {/* Show removed items in diff mode */}
                      {catChanges && catChanges.removed.positive.map((b, i) => (
                        <li key={`rem-${i}`} className="positive-item change-removed">
                          <s>{b}</s>
                          <span className="change-tag removed-tag">REMOVED</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                {/* Challenges */}
                <div className="bullet-section bullet-negative">
                  <div className="bullet-section-title">
                    <span className="bullet-icon negative">−</span> Challenges
                  </div>
                  {viewMode === 'edit' ? (
                    <div className="bullet-list">
                      {data.challenges.map((b, i) => (
                        <div key={i} className="bullet-row">
                          <span className="bullet-marker negative">−</span>
                          <input className="form-input bullet-input" value={b} onChange={e => updateBullet(cat.key, 'challenges', i, e.target.value)} placeholder="Enter challenge..." />
                          <button className="btn btn-ghost btn-icon btn-sm" onClick={() => removeBullet(cat.key, 'challenges', i)}>
                            <Icons.close style={{ width: 12, height: 12 }} />
                          </button>
                        </div>
                      ))}
                      <button className="btn btn-ghost btn-sm add-bullet-btn" onClick={() => addBullet(cat.key, 'challenges')}>
                        <Icons.plus style={{ width: 12, height: 12 }} /> Add
                      </button>
                    </div>
                  ) : (
                    <ul className="bullet-display">
                      {data.challenges.length === 0 && <li className="empty-bullet">No entries</li>}
                      {data.challenges.map((b, i) => {
                        const isNew = catChanges && catChanges.added.challenges.includes(b);
                        return (
                          <li key={i} className={`negative-item ${isNew ? 'change-new' : ''}`}>
                            {b}
                            {isNew && <span className="change-tag new-tag">NEW</span>}
                          </li>
                        );
                      })}
                      {catChanges && catChanges.removed.challenges.map((b, i) => (
                        <li key={`rem-${i}`} className="negative-item change-removed">
                          <s>{b}</s>
                          <span className="change-tag removed-tag">REMOVED</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
