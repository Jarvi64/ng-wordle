import React from 'react';
import GenericTableSection from './GenericTableSection';

export default function PartnerTimeline() {
  return (
    <GenericTableSection
      title="Partner / ToT / OEM Timeline & Milestones"
      collection="partnerTimelines"
      columns={[
        { key: 'partnerName', label: 'Partner Name', type: 'text', width: 180 },
        { key: 'milestone', label: 'Milestone', type: 'text', width: 200 },
        { key: 'startDate', label: 'Start Date', type: 'date' },
        { key: 'endDate', label: 'End Date', type: 'date' },
        { key: 'owner', label: 'Owner', type: 'person' },
      ]}
      emptyRow={{ partnerName: '', milestone: '', startDate: '', endDate: '', owner: '' }}
    />
  );
}
