import React from 'react';
import GenericTableSection from './GenericTableSection';

export default function ProgrammeBudget() {
  return (
    <GenericTableSection
      title="Programme Budget (Cost)"
      collection="budgets"
      columns={[
        { key: 'item', label: 'Item', type: 'text', width: 180 },
        { key: 'supplier', label: 'Supplier', type: 'text' },
        { key: 'unitCost', label: 'Unit Cost (INR Cr)', type: 'currency' },
        { key: 'targetCost', label: 'Target Cost (INR Cr)', type: 'currency' },
        { key: 'deadline', label: 'Deadline', type: 'date' },
        { key: 'owner', label: 'Owner', type: 'person' },
      ]}
      emptyRow={{ item: '', supplier: '', unitCost: '', targetCost: '', deadline: '', owner: '' }}
    />
  );
}
