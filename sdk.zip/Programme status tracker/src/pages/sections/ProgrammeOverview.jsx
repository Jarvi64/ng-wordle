import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { formatDate, getPersonName } from '../../utils/helpers';

export default function ProgrammeOverview() {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ ...programme });

  const poc1 = state.people.find(p => p.id === programme.poc1Id);
  const poc2 = state.people.find(p => p.id === programme.poc2Id);
  const bu = state.businessUnits.find(b => b.id === programme.businessUnitId);
  const cap = bu ? state.capabilities.find(c => c.id === bu.capabilityId) : null;

  const handleSave = (e) => {
    e.preventDefault();
    if (!form.name || !form.businessUnitId || !form.poc1Id) {
      showToast('Please fill all required fields', 'error');
      return;
    }
    dispatch({ type: 'UPDATE_IN_COLLECTION', collection: 'programmes', item: form });
    showToast('Programme overview updated');
    setEditing(false);
  };

  if (editing) {
    return (
      <div className="section-card animate-fadeIn">
        <form onSubmit={handleSave}>
          <div className="section-card-header">
            <h3>Edit Programme Overview</h3>
            <div style={{ display: 'flex', gap: 8 }}>
              <button type="button" className="btn btn-secondary btn-sm" onClick={() => setEditing(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary btn-sm">
                <Icons.save style={{ width: 14, height: 14 }} /> Save
              </button>
            </div>
          </div>
          <div className="section-card-body">
            <div className="form-group">
              <label className="form-label">Programme Name <span style={{ color: 'var(--danger-500)' }}>*</span></label>
              <input required className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Business Unit <span style={{ color: 'var(--danger-500)' }}>*</span></label>
              <select required className="form-select" value={form.businessUnitId || ''} onChange={e => setForm({ ...form, businessUnitId: e.target.value })}>
                <option value="" disabled>Select Business Unit</option>
                {state.businessUnits.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Status <span style={{ color: 'var(--danger-500)' }}>*</span></label>
              <select required className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                <option value="active">Active</option>
                <option value="planning">Planning</option>
                <option value="on-hold">On Hold</option>
                <option value="completed">Completed</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">POC 1 (Primary) <span style={{ color: 'var(--danger-500)' }}>*</span></label>
              <select required className="form-select" value={form.poc1Id || ''} onChange={e => setForm({ ...form, poc1Id: e.target.value })}>
                <option value="" disabled>Select POC 1</option>
                {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">POC 2 (Escalation)</label>
              <select className="form-select" value={form.poc2Id || ''} onChange={e => setForm({ ...form, poc2Id: e.target.value })}>
                <option value="">Select...</option>
                {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Start Date</label>
              <input className="form-input" type="date" value={form.startDate || ''} onChange={e => setForm({ ...form, startDate: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Target End Date</label>
              <input className="form-input" type="date" value={form.targetEndDate || ''} onChange={e => setForm({ ...form, targetEndDate: e.target.value })} />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Overview / Description</label>
            <textarea className="form-input" rows={4} value={form.overview || ''} onChange={e => setForm({ ...form, overview: e.target.value })} />
          </div>
        </div>
      </form>
    </div>
    );
  }

  return (
    <div>
      <div className="section-card animate-slideUp">
        <div className="section-card-header">
          <h3>Programme Overview</h3>
          <button className="btn btn-secondary btn-sm" onClick={() => { setForm({ ...programme }); setEditing(true); }}>
            <Icons.edit style={{ width: 14, height: 14 }} /> Edit
          </button>
        </div>
        <div className="section-card-body">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 24 }}>
            <div>
              <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>Capability</div>
              <div style={{ fontWeight: 600, color: 'var(--slate-800)' }}>{cap?.name || '—'}</div>
            </div>
            <div>
              <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>Business Unit</div>
              <div style={{ fontWeight: 600, color: 'var(--slate-800)' }}>{bu?.name || '—'}</div>
            </div>
            <div>
              <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>Status</div>
              <span className={`badge ${programme.status === 'active' ? 'badge-success' : 'badge-info'}`}>{programme.status}</span>
            </div>
            <div>
              <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>POC 1 (Primary)</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div className="mini-avatar">{poc1 ? poc1.name.split(' ').map(w => w[0]).join('') : '?'}</div>
                <div>
                  <div style={{ fontWeight: 600, color: 'var(--slate-800)', fontSize: 'var(--text-sm)' }}>{poc1?.name || '—'}</div>
                  <div style={{ fontSize: 'var(--text-xs)', color: 'var(--slate-500)' }}>{poc1?.role || ''}</div>
                </div>
              </div>
            </div>
            <div>
              <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>POC 2 (Escalation)</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div className="mini-avatar" style={{ background: 'linear-gradient(135deg, var(--warning-500), #F97316)' }}>{poc2 ? poc2.name.split(' ').map(w => w[0]).join('') : '?'}</div>
                <div>
                  <div style={{ fontWeight: 600, color: 'var(--slate-800)', fontSize: 'var(--text-sm)' }}>{poc2?.name || '—'}</div>
                  <div style={{ fontSize: 'var(--text-xs)', color: 'var(--slate-500)' }}>{poc2?.role || ''}</div>
                </div>
              </div>
            </div>
            <div>
              <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>Timeline</div>
              <div style={{ fontWeight: 600, color: 'var(--slate-800)', fontSize: 'var(--text-sm)' }}>{formatDate(programme.startDate)} — {formatDate(programme.targetEndDate)}</div>
            </div>
          </div>
          <div>
            <div style={{ fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--slate-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Programme Description</div>
            <p style={{ fontSize: 'var(--text-base)', color: 'var(--slate-700)', lineHeight: 1.7 }}>{programme.overview || 'No overview provided.'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
