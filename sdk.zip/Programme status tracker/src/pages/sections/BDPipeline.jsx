import React from 'react';
import GenericTableSection from './GenericTableSection';

export default function BDPipeline() {
  return (
    <GenericTableSection
      title="BD Pipeline"
      collection="bdPipeline"
      columns={[
        { key: 'project', label: 'Project', type: 'text', width: 200 },
        { key: 'currentStatus', label: 'Current Status', type: 'text' },
        { key: 'nextSteps', label: 'Next Steps', type: 'text' },
        { key: 'timeline', label: 'Timeline', type: 'text' },
        { key: 'owner', label: 'Owner', type: 'person' },
      ]}
      emptyRow={{ project: '', currentStatus: '', nextSteps: '', timeline: '', owner: '' }}
    />
  );
}
