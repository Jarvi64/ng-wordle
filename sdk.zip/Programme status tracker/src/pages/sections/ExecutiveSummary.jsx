import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { genId, getPersonName, getStatusColor } from '../../utils/helpers';
import { STATUS_OPTIONS } from '../../data/mockData';

export default function ExecutiveSummary() {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const items = state.executiveSummary[programme.id] || [];
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [filter, setFilter] = useState('All');

  const filtered = filter === 'All' ? items : items.filter(x => x.status === filter);

  const handleAdd = () => {
    const newItem = { id: genId(), issueSummary: '', ownerName: '', deadline: '', status: 'Open' };
    dispatch({ type: 'ADD_TO_PROGRAMME_DATA', collection: 'executiveSummary', programmeId: programme.id, item: newItem });
    setEditing(newItem.id);
    setForm(newItem);
  };

  const handleSave = () => {
    dispatch({ type: 'UPDATE_IN_PROGRAMME_DATA', collection: 'executiveSummary', programmeId: programme.id, item: form });
    showToast('Saved');
    setEditing(null);
  };

  const handleDelete = (itemId) => {
    dispatch({ type: 'DELETE_FROM_PROGRAMME_DATA', collection: 'executiveSummary', programmeId: programme.id, itemId });
    showToast('Removed', 'info');
  };

  return (
    <div className="section-card animate-slideUp">
      <div className="section-card-header">
        <h3>Executive Summary / Support Required</h3>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div className="tabs" style={{ marginBottom: 0 }}>
            {['All', ...STATUS_OPTIONS].map(s => (
              <button key={s} className={`tab-btn ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)} style={{ padding: '4px 12px', fontSize: '11px' }}>{s}</button>
            ))}
          </div>
          <button className="btn btn-primary btn-sm" onClick={handleAdd}>
            <Icons.plus style={{ width: 14, height: 14 }} /> Add Issue
          </button>
        </div>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th style={{ minWidth: 250 }}>Issue Summary</th>
              <th>Owner</th>
              <th>Deadline</th>
              <th>Status</th>
              <th style={{ width: 100 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={5} style={{ textAlign: 'center', padding: 40, color: 'var(--slate-400)' }}>No issues found.</td></tr>
            )}
            {filtered.map(item => (
              <tr key={item.id}>
                {editing === item.id ? (
                  <>
                    <td><input className="form-input" value={form.issueSummary} onChange={e => setForm({ ...form, issueSummary: e.target.value })} /></td>
                    <td>
                      <select className="form-select" value={form.ownerName} onChange={e => setForm({ ...form, ownerName: e.target.value })}>
                        <option value="">Select...</option>
                        {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </td>
                    <td><input className="form-input" type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} /></td>
                    <td>
                      <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                        {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                    <td>
                      <div className="action-btns">
                        <button className="btn btn-success btn-icon btn-sm" onClick={handleSave}><Icons.check style={{ width: 14, height: 14 }} /></button>
                        <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setEditing(null)}><Icons.close style={{ width: 14, height: 14 }} /></button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    <td><strong>{item.issueSummary || '—'}</strong></td>
                    <td>{getPersonName(state.people, item.ownerName)}</td>
                    <td>{item.deadline ? new Date(item.deadline).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}</td>
                    <td><span className={`badge ${getStatusColor(item.status)}`}>{item.status}</span></td>
                    <td>
                      <div className="action-btns">
                        <button className="btn btn-ghost btn-icon btn-sm" onClick={() => { setForm({ ...item }); setEditing(item.id); }}><Icons.edit style={{ width: 14, height: 14 }} /></button>
                        <button className="btn btn-danger btn-icon btn-sm" onClick={() => handleDelete(item.id)}><Icons.trash style={{ width: 14, height: 14 }} /></button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
