import React from 'react';
import GenericTableSection from './GenericTableSection';

export default function ProgrammeBOM() {
  return (
    <GenericTableSection
      title="Programme BOM (Bill of Materials)"
      collection="boms"
      columns={[
        { key: 'bomItem', label: 'BOM Item', type: 'text', width: 180 },
        { key: 'supplier', label: 'Supplier', type: 'text' },
        { key: 'budgetCost', label: 'Budget Cost (INR Cr)', type: 'currency' },
        { key: 'targetCost', label: 'Target Cost (INR Cr)', type: 'currency' },
        { key: 'dateOfOrder', label: 'Date of Order', type: 'date' },
        { key: 'dateOfDelivery', label: 'Date of Delivery', type: 'date' },
        { key: 'leadTime', label: 'Lead Time', type: 'text' },
        { key: 'owner', label: 'Owner', type: 'person' },
      ]}
      emptyRow={{ bomItem: '', supplier: '', budgetCost: '', targetCost: '', dateOfOrder: '', dateOfDelivery: '', leadTime: '', owner: '' }}
    />
  );
}
