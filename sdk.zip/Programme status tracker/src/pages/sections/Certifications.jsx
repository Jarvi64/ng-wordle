import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { genId, getPersonName } from '../../utils/helpers';
import { CERT_STATUSES } from '../../data/mockData';

export default function Certifications() {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const items = state.certifications[programme.id] || [];
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({});

  const handleAdd = () => { setForm({ certification: '', status: 'Pending', owner: '' }); setModal('add'); };
  const handleEdit = (item) => { setForm({ ...item }); setModal('edit'); };

  const handleSave = (e) => {
    e.preventDefault();
    if (!form.certification) {
      showToast('Certification name is required', 'error');
      return;
    }
    if (modal === 'add') {
      dispatch({ type: 'ADD_TO_PROGRAMME_DATA', collection: 'certifications', programmeId: programme.id, item: { ...form, id: genId() } });
      showToast('Certification added');
    } else {
      dispatch({ type: 'UPDATE_IN_PROGRAMME_DATA', collection: 'certifications', programmeId: programme.id, item: form });
      showToast('Updated');
    }
    setModal(null);
  };

  const handleDelete = (itemId) => {
    dispatch({ type: 'DELETE_FROM_PROGRAMME_DATA', collection: 'certifications', programmeId: programme.id, itemId });
    showToast('Removed', 'info');
  };

  const obtained = items.filter(i => i.status === 'Obtained').length;
  const total = items.length;
  const pct = total > 0 ? Math.round((obtained / total) * 100) : 0;

  return (
    <div>
      {/* Progress summary */}
      <div className="section-card animate-slideUp" style={{ marginBottom: 20 }}>
        <div className="section-card-body" style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <div style={{ position: 'relative', width: 70, height: 70 }}>
            <svg viewBox="0 0 100 100" style={{ width: 70, height: 70, transform: 'rotate(-90deg)' }}>
              <circle cx="50" cy="50" r="42" fill="none" stroke="var(--slate-100)" strokeWidth="8" />
              <circle cx="50" cy="50" r="42" fill="none" stroke="var(--success-500)" strokeWidth="8"
                strokeDasharray={`${2 * Math.PI * 42}`}
                strokeDashoffset={`${2 * Math.PI * 42 * (1 - pct / 100)}`}
                strokeLinecap="round"
                style={{ transition: 'stroke-dashoffset 1s ease-out' }}
              />
            </svg>
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 'var(--text-lg)', color: 'var(--slate-800)' }}>{pct}%</div>
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 'var(--text-lg)', color: 'var(--slate-800)' }}>{obtained} / {total} Obtained</div>
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--slate-500)' }}>Certifications, licenses & approvals progress</div>
          </div>
        </div>
      </div>

      {/* Cards */}
      <div className="section-card animate-slideUp">
        <div className="section-card-header">
          <h3>Certifications / Licenses / Approvals</h3>
          <button className="btn btn-primary btn-sm" onClick={handleAdd}>
            <Icons.plus style={{ width: 14, height: 14 }} /> Add
          </button>
        </div>
        <div className="section-card-body">
          {items.length === 0 && (
            <div className="empty-state">
              <Icons.certificate style={{ width: 50, height: 50 }} />
              <h3>No certifications yet</h3>
              <p>Add certifications, licenses, or approvals to track.</p>
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
            {items.map(item => (
              <div key={item.id} style={{
                padding: '16px',
                borderRadius: 'var(--radius-md)',
                border: '1.5px solid',
                borderColor: item.status === 'Obtained' ? 'var(--success-200)' : item.status === 'In Progress' ? 'var(--info-100)' : 'var(--warning-200)',
                background: item.status === 'Obtained' ? 'var(--success-50)' : 'var(--bg-primary)',
                transition: 'all 200ms',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <span className={`badge ${item.status === 'Obtained' ? 'badge-success' : item.status === 'In Progress' ? 'badge-info' : 'badge-warning'}`}>{item.status}</span>
                  <div className="action-btns">
                    <button className="btn btn-ghost btn-icon btn-sm" onClick={() => handleEdit(item)}><Icons.edit style={{ width: 12, height: 12 }} /></button>
                    <button className="btn btn-danger btn-icon btn-sm" onClick={() => handleDelete(item.id)}><Icons.trash style={{ width: 12, height: 12 }} /></button>
                  </div>
                </div>
                <div style={{ fontWeight: 700, fontSize: 'var(--text-sm)', color: 'var(--slate-800)', marginBottom: 4 }}>{item.certification}</div>
                <div style={{ fontSize: 'var(--text-xs)', color: 'var(--slate-500)' }}>Owner: {getPersonName(state.people, item.owner)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">{modal === 'add' ? 'Add Certification' : 'Edit Certification'}</h3>
              <button className="btn btn-ghost btn-icon" onClick={() => setModal(null)}><Icons.close style={{ width: 18, height: 18 }} /></button>
            </div>
            <form onSubmit={handleSave}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Certification / License / Approval <span style={{ color: 'var(--danger-500)' }}>*</span></label>
                  <input required className="form-input" value={form.certification || ''} onChange={e => setForm({ ...form, certification: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Status <span style={{ color: 'var(--danger-500)' }}>*</span></label>
                  <select required className="form-select" value={form.status || 'Pending'} onChange={e => setForm({ ...form, status: e.target.value })}>
                    {CERT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Owner</label>
                  <select className="form-select" value={form.owner || ''} onChange={e => setForm({ ...form, owner: e.target.value })}>
                    <option value="">Select...</option>
                    {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Icons.save style={{ width: 14, height: 14 }} /> Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
