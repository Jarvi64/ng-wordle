import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { genId, formatDate, formatCurrency, getPersonName, getStatusColor } from '../../utils/helpers';

/**
 * GenericTableSection — reusable table component for all programme data sections
 * Accepts config: { title, collection, columns }
 * columns: [{ key, label, type: 'text'|'date'|'number'|'person'|'status'|'currency', width?, options? }]
 */
export default function GenericTableSection({ title, collection, columns, emptyRow }) {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const items = state[collection][programme.id] || [];
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});

  const handleAdd = () => {
    const newItem = { id: genId(), ...emptyRow };
    dispatch({ type: 'ADD_TO_PROGRAMME_DATA', collection, programmeId: programme.id, item: newItem });
    setEditing(newItem.id);
    setForm(newItem);
  };

  const handleSave = () => {
    // Simple validation: Ensure primary column (first column) is filled
    const primaryCol = columns[0];
    const val = form[primaryCol.key];
    if (!val || val.toString().trim() === '') {
      showToast(`${primaryCol.label} is required`, 'error');
      return;
    }

    dispatch({ type: 'UPDATE_IN_PROGRAMME_DATA', collection, programmeId: programme.id, item: form });
    showToast('Saved');
    setEditing(null);
  };

  const handleDelete = (itemId) => {
    dispatch({ type: 'DELETE_FROM_PROGRAMME_DATA', collection, programmeId: programme.id, itemId });
    showToast('Removed', 'info');
  };

  const renderCell = (col, value) => {
    switch (col.type) {
      case 'date': return formatDate(value);
      case 'currency': return formatCurrency(value);
      case 'person': return getPersonName(state.people, value);
      case 'status': return <span className={`badge ${getStatusColor(value)}`}>{value || '—'}</span>;
      default: return value || '—';
    }
  };

  const renderInput = (col) => {
    const val = form[col.key] || '';
    switch (col.type) {
      case 'date':
        return <input className="form-input" type="date" value={val} onChange={e => setForm({ ...form, [col.key]: e.target.value })} />;
      case 'number':
      case 'currency':
        return <input className="form-input" type="number" step="0.01" value={val} onChange={e => setForm({ ...form, [col.key]: e.target.value })} />;
      case 'person':
        return (
          <select className="form-select" value={val} onChange={e => setForm({ ...form, [col.key]: e.target.value })}>
            <option value="">Select...</option>
            {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        );
      case 'status':
        return (
          <select className="form-select" value={val} onChange={e => setForm({ ...form, [col.key]: e.target.value })}>
            {(col.options || ['Open', 'In Progress', 'Changed', 'Closed']).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        );
      default:
        return <input className="form-input" value={val} onChange={e => setForm({ ...form, [col.key]: e.target.value })} />;
    }
  };

  // Calculate totals for currency columns
  const totals = {};
  columns.forEach(col => {
    if (col.type === 'currency') {
      totals[col.key] = items.reduce((sum, item) => sum + (parseFloat(item[col.key]) || 0), 0);
    }
  });
  const hasTotals = Object.keys(totals).length > 0;

  return (
    <div className="section-card animate-slideUp">
      <div className="section-card-header">
        <h3>{title}</h3>
        <button className="btn btn-primary btn-sm" onClick={handleAdd}>
          <Icons.plus style={{ width: 14, height: 14 }} /> Add Row
        </button>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key} style={col.width ? { minWidth: col.width } : {}}>{col.label}</th>
              ))}
              <th style={{ width: 100 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 && (
              <tr><td colSpan={columns.length + 1} style={{ textAlign: 'center', padding: 40, color: 'var(--slate-400)' }}>No data yet. Click "Add Row" to start.</td></tr>
            )}
            {items.map(item => (
              <tr key={item.id}>
                {editing === item.id ? (
                  <>
                    {columns.map(col => (
                      <td key={col.key}>{renderInput(col)}</td>
                    ))}
                    <td>
                      <div className="action-btns">
                        <button className="btn btn-success btn-icon btn-sm" onClick={handleSave}><Icons.check style={{ width: 14, height: 14 }} /></button>
                        <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setEditing(null)}><Icons.close style={{ width: 14, height: 14 }} /></button>
                      </div>
                    </td>
                  </>
                ) : (
                  <>
                    {columns.map((col, ci) => (
                      <td key={col.key}>{ci === 0 ? <strong>{renderCell(col, item[col.key])}</strong> : renderCell(col, item[col.key])}</td>
                    ))}
                    <td>
                      <div className="action-btns">
                        <button className="btn btn-ghost btn-icon btn-sm" onClick={() => { setForm({ ...item }); setEditing(item.id); }}><Icons.edit style={{ width: 14, height: 14 }} /></button>
                        <button className="btn btn-danger btn-icon btn-sm" onClick={() => handleDelete(item.id)}><Icons.trash style={{ width: 14, height: 14 }} /></button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
            {hasTotals && items.length > 0 && (
              <tr style={{ background: 'var(--slate-50)', fontWeight: 700 }}>
                {columns.map((col, ci) => (
                  <td key={col.key} style={col.type === 'currency' ? { color: 'var(--primary-700)' } : {}}>
                    {ci === 0 ? 'Total' : col.type === 'currency' ? formatCurrency(totals[col.key]) : ''}
                  </td>
                ))}
                <td></td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
