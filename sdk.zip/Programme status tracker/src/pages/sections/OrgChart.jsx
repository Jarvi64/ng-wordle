import React, { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Icons } from '../../components/svg/Icons';
import { genId } from '../../utils/helpers';
import './OrgChart.css';

function OrgNode({ node, onEdit, onAddChild, onDelete, depth = 0 }) {
  const [expanded, setExpanded] = useState(true);
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div className="org-node-wrapper">
      <div className={`org-node ${depth === 0 ? 'org-root' : ''}`}>
        <div className="org-node-avatar">
          {node.name ? node.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() : '?'}
        </div>
        <div className="org-node-info">
          <div className="org-node-name">{node.name || 'Unnamed'}</div>
          <div className="org-node-title">{node.title || 'No title'}</div>
        </div>
        <div className="org-node-actions">
          <button className="btn btn-ghost btn-icon btn-sm" onClick={() => onEdit(node)} title="Edit">
            <Icons.edit style={{ width: 12, height: 12 }} />
          </button>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={() => onAddChild(node.id)} title="Add report">
            <Icons.plus style={{ width: 12, height: 12 }} />
          </button>
          {depth > 0 && (
            <button className="btn btn-danger btn-icon btn-sm" onClick={() => onDelete(node.id)} title="Remove">
              <Icons.trash style={{ width: 12, height: 12 }} />
            </button>
          )}
        </div>
        {hasChildren && (
          <button type="button" className="org-expand-btn" onClick={() => setExpanded(!expanded)}>
            <Icons.chevronDown style={{ width: 14, height: 14, transform: expanded ? 'rotate(180deg)' : 'none', transition: 'transform 200ms' }} />
          </button>
        )}
      </div>
      {hasChildren && expanded && (
        <div className="org-children">
          {node.children.map(child => (
            <OrgNode key={child.id} node={child} onEdit={onEdit} onAddChild={onAddChild} onDelete={onDelete} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function OrgChart() {
  const { programme } = useOutletContext();
  const { state, dispatch, showToast } = useApp();
  const orgData = state.orgCharts[programme.id] || null;
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({});

  const initOrgChart = () => {
    const root = { id: genId(), name: 'Programme Head', title: 'Director', children: [] };
    dispatch({ type: 'SET_ORG_CHART', programmeId: programme.id, data: root });
    showToast('Org chart initialized');
  };

  const findNode = (node, id) => {
    if (node.id === id) return node;
    if (node.children) {
      for (const child of node.children) {
        const found = findNode(child, id);
        if (found) return found;
      }
    }
    return null;
  };

  const handleEdit = (node) => {
    setForm({ ...node });
    setModal('edit');
  };

  const handleAddChild = (parentId) => {
    const newNode = { id: genId(), name: '', title: '', children: [] };
    setForm({ ...newNode, parentId });
    setModal('addChild');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || form.name.trim() === '') {
      showToast('Name is required', 'error');
      return;
    }
    if (modal === 'edit') {
      const updated = JSON.parse(JSON.stringify(orgData));
      const node = findNode(updated, form.id);
      if (node) {
        node.name = form.name;
        node.title = form.title;
      }
      dispatch({ type: 'SET_ORG_CHART', programmeId: programme.id, data: updated });
      showToast('Updated');
    } else {
      const updated = JSON.parse(JSON.stringify(orgData));
      const parent = findNode(updated, form.parentId);
      if (parent) {
        parent.children = parent.children || [];
        parent.children.push({ id: form.id, name: form.name, title: form.title, children: [] });
      }
      dispatch({ type: 'SET_ORG_CHART', programmeId: programme.id, data: updated });
      showToast('Added');
    }
    setModal(null);
  };

  const handleDeleteNode = (nodeId) => {
    const removeNode = (node) => {
      if (!node.children) return node;
      return { ...node, children: node.children.filter(c => c.id !== nodeId).map(removeNode) };
    };
    const updated = removeNode(JSON.parse(JSON.stringify(orgData)));
    dispatch({ type: 'SET_ORG_CHART', programmeId: programme.id, data: updated });
    showToast('Removed', 'info');
  };

  if (!orgData) {
    return (
      <div className="section-card animate-slideUp">
        <div className="section-card-body" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <Icons.orgChart style={{ width: 60, height: 60, color: 'var(--slate-300)', margin: '0 auto 16px' }} />
          <h3 style={{ color: 'var(--slate-500)', marginBottom: 8 }}>No Organization Chart Yet</h3>
          <p style={{ color: 'var(--slate-400)', fontSize: 'var(--text-sm)', marginBottom: 20 }}>Initialize the org chart to start building the reporting structure.</p>
          <button className="btn btn-primary" onClick={initOrgChart}>
            <Icons.plus style={{ width: 14, height: 14 }} /> Initialize Org Chart
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="section-card animate-slideUp">
        <div className="section-card-header">
          <h3>Organization Chart</h3>
        </div>
        <div className="section-card-body org-chart-container">
          <OrgNode node={orgData} onEdit={handleEdit} onAddChild={handleAddChild} onDelete={handleDeleteNode} />
        </div>
      </div>

      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">{modal === 'edit' ? 'Edit Node' : 'Add Report'}</h3>
              <button className="btn btn-ghost btn-icon" onClick={() => setModal(null)}>
                <Icons.close style={{ width: 18, height: 18 }} />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Name <span style={{ color: 'var(--danger-500)' }}>*</span></label>
                  <input required className="form-input" value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} autoFocus />
                </div>
                <div className="form-group">
                  <label className="form-label">Title / Designation</label>
                  <input className="form-input" value={form.title || ''} onChange={e => setForm({ ...form, title: e.target.value })} />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">
                  <Icons.save style={{ width: 14, height: 14 }} /> Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
