import React from 'react';
import GenericTableSection from './GenericTableSection';

export default function CapexBudget() {
  return (
    <GenericTableSection
      title="CAPEX Budget"
      collection="capexBudgets"
      columns={[
        { key: 'capexItem', label: 'CAPEX Item', type: 'text', width: 200 },
        { key: 'budget', label: 'Budget (INR Cr)', type: 'currency' },
        { key: 'actual', label: 'Actual (INR Cr)', type: 'currency' },
        { key: 'dateOfCommissioning', label: 'Date of Commissioning', type: 'date' },
        { key: 'owner', label: 'Owner', type: 'person' },
      ]}
      emptyRow={{ capexItem: '', budget: '', actual: '', dateOfCommissioning: '', owner: '' }}
    />
  );
}
