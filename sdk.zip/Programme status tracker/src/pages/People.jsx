import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/svg/Icons';
import { genId } from '../utils/helpers';
import './People.css';

export default function People() {
  const { state, dispatch, showToast } = useApp();
  const [modal, setModal] = useState(null);
  const [formData, setFormData] = useState({});

  const openAdd = () => { setFormData({}); setModal('add'); };
  const openEdit = (person) => { setFormData({ ...person }); setModal('edit'); };

  const handleSave = (e) => {
    e.preventDefault();
    if (modal === 'add') {
      dispatch({ type: 'ADD_TO_COLLECTION', collection: 'people', item: { ...formData, id: genId() } });
      showToast('Person added');
    } else {
      dispatch({ type: 'UPDATE_IN_COLLECTION', collection: 'people', item: formData });
      showToast('Updated');
    }
    setModal(null);
  };

  const handleDelete = (id) => {
    dispatch({ type: 'DELETE_FROM_COLLECTION', collection: 'people', id });
    showToast('Person removed', 'info');
  };

  const getAssociatedProgs = (personId) => {
    return state.programmes.filter(p => p.poc1Id === personId || p.poc2Id === personId);
  };

  return (
    <div className="page-content">
      <div className="page-header">
        <h1 className="page-title">People / POCs</h1>
        <p className="page-subtitle">Manage contacts responsible for programme updates</p>
      </div>

      <div className="table-header-row">
        <h3>{state.people.length} People</h3>
        <button className="btn btn-primary btn-sm" onClick={openAdd}>
          <Icons.plus style={{ width: 14, height: 14 }} /> Add Person
        </button>
      </div>

      <div className="people-grid stagger-children">
        {state.people.map(person => {
          const progs = getAssociatedProgs(person.id);
          return (
            <div key={person.id} className="person-card card">
              <div className="person-card-top">
                <div className="person-avatar">
                  {person.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)}
                </div>
                <div className="action-btns">
                  <button className="btn btn-ghost btn-icon" onClick={() => openEdit(person)}>
                    <Icons.edit style={{ width: 14, height: 14 }} />
                  </button>
                  <button className="btn btn-danger btn-icon" onClick={() => handleDelete(person.id)}>
                    <Icons.trash style={{ width: 14, height: 14 }} />
                  </button>
                </div>
              </div>
              <h3 className="person-name">{person.name}</h3>
              <p className="person-role">{person.role}</p>
              <p className="person-email">{person.email}</p>
              {progs.length > 0 && (
                <div className="person-programmes">
                  <div className="person-programmes-label">Associated Programmes</div>
                  {progs.map(prog => (
                    <div key={prog.id} className="person-prog-badge">
                      {prog.poc1Id === person.id && <span className="badge badge-success" style={{ fontSize: '8px', padding: '1px 6px' }}>POC 1</span>}
                      {prog.poc2Id === person.id && <span className="badge badge-warning" style={{ fontSize: '8px', padding: '1px 6px' }}>POC 2</span>}
                      <span>{prog.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <form onSubmit={handleSave}>
              <div className="modal-header">
                <h3 className="modal-title">{modal === 'add' ? 'Add Person' : 'Edit Person'}</h3>
                <button type="button" className="btn btn-ghost btn-icon" onClick={() => setModal(null)}>
                  <Icons.close style={{ width: 18, height: 18 }} />
                </button>
              </div>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input className="form-input" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Email *</label>
                  <input className="form-input" required type="email" value={formData.email || ''} onChange={e => setFormData({ ...formData, email: e.target.value })} />
                </div>
                <div className="form-group">
                  <label className="form-label">Role / Designation *</label>
                  <input className="form-input" required value={formData.role || ''} onChange={e => setFormData({ ...formData, role: e.target.value })} />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">
                  <Icons.save style={{ width: 14, height: 14 }} /> {modal === 'add' ? 'Add' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
