import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/svg/Icons';
import { genId } from '../utils/helpers';
import './MasterData.css';

export default function MasterData() {
  const { state, dispatch, showToast } = useApp();
  const [activeTab, setActiveTab] = useState('capabilities');
  const [modal, setModal] = useState(null);
  const [formData, setFormData] = useState({});

  const tabs = [
    { key: 'capabilities', label: 'Capabilities' },
    { key: 'businessUnits', label: 'Business Units' },
    { key: 'programmes', label: 'Programmes' },
  ];

  const openAdd = (type) => {
    setFormData({});
    setModal({ type, mode: 'add' });
  };

  const openEdit = (type, item) => {
    setFormData({ ...item });
    setModal({ type, mode: 'edit' });
  };

  const handleSave = (e) => {
    e.preventDefault();
    const { type, mode } = modal;
    if (mode === 'add') {
      const item = { ...formData, id: genId() };
      dispatch({ type: 'ADD_TO_COLLECTION', collection: type, item });
      showToast(`${type === 'capabilities' ? 'Capability' : type === 'businessUnits' ? 'Business Unit' : 'Programme'} added`);
    } else {
      dispatch({ type: 'UPDATE_IN_COLLECTION', collection: type, item: formData });
      showToast('Updated successfully');
    }
    setModal(null);
  };

  const handleDelete = (type, id) => {
    dispatch({ type: 'DELETE_FROM_COLLECTION', collection: type, id });
    showToast('Deleted', 'info');
  };

  return (
    <div className="page-content">
      <div className="page-header">
        <h1 className="page-title">Master Data</h1>
        <p className="page-subtitle">Manage capabilities, business units, and programmes</p>
      </div>

      <div className="tabs">
        {tabs.map(t => (
          <button key={t.key} className={`tab-btn ${activeTab === t.key ? 'active' : ''}`} onClick={() => setActiveTab(t.key)}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Capabilities Tab */}
      {activeTab === 'capabilities' && (
        <div className="animate-fadeIn">
          <div className="table-header-row">
            <h3>{state.capabilities.length} Capabilities</h3>
            <button className="btn btn-primary btn-sm" onClick={() => openAdd('capabilities')}>
              <Icons.plus style={{ width: 14, height: 14 }} /> Add Capability
            </button>
          </div>
          <div className="card">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Business Units</th>
                  <th style={{ width: 100 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {state.capabilities.map(cap => {
                  const buCount = state.businessUnits.filter(b => b.capabilityId === cap.id).length;
                  return (
                    <tr key={cap.id}>
                      <td><strong>{cap.name}</strong></td>
                      <td>{cap.description}</td>
                      <td><span className="badge badge-neutral">{buCount}</span></td>
                      <td>
                        <div className="action-btns">
                          <button className="btn btn-ghost btn-icon" onClick={() => openEdit('capabilities', cap)}>
                            <Icons.edit style={{ width: 14, height: 14 }} />
                          </button>
                          <button className="btn btn-danger btn-icon" onClick={() => handleDelete('capabilities', cap.id)}>
                            <Icons.trash style={{ width: 14, height: 14 }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Business Units Tab */}
      {activeTab === 'businessUnits' && (
        <div className="animate-fadeIn">
          <div className="table-header-row">
            <h3>{state.businessUnits.length} Business Units</h3>
            <button className="btn btn-primary btn-sm" onClick={() => openAdd('businessUnits')}>
              <Icons.plus style={{ width: 14, height: 14 }} /> Add Business Unit
            </button>
          </div>
          <div className="card">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Capability</th>
                  <th>Programmes</th>
                  <th style={{ width: 100 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {state.businessUnits.map(bu => {
                  const cap = state.capabilities.find(c => c.id === bu.capabilityId);
                  const progCount = state.programmes.filter(p => p.businessUnitId === bu.id).length;
                  return (
                    <tr key={bu.id}>
                      <td><strong>{bu.name}</strong></td>
                      <td>{cap?.name || '—'}</td>
                      <td><span className="badge badge-neutral">{progCount}</span></td>
                      <td>
                        <div className="action-btns">
                          <button className="btn btn-ghost btn-icon" onClick={() => openEdit('businessUnits', bu)}>
                            <Icons.edit style={{ width: 14, height: 14 }} />
                          </button>
                          <button className="btn btn-danger btn-icon" onClick={() => handleDelete('businessUnits', bu.id)}>
                            <Icons.trash style={{ width: 14, height: 14 }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Programmes Tab */}
      {activeTab === 'programmes' && (
        <div className="animate-fadeIn">
          <div className="table-header-row">
            <h3>{state.programmes.length} Programmes</h3>
            <button className="btn btn-primary btn-sm" onClick={() => openAdd('programmes')}>
              <Icons.plus style={{ width: 14, height: 14 }} /> Add Programme
            </button>
          </div>
          <div className="card">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Programme Name</th>
                  <th>Business Unit</th>
                  <th>POC 1</th>
                  <th>POC 2</th>
                  <th>Status</th>
                  <th style={{ width: 100 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {state.programmes.map(prog => {
                  const bu = state.businessUnits.find(b => b.id === prog.businessUnitId);
                  const poc1 = state.people.find(p => p.id === prog.poc1Id);
                  const poc2 = state.people.find(p => p.id === prog.poc2Id);
                  return (
                    <tr key={prog.id}>
                      <td><strong>{prog.name}</strong></td>
                      <td>{bu?.name || '—'}</td>
                      <td>{poc1?.name || '—'}</td>
                      <td>{poc2?.name || '—'}</td>
                      <td><span className={`badge ${getStatusColor(prog.status)}`}>{prog.status}</span></td>
                      <td>
                        <div className="action-btns">
                          <button className="btn btn-ghost btn-icon" onClick={() => openEdit('programmes', prog)}>
                            <Icons.edit style={{ width: 14, height: 14 }} />
                          </button>
                          <button className="btn btn-danger btn-icon" onClick={() => handleDelete('programmes', prog.id)}>
                            <Icons.trash style={{ width: 14, height: 14 }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <form onSubmit={handleSave}>
              <div className="modal-header">
                <h3 className="modal-title">{modal.mode === 'add' ? 'Add' : 'Edit'} {modal.type === 'capabilities' ? 'Capability' : modal.type === 'businessUnits' ? 'Business Unit' : 'Programme'}</h3>
                <button type="button" className="btn btn-ghost btn-icon" onClick={() => setModal(null)}>
                  <Icons.close style={{ width: 18, height: 18 }} />
                </button>
              </div>
              <div className="modal-body">
                {modal.type === 'capabilities' && (
                  <>
                    <div className="form-group">
                      <label className="form-label">Name *</label>
                      <input className="form-input" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="e.g. Defence Systems" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Description</label>
                      <textarea className="form-input" value={formData.description || ''} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Brief description..." />
                    </div>
                  </>
                )}
                {modal.type === 'businessUnits' && (
                  <>
                    <div className="form-group">
                      <label className="form-label">Name *</label>
                      <input className="form-input" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="e.g. Land Systems" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Capability *</label>
                      <select className="form-select" required value={formData.capabilityId || ''} onChange={e => setFormData({ ...formData, capabilityId: e.target.value })}>
                        <option value="">Select capability...</option>
                        {state.capabilities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                  </>
                )}
                {modal.type === 'programmes' && (
                  <>
                    <div className="form-group">
                      <label className="form-label">Programme Name *</label>
                      <input className="form-input" required value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="e.g. Main Battle Tank Mk-II" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Business Unit *</label>
                      <select className="form-select" required value={formData.businessUnitId || ''} onChange={e => setFormData({ ...formData, businessUnitId: e.target.value })}>
                        <option value="">Select business unit...</option>
                        {state.businessUnits.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">POC 1 (Primary) *</label>
                      <select className="form-select" required value={formData.poc1Id || ''} onChange={e => setFormData({ ...formData, poc1Id: e.target.value })}>
                        <option value="">Select POC 1...</option>
                        {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">POC 2 (Escalation)</label>
                      <select className="form-select" value={formData.poc2Id || ''} onChange={e => setFormData({ ...formData, poc2Id: e.target.value })}>
                        <option value="">Select POC 2...</option>
                        {state.people.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">Status *</label>
                      <select className="form-select" required value={formData.status || 'active'} onChange={e => setFormData({ ...formData, status: e.target.value })}>
                        <option value="active">Active</option>
                        <option value="planning">Planning</option>
                        <option value="on-hold">On Hold</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">Overview</label>
                      <textarea className="form-input" rows={3} value={formData.overview || ''} onChange={e => setFormData({ ...formData, overview: e.target.value })} placeholder="Programme overview..." />
                    </div>
                  </>
                )}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">
                  <Icons.save style={{ width: 14, height: 14 }} /> {modal.mode === 'add' ? 'Add' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function getStatusColor(status) {
  const map = { active: 'badge-success', planning: 'badge-info', 'on-hold': 'badge-warning', completed: 'badge-neutral' };
  return map[status] || 'badge-neutral';
}
