import React from 'react';
import { Outlet, useParams, useNavigate, NavLink } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/svg/Icons';
import './ProgrammeLayout.css';

const sectionNav = [
  { path: 'overview', icon: 'programme', label: 'Overview' },
  { path: 'milestones', icon: 'milestone', label: 'Milestones' },
  { path: 'weekly-status', icon: 'weekly', label: 'Weekly Status' },
  { path: 'executive-summary', icon: 'summary', label: 'Exec Summary' },
  { path: 'org-chart', icon: 'orgChart', label: 'Org Chart' },
  { path: 'partner-timeline', icon: 'partner', label: 'Partners' },
  { path: 'capex-budget', icon: 'budget', label: 'CAPEX' },
  { path: 'bom', icon: 'bom', label: 'BOM' },
  { path: 'budget', icon: 'budget', label: 'Budget' },
  { path: 'certifications', icon: 'certificate', label: 'Certs' },
  { path: 'bd-pipeline', icon: 'pipeline', label: 'BD Pipeline' },
];

export default function ProgrammeLayout() {
  const { id } = useParams();
  const { state } = useApp();
  const navigate = useNavigate();
  const programme = state.programmes.find(p => p.id === id);

  if (!programme) {
    return (
      <div className="page-content">
        <div className="empty-state">
          <Icons.alert style={{ width: 60, height: 60 }} />
          <h3>Programme not found</h3>
          <p>The programme you're looking for doesn't exist.</p>
          <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => navigate('/')}>
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const bu = state.businessUnits.find(b => b.id === programme.businessUnitId);
  const cap = bu ? state.capabilities.find(c => c.id === bu.capabilityId) : null;

  return (
    <div className="page-content programme-layout">
      <div className="programme-hero animate-slideUp">
        <div className="programme-hero-info">
          <div className="programme-hero-badges">
            {cap && <span className="badge badge-neutral">{cap.name}</span>}
            {bu && <span className="badge badge-info">{bu.name}</span>}
          </div>
          <h1 className="page-title">{programme.name}</h1>
        </div>
        <button className="btn btn-secondary" onClick={() => navigate('/')}>
          <Icons.arrowLeft style={{ width: 14, height: 14 }} /> All Programmes
        </button>
      </div>

      <div className="programme-section-nav">
        {sectionNav.map(item => {
          const Icon = Icons[item.icon];
          return (
            <NavLink
              key={item.path}
              to={`/programmes/${id}/${item.path}`}
              className={({ isActive }) => `prog-nav-link ${isActive ? 'active' : ''}`}
            >
              <Icon style={{ width: 14, height: 14 }} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </div>

      <div className="programme-section-content animate-fadeIn">
        <Outlet context={{ programme, bu, cap }} />
      </div>
    </div>
  );
}
