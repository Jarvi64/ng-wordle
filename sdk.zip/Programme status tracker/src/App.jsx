import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useParams, useLocation } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Dashboard from './pages/Dashboard';
import CEOReview from './pages/CEOReview';
import MasterData from './pages/MasterData';
import People from './pages/People';
import ProgrammeLayout from './pages/ProgrammeLayout';
import ProgrammeOverview from './pages/sections/ProgrammeOverview';
import KeyMilestones from './pages/sections/KeyMilestones';
import WeeklyStatus from './pages/sections/WeeklyStatus';
import ExecutiveSummary from './pages/sections/ExecutiveSummary';
import OrgChart from './pages/sections/OrgChart';
import PartnerTimeline from './pages/sections/PartnerTimeline';
import CapexBudget from './pages/sections/CapexBudget';
import ProgrammeBOM from './pages/sections/ProgrammeBOM';
import ProgrammeBudget from './pages/sections/ProgrammeBudget';
import Certifications from './pages/sections/Certifications';
import BDPipeline from './pages/sections/BDPipeline';

function AppLayout() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const location = useLocation();

  // Extract programme ID from URL path for the sidebar
  const progMatch = location.pathname.match(/\/programmes\/([^/]+)/);
  const activeProgrammeId = progMatch ? progMatch[1] : null;

  return (
    <div className="app-layout">
      <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(p => !p)} activeProgrammeId={activeProgrammeId} />
      <div className={`app-main ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <Header collapsed={sidebarCollapsed} />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/ceo-review" element={<CEOReview />} />
          <Route path="/master-data" element={<MasterData />} />
          <Route path="/people" element={<People />} />
          <Route path="/programmes/:id" element={<ProgrammeLayout />}>
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview" element={<ProgrammeOverview />} />
            <Route path="milestones" element={<KeyMilestones />} />
            <Route path="weekly-status" element={<WeeklyStatus />} />
            <Route path="executive-summary" element={<ExecutiveSummary />} />
            <Route path="org-chart" element={<OrgChart />} />
            <Route path="partner-timeline" element={<PartnerTimeline />} />
            <Route path="capex-budget" element={<CapexBudget />} />
            <Route path="bom" element={<ProgrammeBOM />} />
            <Route path="budget" element={<ProgrammeBudget />} />
            <Route path="certifications" element={<Certifications />} />
            <Route path="bd-pipeline" element={<BDPipeline />} />
          </Route>
        </Routes>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <AppLayout />
      </BrowserRouter>
    </AppProvider>
  );
}
