import { Component, ElementRef, HostListener, QueryList, Renderer2, ViewChild, ViewChildren, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { targetWords, words } from './word';
import { NgClass } from '@angular/common';



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NgClass],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'ng-wordle';
  maxGuesses: number = 7; // Default value, can be changed
  wordLength: number = 5; // Default value, can be changed
  rows = Array.from({ length: this.maxGuesses }, (_, i) => i + 1);
  columns = Array.from({ length: this.wordLength }, (_, i) => i + 1);
  current_row = 1;
  goal = targetWords[Math.floor(Math.random() * targetWords.length)];
  // goal = 'maxim'
  keyboardRows: string[][] = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['Enter', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'Backspace']
  ];

  userInput: string[] = ['', '', '', '', '', ''];
  dictionary: string[] = words;

  renderer = inject(Renderer2);
  @ViewChildren('cellRef') cellRefs?: QueryList<ElementRef>;
  @ViewChildren('keys') keyRefs?: QueryList<ElementRef>;

  @HostListener('window:keydown', ['$event'])
  handleInput(event: KeyboardEvent) {
    // const originalString = 'apple';

    // // Encoding
    // const charCodes = Array.from(originalString).map(char => char.charCodeAt(0));
    // const encodedValue = BigInt(charCodes.join(''));
    // console.log(encodedValue); // Output: 97112112108101n

    // // Decoding
    // const charCodeStrings = encodedValue.toString().split('');
    // const decodedCharCodes = charCodeStrings.map(charCode => parseInt(charCode, 10));
    // const decodedString = String.fromCharCode(...decodedCharCodes);
    // console.log(decodedString); // Output: 'apple'





    const key = event.key.toLowerCase();
    console.log(event);

    if (key.match(/^[a-zA-Z]$/) && this.userInput[this.current_row - 1].length < this.wordLength) {
      this.userInput[this.current_row - 1] += key;
    }
    else if (
      key === 'backspace' &&
      this.userInput[this.current_row - 1].length > 0) {
      this.userInput[this.current_row - 1] = this.userInput[
        this.current_row - 1
      ].slice(0, -1);
    }
    else if (
      key === 'enter' &&
      this.userInput[this.current_row - 1].length == this.wordLength
    ) {
      this.validateWord(this.userInput[this.current_row - 1]);
    }
  }

  // validateWord(word: string) {
  //   if (this.dictionary.includes(word)) {
  //     const colors: string[] = new Array(5).fill('DARK');
  //     const wordArray = word.split('');
  //     const goalArray = this.goal.split('');

  //     // First pass: Mark correct letters
  //     for (let i = 0; i < 5; i++) {
  //       if (goalArray[i] === wordArray[i]) {
  //         colors[i] = "GREEN";
  //         goalArray[i] = '0';

  //       }
  //     }

  //     // Second pass: Mark misplaced letters
  //     for (let i = 0; i < 5; i++) {
  //       if (colors[i] !== "GREEN") {
  //         const index = goalArray.indexOf(wordArray[i]);
  //         if (index !== -1) {
  //           colors[i] = "YELLOW";
  //           goalArray[index] = '0'; // Assign null to the temporary array
  //         }
  //       }
  //     }

  //     let delay = 0;
  //     for (let i = 0; i < 5; i++) {
  //       const cellRef = this.cellRefs?.get(this.current_row * 5 - 5 + i);
  //       setTimeout(() => {
  //         if (colors[i] === "GREEN") {
  //           this.renderer.addClass(cellRef?.nativeElement, 'flip');
  //           this.renderer.addClass(cellRef?.nativeElement, 'correct');
  //           // this.renderer.addClass(this.keyboard?.nativeElement, 'correct');

  //         } else if (colors[i] === "YELLOW") {
  //           this.renderer.addClass(cellRef?.nativeElement, 'flip');
  //           this.renderer.addClass(cellRef?.nativeElement, 'misplaced');
  //         } else {
  //           this.renderer.addClass(cellRef?.nativeElement, 'flip');
  //           this.renderer.addClass(cellRef?.nativeElement, 'incorrect');
  //         }
  //       }, delay);
  //       delay += 250;
  //     }
  //     this.current_row++;
  //   } else {
  //     console.error('not a valid word');
  //   }
  //   }

  validateWord(word: string) {
    if (this.dictionary.includes(word) && word.length === this.wordLength) {
      const colors: string[] = new Array(this.wordLength).fill('DARK');
      const wordArray = word.split('');
      const goalArray = this.goal.split('');

      // First pass: Mark correct letters
      for (let i = 0; i < this.wordLength; i++) {
        if (goalArray[i] === wordArray[i]) {
          colors[i] = "GREEN";
          goalArray[i] = '0';
        }
      }

      // Second pass: Mark misplaced letters
      for (let i = 0; i < this.wordLength; i++) {
        if (colors[i] !== "GREEN") {
          const index = goalArray.indexOf(wordArray[i]);
          if (index !== -1) {
            colors[i] = "YELLOW";
            goalArray[index] = '0';
          }
        }
      }

      let delay = 0;
      for (let i = 0; i < this.wordLength; i++) {
        const cellRef = this.cellRefs?.get(this.current_row * this.wordLength - this.wordLength + i);
        setTimeout(() => {
          if (colors[i] === "GREEN") {
            this.renderer.addClass(cellRef?.nativeElement, 'flip');
            this.renderer.addClass(cellRef?.nativeElement, 'correct');
            const keyIndex = this.keyboardRows.flat().indexOf(wordArray[i].toUpperCase());
            if (keyIndex !== -1 && this.keyRefs) {
              const keyRef = this.keyRefs.get(keyIndex);
              this.renderer.addClass(keyRef?.nativeElement, 'correct');
            }
            // this.renderer.addClass(this.keyboard?.nativeElement, 'correct');

          } else if (colors[i] === "YELLOW") {
            this.renderer.addClass(cellRef?.nativeElement, 'flip');
            this.renderer.addClass(cellRef?.nativeElement, 'misplaced');
            const keyIndex = this.keyboardRows.flat().indexOf(wordArray[i].toUpperCase());
            if (keyIndex !== -1 && this.keyRefs) {
              const keyRef = this.keyRefs.get(keyIndex);
              this.renderer.addClass(keyRef?.nativeElement, 'misplaced');
            }
          } else {
            this.renderer.addClass(cellRef?.nativeElement, 'flip');
            this.renderer.addClass(cellRef?.nativeElement, 'incorrect');
            const keyIndex = this.keyboardRows.flat().indexOf(wordArray[i].toUpperCase());
            if (keyIndex !== -1 && this.keyRefs) {
              const keyRef = this.keyRefs.get(keyIndex);
              this.renderer.addClass(keyRef?.nativeElement, 'incorrect');
            }
          }
        }, delay);
        delay += 250;

      }
      if(word===this.goal){
        console.log('sucess is yours');
      }
      else{
        this.current_row++;
      }
    } else {
      console.error('not a valid word');
    }
  }

  onKeyClick(key: string) {
    this.handleInput(new KeyboardEvent('keydown', { key: key }));
  }

  addGuess(){
    this.maxGuesses++;
    this.rows.push(this.maxGuesses);
  }
}


