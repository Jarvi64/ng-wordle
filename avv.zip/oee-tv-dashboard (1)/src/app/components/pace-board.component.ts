import { Component, input, computed, ChangeDetectionStrategy, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-pace-board',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full flex gap-6">
      <!-- Time Section (Left Column) - Circular SVG Gauge -->
      <div class="w-[28%] bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center relative transition-colors duration-500 overflow-hidden">
        
        <!-- Subtle background pattern -->
        <div class="absolute inset-0 opacity-[0.015] dark:opacity-[0.03]" style="background-image: radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0); background-size: 24px 24px;"></div>

        <!-- Circular Shift Timer SVG -->
        <div class="relative w-full max-w-[340px] 2xl:max-w-[400px] aspect-square z-10">
          <svg viewBox="0 0 200 200" class="w-full h-full">
            <defs>
              <!-- Gradient for the progress arc -->
              <linearGradient id="shiftGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#818cf8" />
                <stop offset="100%" stop-color="#6366f1" />
              </linearGradient>
              <!-- Gradient for remaining arc -->
              <linearGradient id="remainGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#e2e8f0" />
                <stop offset="100%" stop-color="#cbd5e1" />
              </linearGradient>
              <!-- Glow filter -->
              <filter id="glowArc">
                <feGaussianBlur stdDeviation="3" result="blur"/>
                <feMerge>
                  <feMergeNode in="blur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>
            
            <!-- Outer decorative ring -->
            <circle cx="100" cy="100" r="96" class="fill-none stroke-slate-100 dark:stroke-slate-800" stroke-width="1" />
            
            <!-- Tick marks for 8 hours -->
            @for (tick of shiftTicks; track $index) {
              <line 
                [attr.x1]="100 + 82 * tick.cos" 
                [attr.y1]="100 + 82 * tick.sin" 
                [attr.x2]="100 + (tick.major ? 76 : 79) * tick.cos" 
                [attr.y2]="100 + (tick.major ? 76 : 79) * tick.sin" 
                class="stroke-slate-300 dark:stroke-slate-600" 
                [attr.stroke-width]="tick.major ? 2.5 : 1"
                stroke-linecap="round"
              />
              @if (tick.major) {
                <text 
                  [attr.x]="100 + 70 * tick.cos" 
                  [attr.y]="100 + 70 * tick.sin"
                  text-anchor="middle" 
                  dominant-baseline="central"
                  class="fill-slate-400 dark:fill-slate-500 text-[8px] font-bold select-none"
                >{{ tick.label }}</text>
              }
            }

            <!-- Background track -->
            <circle cx="100" cy="100" r="85" class="fill-none stroke-slate-100 dark:stroke-slate-800" stroke-width="14" stroke-linecap="round" />
            
            <!-- Progress arc (elapsed) -->
            <circle cx="100" cy="100" r="85" 
                    fill="none"  
                    stroke="url(#shiftGrad)" 
                    stroke-width="14" 
                    stroke-linecap="round"
                    [attr.stroke-dasharray]="circumference()"
                    [attr.stroke-dashoffset]="progressOffset()"
                    style="transform: rotate(-90deg); transform-origin: center;"
                    filter="url(#glowArc)"
            />

            <!-- Progress end dot -->
            <circle [attr.cx]="progressDotX()" [attr.cy]="progressDotY()" r="9"
                    class="fill-indigo-500 stroke-white dark:stroke-slate-900" stroke-width="3" />

            <!-- Center content -->
            <!-- Shift Name Badge -->
            <rect x="72" y="52" width="56" height="22" rx="11" class="fill-indigo-100 dark:fill-indigo-900/60" />
            <text x="100" y="64" text-anchor="middle" dominant-baseline="central" class="fill-indigo-600 dark:fill-indigo-400 text-[11px] font-black uppercase select-none">Shift {{ shiftName() }}</text>

            <!-- Digital Clock -->
            <text x="100" y="94" text-anchor="middle" dominant-baseline="central" class="fill-slate-900 dark:fill-white text-[28px] font-black select-none" style="font-family: ui-monospace, monospace; letter-spacing: -1px;">
              {{ time() | date:'HH:mm' }}
            </text>
            <text x="100" y="114" text-anchor="middle" dominant-baseline="central" class="fill-indigo-500 dark:fill-indigo-400 text-[14px] font-bold select-none" style="font-family: ui-monospace, monospace;">
              :{{ time() | date:'ss' }}
            </text>
            
            <!-- Progress percentage -->
            <text x="100" y="140" text-anchor="middle" dominant-baseline="central" class="fill-slate-400 dark:fill-slate-500 text-[10px] font-bold uppercase select-none tracking-widest">
              {{ shiftProgress() | number:'1.0-0' }}% Complete
            </text>
          </svg>
        </div>

        <!-- Elapsed / Remaining Blocks -->
        <div class="w-full grid grid-cols-2 gap-4 mt-4 z-10">
          <div class="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 text-center">
            <div class="flex items-center justify-center gap-1.5 mb-1.5">
              <svg class="w-4 h-4 text-emerald-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/>
                <polyline points="16 7 22 7 22 13"/>
              </svg>
              <span class="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Elapsed</span>
            </div>
            <div class="text-3xl 2xl:text-4xl font-mono font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{{ formatElapsed() }}</div>
          </div>
          <div class="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 text-center">
            <div class="flex items-center justify-center gap-1.5 mb-1.5">
              <svg class="w-4 h-4 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
              </svg>
              <span class="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Remaining</span>
            </div>
            <div class="text-3xl 2xl:text-4xl font-mono font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{{ formatRemaining() }}</div>
          </div>
        </div>
      </div>

      <!-- Right Section (Pace) -->
      <div class="w-[72%] flex flex-col">
        <!-- Pace Master Block -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl p-10 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col flex-1 relative overflow-hidden transition-colors duration-500">
          <!-- Big watermark status -->
          <div class="absolute -bottom-16 -right-10 text-[16rem] font-black opacity-[0.02] dark:opacity-[0.04] leading-none pointer-events-none uppercase whitespace-nowrap select-none">
            {{ isAhead() ? 'AHEAD' : 'BEHIND' }}
          </div>

          <!-- Header Row -->
          <div class="flex justify-between items-start mb-6 z-10 w-full relative">
            <h2 class="text-3xl font-bold text-slate-700 dark:text-slate-200 tracking-tight uppercase">Production Pace</h2>
            
            <!-- Delta Badge -->
            <div class="flex items-center gap-4 px-8 py-4 rounded-3xl border-2 shadow-sm" [class.bg-emerald-50]="isAhead()" [class.border-emerald-100]="isAhead()" [class.dark:bg-emerald-900/40]="isAhead()" [class.dark:border-emerald-800/50]="isAhead()" [class.bg-rose-50]="!isAhead()" [class.border-rose-100]="!isAhead()" [class.dark:bg-rose-900/40]="!isAhead()" [class.dark:border-rose-800/50]="!isAhead()">
              <div class="text-4xl 2xl:text-5xl font-black tabular-nums tracking-tighter" [class.text-emerald-700]="isAhead()" [class.dark:text-emerald-400]="isAhead()" [class.text-rose-700]="!isAhead()" [class.dark:text-rose-400]="!isAhead()">
                 {{ isAhead() ? '+' : '' }}{{ (actual() - idealProduction()) | number }}
                 <span class="text-xl 2xl:text-2xl font-bold uppercase tracking-widest opacity-80 ml-2">Delta</span>
              </div>
              <div class="w-12 h-12 2xl:w-14 2xl:h-14 rounded-full flex items-center justify-center shrink-0 ml-4" [class.bg-emerald-200]="isAhead()" [class.dark:bg-emerald-800]="isAhead()" [class.bg-rose-200]="!isAhead()" [class.dark:bg-rose-800]="!isAhead()">
                <svg class="w-8 h-8 2xl:w-10 2xl:h-10" [class.text-emerald-700]="isAhead()" [class.dark:text-emerald-300]="isAhead()" [class.text-rose-700]="!isAhead()" [class.dark:text-rose-300]="!isAhead()" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  @if (isAhead()) {
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  } @else {
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  }
                </svg>
              </div>
            </div>
          </div>

          <!-- 3 Bars Section -->
          <div class="flex-1 flex flex-col justify-center gap-8 z-10">

            <!-- Bar 1: SHIFT TARGET (ppm * 480) -->
            <div>
              <div class="flex justify-between items-end mb-3">
                <div class="flex items-center gap-3">
                  <div class="w-5 h-5 rounded-md bg-indigo-500"></div>
                  <span class="text-2xl font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider">Shift Target</span>
                  <span class="text-lg text-slate-400 dark:text-slate-500 font-medium ml-2">(PPM × 480 min)</span>
                </div>
                <div class="text-5xl 2xl:text-6xl font-mono font-black text-indigo-600 dark:text-indigo-400 tabular-nums tracking-tighter">{{ shiftTarget() | number }}</div>
              </div>
              <div class="relative h-16 2xl:h-20 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-inner">
                <div class="absolute left-0 top-0 h-full bg-indigo-500 rounded-2xl transition-all duration-1000 ease-out" [style.width.%]="barWidthTarget()">
                  <div class="absolute inset-0 opacity-10" style="background-image: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%);"></div>
                </div>
              </div>
            </div>

            <!-- Bar 2: IDEAL (runtime * ppm) -->
            <div>
              <div class="flex justify-between items-end mb-3">
                <div class="flex items-center gap-3">
                  <div class="w-5 h-5 rounded-md bg-slate-500 dark:bg-slate-400"></div>
                  <span class="text-2xl font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider">Ideal</span>
                  <span class="text-lg text-slate-400 dark:text-slate-500 font-medium ml-2">(PPM × Run Time)</span>
                </div>
                <div class="text-5xl 2xl:text-6xl font-mono font-black text-slate-600 dark:text-slate-300 tabular-nums tracking-tighter">{{ idealProduction() | number }}</div>
              </div>
              <div class="relative h-16 2xl:h-20 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-inner">
                <div class="absolute left-0 top-0 h-full bg-slate-400 dark:bg-slate-500 rounded-2xl transition-all duration-1000 ease-out" [style.width.%]="barWidthIdeal()">
                  <div class="absolute inset-0 opacity-10" style="background-image: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%);"></div>
                </div>
              </div>
            </div>

            <!-- Bar 3: ACTUAL -->
            <div>
              <div class="flex justify-between items-end mb-3">
                <div class="flex items-center gap-3">
                  <div class="w-5 h-5 rounded-md" [class.bg-emerald-500]="isAhead()" [class.bg-rose-500]="!isAhead()"></div>
                  <span class="text-2xl font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider">Actual</span>
                  <span class="text-lg text-slate-400 dark:text-slate-500 font-medium ml-2">(OK Parts)</span>
                </div>
                <div class="text-5xl 2xl:text-6xl font-mono font-black tabular-nums tracking-tighter" [class.text-emerald-600]="isAhead()" [class.dark:text-emerald-400]="isAhead()" [class.text-rose-600]="!isAhead()" [class.dark:text-rose-400]="!isAhead()">{{ actual() | number }}</div>
              </div>
              <div class="relative h-16 2xl:h-20 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-inner">
                <div class="absolute left-0 top-0 h-full rounded-2xl transition-all duration-1000 ease-out" [style.width.%]="barWidthActual()" [class.bg-emerald-500]="isAhead()" [class.bg-rose-500]="!isAhead()">
                  <div class="absolute inset-0 opacity-20 overflow-hidden rounded-2xl" style="background-image: linear-gradient(45deg, rgba(255,255,255,0.2) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0.2) 75%, transparent 75%, transparent); background-size: 2rem 2rem;"></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  `
})
export class PaceBoardComponent implements OnDestroy {
  target = input.required<number>();
  actual = input.required<number>();
  nokQty = input.required<number>();
  ppm = input.required<number>();
  runTime = input.required<number>();
  
  time = signal<Date>(new Date());
  private timer: ReturnType<typeof setInterval>;

  constructor() {
    this.timer = setInterval(() => {
      this.time.set(new Date());
    }, 1000);
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }

  // SVG circular gauge constants
  private readonly radius = 85;
  circumference = computed(() => 2 * Math.PI * this.radius);

  // Shift tick marks (every 30 minutes = 16 ticks for 8 hours)
  shiftTicks = Array.from({ length: 17 }).map((_, i) => {
    // Map 0-16 ticks to 270deg arc starting from top (-90deg)
    const angle = (-90 + (i / 16) * 360) * (Math.PI / 180);
    return {
      cos: Math.cos(angle),
      sin: Math.sin(angle),
      major: i % 2 === 0,  // Every hour is major
      label: `${i / 2}h`
    };
  });

  shiftInfo = computed(() => {
    const now = this.time();
    const hours = now.getHours();
    const mins = now.getMinutes();
    const secs = now.getSeconds();
    
    let shiftStartHour = 6;
    let shiftName = 'A';
    if (hours >= 14 && hours < 22) {
      shiftStartHour = 14;
      shiftName = 'B';
    } else if (hours >= 22 || hours < 6) {
      shiftStartHour = 22;
      shiftName = 'C';
    }
    
    let elapsedMins = 0;
    if (shiftStartHour === 22 && hours < 6) {
      elapsedMins = ((hours + 24) - 22) * 60 + mins + secs/60;
    } else {
      elapsedMins = (hours - shiftStartHour) * 60 + mins + secs/60;
    }
    
    const progress = Math.min(100, Math.max(0, (elapsedMins / 480) * 100));
    
    return { shiftName, progress, elapsedMins, shiftStartHour };
  });

  shiftName = computed(() => this.shiftInfo().shiftName);
  shiftProgress = computed(() => this.shiftInfo().progress);
  
  // SVG arc progress
  progressOffset = computed(() => {
    const c = this.circumference();
    return c - (this.shiftProgress() / 100) * c;
  });

  // Dot at the end of the progress arc
  progressDotX = computed(() => {
    const angle = (-90 + (this.shiftProgress() / 100) * 360) * (Math.PI / 180);
    return 100 + this.radius * Math.cos(angle);
  });
  progressDotY = computed(() => {
    const angle = (-90 + (this.shiftProgress() / 100) * 360) * (Math.PI / 180);
    return 100 + this.radius * Math.sin(angle);
  });

  formatElapsed = computed(() => {
    const totalMins = Math.floor(this.shiftInfo().elapsedMins);
    const hrs = Math.floor(totalMins / 60);
    const mins = totalMins % 60;
    return `${hrs.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m`;
  });

  formatRemaining = computed(() => {
    const elapsedMins = Math.floor(this.shiftInfo().elapsedMins);
    const totalShiftMins = 480;
    const remainingMins = Math.max(0, totalShiftMins - elapsedMins);
    const hrs = Math.floor(remainingMins / 60);
    const mins = remainingMins % 60;
    return `${hrs.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m`;
  });

  shiftTarget = computed(() => {
    return Math.round(this.ppm() * 480);
  });

  idealProduction = computed(() => {
    return Math.round(this.ppm() * this.runTime());
  });

  isAhead = computed(() => {
    return this.actual() >= this.idealProduction();
  });

  // All 3 bars are relative to the max of the three values
  private maxValue = computed(() => {
    return Math.max(this.shiftTarget(), this.idealProduction(), this.actual(), 1);
  });

  barWidthTarget = computed(() => {
    return Math.min(100, (this.shiftTarget() / this.maxValue()) * 100);
  });

  barWidthIdeal = computed(() => {
    return Math.min(100, (this.idealProduction() / this.maxValue()) * 100);
  });

  barWidthActual = computed(() => {
    return Math.min(100, (this.actual() / this.maxValue()) * 100);
  });
}
