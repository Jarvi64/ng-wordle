import { useParams, Link, Navigate } from "react-router-dom";
import { useAppStore } from "@/lib/store";
import { ChevronRight } from "lucide-react";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { NoiseBackground } from "@/components/ui/noise-background";

import { WeeklyUpdatesTab } from "./programme/WeeklyUpdatesTab";
import { OrganisationTab } from "./programme/OrganisationTab";
import { MilestonesTab } from "./programme/MilestonesTab";
import { SupportRequiredTab } from "./programme/SupportRequiredTab";
import { DateChangeLogsTab } from "./programme/DateChangeLogsTab";
import { PartnerDeliverablesTab } from "./programme/PartnerDeliverablesTab";
import { BudgetTab } from "./programme/BudgetTab";
import { CertificationsTab } from "./programme/CertificationsTab";
import { SupplyChainReadinessTab } from "./programme/SupplyChainReadinessTab";

export function ProgrammeDetail() {
  const { id } = useParams<{ id: string }>();
  const { programmes, businessUnits, users, dateChangeLogs } = useAppStore();

  const programme = programmes.find((p) => p.programmeid === id);
  if (!programme) return <Navigate to="/programmes" replace />;

  const programmeId = programme.programmeid;

  const buName =
    businessUnits.find((b) => b.businessunitid === programme.businessid)
      ?.name || "—";
  const poc1 =
    users.find((u) => u.userid === programme.poc1userid)?.name || "—";

  // Check if there are recent date change logs (last 7 days)
  const recentLogs = dateChangeLogs.filter((l) => {
    if (l.programmeid !== programme.programmeid) return false;
    const changed = new Date(l.changedon);
    const sevenDaysAgo = new Date(Date.now() - 7 * 86400000);
    return changed >= sevenDaysAgo;
  });

  return (
    <div className="flex flex-col gap-6">
      {/* Breadcrumb + Header */}
      <div>
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-2">
          <Link
            to="/programmes"
            className="hover:text-foreground transition-colors"
          >
            Programmes
          </Link>
          <ChevronRight className="size-3.5" />
          <span className="text-foreground font-medium">{programme.name}</span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-foreground">
              {programme.name}
            </h2>
            <div className="flex items-center gap-3 mt-1.5">
              <Badge variant="secondary">{buName}</Badge>
              <span className="text-sm text-muted-foreground">
                POC: {poc1}
              </span>
              <Badge variant="secondary">{programme.lastreportingweek}</Badge>
            </div>
          </div>
          <div className="flex items-center">
            <NoiseBackground
              containerClassName="w-fit p-1 rounded-full mx-auto"
              gradientColors={[
                "rgb(255, 100, 150)",
                "rgb(100, 150, 255)",
                "rgb(255, 200, 100)",
              ]}
            >
              <button className="h-full w-full cursor-pointer rounded-full bg-linear-to-r from-neutral-100 via-neutral-100 to-white px-4 py-2 text-sm font-medium text-black shadow-[0px_2px_0px_0px_var(--color-neutral-50)_inset,0px_0.5px_1px_0px_var(--color-neutral-400)] transition-all duration-100 active:scale-98 dark:from-black dark:via-black dark:to-neutral-900 dark:text-white dark:shadow-[0px_1px_0px_0px_var(--color-neutral-950)_inset,0px_1px_0px_0px_var(--color-neutral-800)]">
                Start publishing &rarr;
              </button>
            </NoiseBackground>
          </div>
        </div>
        {programme.notes && (
          <p className="text-muted-foreground text-sm mt-2 max-w-2xl">
            {programme.notes}
          </p>
        )}
      </div>

      {/* Tab Layout */}
      <Tabs defaultValue="weekly" className="w-full">
        <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent gap-6 overflow-x-auto overflow-y-hidden [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <TabsTrigger value="weekly" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Weekly Updates</TabsTrigger>
          <TabsTrigger value="organisation" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Org Chart</TabsTrigger>
          <TabsTrigger value="milestones" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Milestones</TabsTrigger>
          <TabsTrigger value="partner" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Partner & ToT</TabsTrigger>
          <TabsTrigger value="budget" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Budget (Capex/Opex)</TabsTrigger>
          <TabsTrigger value="certifications" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Certifications</TabsTrigger>
          <TabsTrigger value="supplychain" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Supply Chain</TabsTrigger>
          <TabsTrigger value="support" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">Support</TabsTrigger>
          <TabsTrigger value="datechangelogs" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-2 py-3">
            Date Change Logs
            {recentLogs.length > 0 && (
              <Badge
                variant="destructive"
                className="ml-1.5 px-1.5 py-0 text-[10px] leading-4 min-w-0"
              >
                {recentLogs.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="weekly" className="m-0 focus-visible:outline-none mt-6">
          <WeeklyUpdatesTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="organisation" className="m-0 focus-visible:outline-none mt-6">
          <OrganisationTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="milestones" className="m-0 focus-visible:outline-none mt-6">
          <MilestonesTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="partner" className="m-0 focus-visible:outline-none mt-6">
          <PartnerDeliverablesTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="budget" className="m-0 focus-visible:outline-none mt-6">
          <BudgetTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="certifications" className="m-0 focus-visible:outline-none mt-6">
          <CertificationsTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="supplychain" className="m-0 focus-visible:outline-none mt-6">
          <SupplyChainReadinessTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="support" className="m-0 focus-visible:outline-none mt-6">
          <SupportRequiredTab programmeId={programmeId} />
        </TabsContent>
        <TabsContent value="datechangelogs" className="m-0 focus-visible:outline-none mt-6">
          <DateChangeLogsTab programmeId={programmeId} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
