
import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Layers, Briefcase, LayoutGrid, GanttChartSquare, Eye } from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar";

const MOCK_USER = {
  name: "Alice Smith",
  email: "alice@example.com",
};

const NAV_ITEMS = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Capabilities", url: "/capabilities", icon: Layers },
  { title: "Business Units", url: "/business-units", icon: Briefcase },
  { title: "Programmes", url: "/programmes", icon: LayoutGrid },
  { title: "Gantt Chart", url: "/gantt", icon: GanttChartSquare },
  { title: "CEO Review", url: "/ceo-review", icon: Eye },
];

export function AppSidebar() {
  const location = useLocation();

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      <SidebarHeader className="pb-3">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" className="hover:bg-transparent hover:cursor-default px-2">
              {/* Adani Defence logo */}
              <img
                src="https://www.adanidefence.com/-/media/Project/Defence/images/mainlogo.png"
                alt="Logo"
                className="h-8 w-auto shrink-0 object-contain brightness-0 invert"
              />
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarSeparator />

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {NAV_ITEMS.map((item) => {
                const isActive =
                  item.url === "/"
                    ? location.pathname === "/"
                    : location.pathname === item.url || location.pathname.startsWith(item.url + "/");
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive} tooltip={item.title}>
                      <Link to={item.url}>
                        <item.icon />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
         <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary">
                <span className="text-xs font-medium">{MOCK_USER.name.charAt(0)}</span>
              </div>
              <div className="flex flex-col overflow-hidden leading-none">
                <span className="truncate text-sm font-medium">{MOCK_USER.name}</span>
                <span className="truncate text-xs text-muted-foreground">{MOCK_USER.email}</span>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
