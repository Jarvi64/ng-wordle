import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppSidebar } from "./AppSidebar";
import { motion, AnimatePresence } from "framer-motion";
import { Toaster } from "@/components/ui/sonner";

export function AppLayout() {
  const location = useLocation();

  return (
    <TooltipProvider>
      <SidebarProvider>
        <AppSidebar />
        
        <div className="flex min-h-screen flex-col w-full bg-background transition-all">
          <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60 w-full">
            <SidebarTrigger />
            <div className="flex flex-1 items-center gap-4">
              <h1 className="text-sm font-semibold sm:text-base text-foreground tracking-tight">Programme Tracker</h1>
            </div>
          </header>
          
          <main className="flex-1 overflow-x-hidden p-6 w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2, ease: "easeOut" }}
                className="h-full max-w-[1400px] mx-auto w-full"
              >
                <Outlet />
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
        
        <Toaster position="bottom-right" richColors theme="light" />
      </SidebarProvider>
    </TooltipProvider>
  );
}
