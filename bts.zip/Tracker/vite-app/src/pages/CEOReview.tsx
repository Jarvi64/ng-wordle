import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { useAppStore } from "@/lib/store";
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  DollarSign,
  Eye,
  Flag,
  LayoutGrid,
  Package,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// ── Types ──────────────────────────────────────────────────────
type Health = "On Track" | "In Progress" | "Delayed" | "At Risk" | "No Data";

// ── Health helpers ─────────────────────────────────────────────
const HEALTH_CONFIG: Record<Health, { badge: string; dot: string; bar: string }> = {
  "At Risk":    { badge: "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300",       dot: "#ef4444", bar: "#ef4444" },
  "Delayed":    { badge: "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300", dot: "#f59e0b", bar: "#f59e0b" },
  "In Progress":{ badge: "bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300",    dot: "#0874B0", bar: "#0874B0" },
  "On Track":   { badge: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300", dot: "#10b981", bar: "#10b981" },
  "No Data":    { badge: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400",   dot: "#94a3b8", bar: "#94a3b8" },
};

function getHealth(statuses: string[]): Health {
  if (statuses.length === 0) return "No Data";
  if (statuses.includes("At Risk")) return "At Risk";
  if (statuses.includes("Delayed")) return "Delayed";
  if (statuses.every((s) => s === "Completed" || s === "Approved")) return "On Track";
  if (statuses.includes("In Progress") || statuses.includes("In Review")) return "In Progress";
  return "No Data";
}

function HealthBadge({ health }: { health: Health }) {
  const cfg = HEALTH_CONFIG[health];
  return (
    <Badge className={`${cfg.badge} text-xs font-semibold px-2 py-0.5`}>
      <span className="size-1.5 rounded-full mr-1.5 inline-block" style={{ background: cfg.dot }} />
      {health}
    </Badge>
  );
}

// ── Accordion row ─────────────────────────────────────────────
function AccordionRow({
  open,
  onToggle,
  left,
  right,
  children,
  indent = 0,
  variant = "default",
}: {
  open: boolean;
  onToggle: () => void;
  left: React.ReactNode;
  right: React.ReactNode;
  children: React.ReactNode;
  indent?: number;
  variant?: "default" | "bu" | "capability";
}) {
  const bgClass =
    variant === "capability"
      ? "bg-muted/60 hover:bg-muted/80 border-b"
      : variant === "bu"
      ? "bg-muted/30 hover:bg-muted/50 border-b"
      : "hover:bg-muted/20 border-b";

  return (
    <div style={{ marginLeft: indent }}>
      <button
        onClick={onToggle}
        className={`w-full flex items-center gap-3 px-4 py-3 transition-colors text-left ${bgClass}`}
      >
        <ChevronDown
          className={`size-4 shrink-0 text-muted-foreground transition-transform duration-200 ${open ? "" : "-rotate-90"}`}
        />
        <div className="flex-1 min-w-0">{left}</div>
        <div className="flex items-center gap-3 shrink-0">{right}</div>
      </button>
      {open && <div className="animate-in fade-in slide-in-from-top-1 duration-150">{children}</div>}
    </div>
  );
}

// ── Mini stat chip ─────────────────────────────────────────────
function MiniStat({ icon: Icon, value, color }: { icon: React.ElementType; value: string | number; color: string }) {
  return (
    <div className="flex items-center gap-1 text-xs">
      <Icon className="size-3" style={{ color }} />
      <span className="font-semibold">{value}</span>
    </div>
  );
}

// ── Programme card ─────────────────────────────────────────────
function ProgrammeCard({ prog, health }: { prog: ReturnType<typeof useAppStore.getState>["programmes"][0]; health: Health }) {
  const { milestones, certifications, supportRequired, capexBudgets, dateChangeLogs, users } = useAppStore();
  const pid = prog.programmeid;

  const pMilestones = milestones.filter((m) => m.programmeid === pid);
  const completedMs = pMilestones.filter((m) => m.status === "Completed").length;
  const atRiskMs = pMilestones.filter((m) => m.status === "At Risk" || m.status === "Delayed").length;
  const msCompletion = pMilestones.length > 0 ? Math.round((completedMs / pMilestones.length) * 100) : 0;

  const openSupport = supportRequired.filter((s) => s.programmeid === pid && s.status !== "Closed" && s.status !== "Resolved").length;
  const criticalSupport = supportRequired.filter((s) => s.programmeid === pid && s.criticality === "Critical" && s.status !== "Closed").length;

  const certCount = certifications.filter((c) => c.programmeid === pid).length;
  const certApproved = certifications.filter((c) => c.programmeid === pid && c.status === "Approved").length;

  const totalBudget = capexBudgets.filter((c) => c.programmeid === pid).reduce((a, c) => a + c.budgetcr, 0);
  const totalActual = capexBudgets.filter((c) => c.programmeid === pid).reduce((a, c) => a + c.actualcr, 0);
  const variance = totalBudget - totalActual;

  const recentChanges = dateChangeLogs.filter(
    (l) => l.programmeid === pid && new Date(l.changedon) >= new Date(Date.now() - 7 * 86400000)
  ).length;

  const poc1Name = users.find((u) => u.userid === prog.poc1userid)?.name ?? "—";
  const poc2Name = users.find((u) => u.userid === prog.poc2userid)?.name ?? "—";

  const cfg = HEALTH_CONFIG[health];

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow border-l-4" style={{ borderLeftColor: cfg.dot }}>
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <Link
              to={`/programmes/${pid}`}
              className="text-sm font-bold hover:text-primary transition-colors truncate block"
            >
              {prog.name}
            </Link>
            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
              <span className="text-[10px] text-muted-foreground">POC: {poc1Name}</span>
              {poc2Name !== "—" && <span className="text-[10px] text-muted-foreground">· {poc2Name}</span>}
              <span className="text-[10px] text-muted-foreground">{prog.lastreportingweek}</span>
            </div>
          </div>
          <HealthBadge health={health} />
        </div>
      </CardHeader>
      <CardContent className="px-4 pb-3 space-y-2.5">
        {/* Milestone progress */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-muted-foreground font-medium">Milestone Progress</span>
            <span className="text-[10px] font-bold">{completedMs}/{pMilestones.length} · {msCompletion}%</span>
          </div>
          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full rounded-full transition-all"
              style={{ width: `${msCompletion}%`, background: cfg.bar }}
            />
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          <MiniStat icon={AlertTriangle} value={`${atRiskMs} at risk`} color={atRiskMs > 0 ? "#ef4444" : "#94a3b8"} />
          <MiniStat icon={Zap} value={`${openSupport} support${criticalSupport > 0 ? ` (${criticalSupport} crit)` : ""}`} color={criticalSupport > 0 ? "#BD3661" : openSupport > 0 ? "#f59e0b" : "#94a3b8"} />
          <MiniStat icon={ShieldCheck} value={`${certApproved}/${certCount} certs`} color="#75679C" />
          <MiniStat icon={Clock} value={`${recentChanges} date changes`} color={recentChanges > 0 ? "#f59e0b" : "#94a3b8"} />
        </div>

        {/* CAPEX row */}
        {totalBudget > 0 && (
          <div className="flex items-center justify-between rounded-md bg-muted/40 px-2.5 py-1.5">
            <div className="flex items-center gap-1.5">
              <DollarSign className="size-3 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground">CAPEX</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[10px]">Budget: <strong>{totalBudget.toFixed(1)} CR</strong></span>
              <span className={`text-[10px] flex items-center gap-0.5 font-semibold ${variance >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                {variance >= 0 ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
                {variance >= 0 ? "+" : ""}{variance.toFixed(1)} CR
              </span>
            </div>
          </div>
        )}

        <Link
          to={`/programmes/${pid}`}
          className="flex items-center gap-1 text-[10px] font-medium text-primary hover:underline"
        >
          View full detail <ChevronRight className="size-3" />
        </Link>
      </CardContent>
    </Card>
  );
}

// ── Main CEO Review page ───────────────────────────────────────
export function CEOReview() {
  const {
    capabilities,
    businessUnits,
    programmes,
    milestones,
    certifications,
    supportRequired,
    dateChangeLogs,
    capexBudgets,
  } = useAppStore();

  // Expand state: track open cap/bu by ID
  const [openCaps, setOpenCaps] = useState<Record<string, boolean>>({});
  const [openBUs, setOpenBUs] = useState<Record<string, boolean>>({});

  const toggleCap = (id: string) => setOpenCaps((p) => ({ ...p, [id]: !p[id] }));
  const toggleBU = (id: string) => setOpenBUs((p) => ({ ...p, [id]: !p[id] }));

  const today = new Date();
  const sevenDaysAgo = new Date(today.getTime() - 7 * 86400000);

  // ── Global summary ──
  const totalMilestones = milestones.length;
  const atRiskMs = milestones.filter((m) => m.status === "At Risk" || m.status === "Delayed").length;
  const completedMs = milestones.filter((m) => m.status === "Completed").length;
  const msCompletion = totalMilestones > 0 ? Math.round((completedMs / totalMilestones) * 100) : 0;
  const openSupport = supportRequired.filter((s) => s.status !== "Closed" && s.status !== "Resolved").length;
  const criticalSupport = supportRequired.filter((s) => s.criticality === "Critical" && s.status !== "Closed").length;
  const recentDateChanges = dateChangeLogs.filter((l) => new Date(l.changedon) >= sevenDaysAgo).length;
  const totalCapex = capexBudgets.reduce((a, c) => a + c.budgetcr, 0);
  const totalActual = capexBudgets.reduce((a, c) => a + c.actualcr, 0);
  const capexVariance = totalCapex - totalActual;

  // ── Per-programme health ──
  const progHealth = useMemo(() => {
    const map: Record<string, Health> = {};
    programmes.forEach((p) => {
      const statuses = [
        ...milestones.filter((m) => m.programmeid === p.programmeid).map((m) => m.status),
        ...certifications.filter((c) => c.programmeid === p.programmeid).map((c) => c.status),
      ];
      map[p.programmeid] = getHealth(statuses);
    });
    return map;
  }, [programmes, milestones, certifications]);

  // ── Per-BU health ──
  const buHealth = useMemo(() => {
    const map: Record<string, Health> = {};
    businessUnits.forEach((bu) => {
      const buProgs = programmes.filter((p) => p.businessid === bu.businessunitid);
      const h = buProgs.map((p) => progHealth[p.programmeid] ?? "No Data");
      map[bu.businessunitid] = getHealth(
        h.includes("At Risk") ? ["At Risk"] :
        h.includes("Delayed") ? ["Delayed"] :
        h.every((x) => x === "On Track") ? ["Completed"] :
        h.includes("In Progress") ? ["In Progress"] : []
      );
    });
    return map;
  }, [businessUnits, programmes, progHealth]);

  // ── Per-capability health ──
  const capHealth = useMemo(() => {
    const map: Record<string, Health> = {};
    capabilities.forEach((cap) => {
      const capBUs = businessUnits.filter((b) => b.capabilityid === cap.capabilityid);
      const h = capBUs.map((b) => buHealth[b.businessunitid] ?? "No Data");
      map[cap.capabilityid] = getHealth(
        h.includes("At Risk") ? ["At Risk"] :
        h.includes("Delayed") ? ["Delayed"] :
        h.every((x) => x === "On Track") ? ["Completed"] :
        h.includes("In Progress") ? ["In Progress"] : []
      );
    });
    return map;
  }, [capabilities, businessUnits, buHealth]);

  // Health breakdown for summary donut-like stat
  const healthCounts = useMemo(() => {
    const counts: Record<Health, number> = { "On Track": 0, "In Progress": 0, "Delayed": 0, "At Risk": 0, "No Data": 0 };
    programmes.forEach((p) => counts[progHealth[p.programmeid]]++);
    return counts;
  }, [programmes, progHealth]);

  return (
    <div className="space-y-6 pb-10">
      {/* ── Page header ── */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2.5">
            <Eye className="size-7 text-primary" />
            CEO Review
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Organisation-wide programme health — Capability → Business Unit → Programme
          </p>
        </div>
      </div>

      {/* ── Global summary strip ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: "Programmes", value: programmes.length, icon: LayoutGrid, color: "#0874B0" },
          { label: "Milestones", value: `${msCompletion}%`, icon: Flag, color: "#10b981", sub: `${completedMs}/${totalMilestones} done` },
          { label: "At Risk", value: atRiskMs, icon: AlertTriangle, color: atRiskMs > 0 ? "#ef4444" : "#10b981" },
          { label: "Critical Support", value: criticalSupport, icon: Zap, color: criticalSupport > 0 ? "#BD3661" : "#10b981" },
          { label: "Date Changes (7d)", value: recentDateChanges, icon: Clock, color: "#75679C" },
          { label: "CAPEX Variance", value: `${capexVariance >= 0 ? "+" : ""}${capexVariance.toFixed(1)} CR`, icon: DollarSign, color: capexVariance >= 0 ? "#10b981" : "#ef4444" },
        ].map((s) => (
          <Card key={s.label} className="relative overflow-hidden">
            <div className="absolute inset-0 opacity-[0.04]" style={{ background: `radial-gradient(circle at top right, ${s.color}, transparent 70%)` }} />
            <CardContent className="pt-3 pb-3 px-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">{s.label}</span>
                <s.icon className="size-3.5" style={{ color: s.color }} />
              </div>
              <div className="text-xl font-bold" style={{ color: s.color }}>{s.value}</div>
              {s.sub && <p className="text-[10px] text-muted-foreground">{s.sub}</p>}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Programme health breakdown ── */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <BarChart3 className="size-4 text-primary" />
            Programme Health Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3 flex-wrap">
            {(["On Track", "In Progress", "Delayed", "At Risk", "No Data"] as Health[]).map((h) => {
              const cfg = HEALTH_CONFIG[h];
              const count = healthCounts[h];
              const pct = programmes.length > 0 ? Math.round((count / programmes.length) * 100) : 0;
              return (
                <div key={h} className="flex items-center gap-2 flex-1 min-w-28">
                  <div className="size-2.5 rounded-full shrink-0" style={{ background: cfg.dot }} />
                  <div className="flex-1">
                    <div className="flex items-center justify-between text-xs mb-0.5">
                      <span className="text-muted-foreground">{h}</span>
                      <span className="font-bold">{count}</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${pct}%`, background: cfg.bar }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Three-level accordion ── */}
      <Card className="overflow-hidden p-0">
        <CardHeader className="px-4 py-3 border-b bg-muted/20">
          <CardTitle className="text-sm font-semibold">Organisational Hierarchy</CardTitle>
        </CardHeader>
        <div>
          {capabilities.length === 0 && (
            <div className="text-center py-12 text-muted-foreground text-sm">No capabilities found.</div>
          )}
          {capabilities.map((cap) => {
            const capBUs = businessUnits.filter((b) => b.capabilityid === cap.capabilityid);
            const capProgs = programmes.filter((p) => capBUs.some((b) => b.businessunitid === p.businessid));
            const capAtRisk = capProgs.filter((p) => progHealth[p.programmeid] === "At Risk").length;
            const capDelayed = capProgs.filter((p) => progHealth[p.programmeid] === "Delayed").length;
            const isCOpen = !!openCaps[cap.capabilityid];

            return (
              <AccordionRow
                key={cap.capabilityid}
                open={isCOpen}
                onToggle={() => toggleCap(cap.capabilityid)}
                variant="capability"
                left={
                  <div className="flex items-center gap-3">
                    <LayoutGrid className="size-4 text-primary shrink-0" />
                    <div>
                      <p className="text-sm font-bold">{cap.name}</p>
                      {cap.description && (
                        <p className="text-[11px] text-muted-foreground">{cap.description}</p>
                      )}
                    </div>
                  </div>
                }
                right={
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{capBUs.length} BUs · {capProgs.length} Programmes</span>
                    {capAtRisk > 0 && (
                      <Badge className="bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300 text-[10px]">
                        {capAtRisk} At Risk
                      </Badge>
                    )}
                    {capDelayed > 0 && capAtRisk === 0 && (
                      <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300 text-[10px]">
                        {capDelayed} Delayed
                      </Badge>
                    )}
                    <HealthBadge health={capHealth[cap.capabilityid] ?? "No Data"} />
                  </div>
                }
              >
                {/* BU level */}
                {capBUs.length === 0 && (
                  <p className="text-xs text-muted-foreground px-10 py-3">No business units under this capability.</p>
                )}
                {capBUs.map((bu) => {
                  const buProgs = programmes.filter((p) => p.businessid === bu.businessunitid);
                  const buAtRisk = buProgs.filter((p) => progHealth[p.programmeid] === "At Risk").length;
                  const isBOpen = !!openBUs[bu.businessunitid];

                  return (
                    <AccordionRow
                      key={bu.businessunitid}
                      open={isBOpen}
                      onToggle={() => toggleBU(bu.businessunitid)}
                      variant="bu"
                      indent={32}
                      left={
                        <div className="flex items-center gap-2.5">
                          <Users className="size-3.5 text-muted-foreground shrink-0" />
                          <div>
                            <p className="text-sm font-semibold">{bu.name}</p>
                            {bu.description && (
                              <p className="text-[10px] text-muted-foreground">{bu.description}</p>
                            )}
                          </div>
                        </div>
                      }
                      right={
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">{buProgs.length} Programmes</span>
                          {buAtRisk > 0 && (
                            <Badge className="bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300 text-[10px]">
                              {buAtRisk} At Risk
                            </Badge>
                          )}
                          <HealthBadge health={buHealth[bu.businessunitid] ?? "No Data"} />
                        </div>
                      }
                    >
                      {/* Programme cards */}
                      <div className="px-6 py-4 bg-background/50">
                        {buProgs.length === 0 && (
                          <p className="text-xs text-muted-foreground">No programmes in this business unit.</p>
                        )}
                        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                          {buProgs.map((prog) => (
                            <ProgrammeCard
                              key={prog.programmeid}
                              prog={prog}
                              health={progHealth[prog.programmeid] ?? "No Data"}
                            />
                          ))}
                        </div>
                      </div>
                    </AccordionRow>
                  );
                })}
              </AccordionRow>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
