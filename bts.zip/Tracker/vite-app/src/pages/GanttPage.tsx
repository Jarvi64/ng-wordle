import { useMemo, useRef, useState } from "react";
import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CalendarDays,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Flag,
  ShieldCheck,
} from "lucide-react";
import {
  format,
  addMonths,
  startOfMonth,
  endOfMonth,
  differenceInDays,
  addDays,
  isValid,
} from "date-fns";

// ─── Layout constants ──────────────────────────────────────────
const ROW_H    = 36;
const HEADER_H = 56; // 2 rows: month + day
const BAR_H    = 20;
const BAR_R    = 5;
const COL_WIDTHS = { name: 200, start: 76, end: 76, days: 52, status: 90, progress: 70 };
const LEFT_W   = Object.values(COL_WIDTHS).reduce((a, b) => a + b, 0); // 564

// ─── Status colour maps ────────────────────────────────────────
const MS_CLR: Record<string, string> = {
  "Not Started": "#94a3b8",
  "In Progress": "#0874B0",
  Completed:     "#10b981",
  Delayed:       "#f59e0b",
  "At Risk":     "#ef4444",
};
const MS_BADGE: Record<string, string> = {
  "Not Started": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300",
  Completed:     "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300",
  Delayed:       "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300",
  "At Risk":     "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300",
};
const CERT_CLR: Record<string, string> = {
  Pending:    "#94a3b8",
  "In Review":"#6366f1",
  Approved:   "#10b981",
  Rejected:   "#ef4444",
  Expired:    "#f97316",
};
const CERT_BADGE: Record<string, string> = {
  Pending:     "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Review": "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/50 dark:text-indigo-300",
  Approved:    "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300",
  Rejected:    "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300",
  Expired:     "bg-orange-100 text-orange-800 dark:bg-orange-900/50 dark:text-orange-300",
};

// ─── Helpers ──────────────────────────────────────────────────
function safeParse(ds: string | undefined): Date | null {
  if (!ds) return null;
  try { const d = new Date(ds.includes("T") ? ds : ds + "T00:00:00"); return isValid(d) ? d : null; }
  catch { return null; }
}
function clamp(v: number, lo: number, hi: number) { return Math.max(lo, Math.min(hi, v)); }
function fmtShort(d: Date | null): string { return d ? format(d, "dd/MM/yy") : "—"; }

function progHealth(statuses: string[]): { color: string; label: string; badge: string } {
  if (statuses.includes("At Risk")) return { color: "#ef4444", label: "At Risk", badge: "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300" };
  if (statuses.includes("Delayed")) return { color: "#f59e0b", label: "Delayed", badge: "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300" };
  if (statuses.every((s) => s === "Completed" || s === "Approved")) return { color: "#10b981", label: "On Track", badge: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300" };
  if (statuses.includes("In Progress") || statuses.includes("In Review")) return { color: "#0874B0", label: "In Progress", badge: "bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300" };
  if (statuses.length === 0) return { color: "#94a3b8", label: "No Data", badge: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300" };
  return { color: "#94a3b8", label: "Not Started", badge: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300" };
}

// ─── Row types ─────────────────────────────────────────────────
type PinDetail = { type: "milestone" | "certification"; name: string; status: string; date: string; prog: string; badge: string };

type GanttRow = {
  key: string;
  type: "programme" | "milestone" | "cert";
  label: string;
  sub?: string;
  startD: Date | null;
  endD: Date | null;
  status: string;
  progress: number;
  color: string;
  badge: string;
  progId: string;
  raw?: unknown;
};

// ─── Left panel column header ──────────────────────────────────
function ColHdr({ children, w, align = "left" }: { children: React.ReactNode; w: number; align?: string }) {
  return (
    <div className="border-r last:border-r-0 flex items-end pb-1.5 px-2 shrink-0" style={{ width: w }}>
      <span className={`text-[10px] font-semibold uppercase tracking-wider text-muted-foreground w-full text-${align}`}>
        {children}
      </span>
    </div>
  );
}

// ─── Progress pill ─────────────────────────────────────────────
function ProgressPill({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="flex items-center gap-1.5 w-full px-1">
      <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="text-[10px] font-semibold shrink-0" style={{ color }}>{pct}%</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
export function GanttPage() {
  const { programmes, milestones, certifications, businessUnits } = useAppStore();

  // Zoom: pixels per day
  const ZOOM_OPTIONS = [
    { label: "Days",   ppd: 30 },
    { label: "Weeks",  ppd: 6  },
    { label: "Months", ppd: 2  },
    { label: "All",    ppd: 0  }, // computed
  ];
  const [zoomIdx, setZoomIdx]         = useState(1); // Weeks by default
  const [viewStart, setViewStart]     = useState<Date>(() => { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 2); return d; });
  const [viewMonths, setViewMonths]   = useState(10);
  const [expanded, setExpanded]       = useState<Record<string, boolean>>({});
  const [pinDetail, setPinDetail]     = useState<PinDetail | null>(null);

  const leftScrollRef  = useRef<HTMLDivElement>(null);
  const rightScrollRef = useRef<HTMLDivElement>(null);
  const syncingRef     = useRef(false);

  // ── Build per-programme data ──
  const progData = useMemo(() => programmes.map((p) => {
    const pMs   = milestones.filter((m) => m.programmeid === p.programmeid);
    const pCerts = certifications.filter((c) => c.programmeid === p.programmeid);
    const allDates: Date[] = [];
    pMs.forEach((m) => { [m.startdate, m.targetedcompletiondate].forEach((d) => { const x = safeParse(d); if (x) allDates.push(x); }); });
    pCerts.forEach((c) => { [c.currentedc, c.validitydate].forEach((d) => { const x = safeParse(d); if (x) allDates.push(x); }); });
    const minD = allDates.length ? allDates.reduce((a, b) => a < b ? a : b) : null;
    const maxD = allDates.length ? allDates.reduce((a, b) => a > b ? a : b) : null;
    const statuses = [...pMs.map((m) => m.status), ...pCerts.map((c) => c.status)];
    const health   = progHealth(statuses);
    const msCompleted = pMs.filter((m) => m.status === "Completed").length;
    const msPct    = pMs.length > 0 ? Math.round((msCompleted / pMs.length) * 100) : 0;
    const buName   = businessUnits.find((b) => b.businessunitid === p.businessid)?.name ?? "";
    return { prog: p, pMs, pCerts, minD, maxD, health, msPct, buName };
  }), [programmes, milestones, certifications, businessUnits]);

  // ── Timeline bounds ──
  const globalMin = useMemo(() => {
    const all = progData.flatMap((d) => d.minD ? [d.minD] : []);
    return all.length ? all.reduce((a, b) => a < b ? a : b) : viewStart;
  }, [progData, viewStart]);

  const globalMax = useMemo(() => {
    const all = progData.flatMap((d) => d.maxD ? [d.maxD] : []);
    return all.length ? all.reduce((a, b) => a > b ? a : b) : addMonths(viewStart, viewMonths);
  }, [progData, viewStart, viewMonths]);

  const viewEnd    = addMonths(viewStart, viewMonths);
  const totalDays  = differenceInDays(viewEnd, viewStart);

  // "All" zoom: fit total span into viewport-ish width
  const effectivePpd = ZOOM_OPTIONS[zoomIdx].ppd > 0
    ? ZOOM_OPTIONS[zoomIdx].ppd
    : Math.max(1, Math.floor(1000 / Math.max(differenceInDays(globalMax, globalMin) + 1, 1)));

  const timelineW = Math.max(totalDays * effectivePpd + 80, 600);
  const today     = new Date();
  const todayX    = clamp(differenceInDays(today, viewStart) * effectivePpd, 0, timelineW);

  function dateX(d: Date | null): number {
    if (!d) return -1;
    return clamp(differenceInDays(d, viewStart) * effectivePpd, 0, timelineW);
  }

  // ── Month + day headers ──
  const monthBands = useMemo(() => {
    const result: { label: string; x: number; width: number; idx: number }[] = [];
    let cursor = startOfMonth(viewStart); let idx = 0;
    while (cursor < viewEnd) {
      const me = endOfMonth(cursor);
      const ce = me < viewEnd ? me : viewEnd;
      const x  = Math.max(0, differenceInDays(cursor, viewStart)) * effectivePpd;
      const ex = (differenceInDays(ce, viewStart) + 1) * effectivePpd;
      result.push({ label: format(cursor, "MMM yyyy"), x, width: ex - x, idx: idx++ });
      cursor = addMonths(startOfMonth(cursor), 1);
    }
    return result;
  }, [viewStart, viewEnd, effectivePpd]);

  // Day tick marks (only show if pxPerDay >= 8)
  const dayTicks = useMemo(() => {
    if (effectivePpd < 8) return [];
    const ticks: { x: number; label: string }[] = [];
    let d = new Date(viewStart);
    while (d < viewEnd) {
      ticks.push({ x: differenceInDays(d, viewStart) * effectivePpd, label: format(d, "d") });
      d = addDays(d, 1);
    }
    return ticks;
  }, [viewStart, viewEnd, effectivePpd]);

  // Week gridlines
  const weekLines = useMemo(() => {
    const lines: number[] = [];
    let cursor = new Date(viewStart);
    while (cursor.getDay() !== 1) cursor = addDays(cursor, 1);
    while (cursor < viewEnd) { lines.push(differenceInDays(cursor, viewStart) * effectivePpd); cursor = addDays(cursor, 7); }
    return lines;
  }, [viewStart, viewEnd, effectivePpd]);

  // ── Flat visible rows ──
  const rows = useMemo((): GanttRow[] => {
    const result: GanttRow[] = [];
    progData.forEach(({ prog, pMs, pCerts, minD, maxD, health, msPct, buName }) => {
      const isOpen = expanded[prog.programmeid] !== false; // default open
      result.push({
        key: `prog-${prog.programmeid}`,
        type: "programme",
        label: prog.name,
        sub: buName,
        startD: minD,
        endD: maxD,
        status: health.label,
        progress: msPct,
        color: health.color,
        badge: health.badge,
        progId: prog.programmeid,
      });
      if (isOpen) {
        pMs.forEach((m) => result.push({
          key: `ms-${m.milestoneid}`,
          type: "milestone",
          label: m.name,
          startD: safeParse(m.startdate),
          endD: safeParse(m.targetedcompletiondate),
          status: m.status,
          progress: 0, // no fake %; status conveys state
          color: MS_CLR[m.status] ?? "#94a3b8",
          badge: MS_BADGE[m.status] ?? "",
          progId: prog.programmeid,
          raw: m,
        }));
        pCerts.forEach((c) => result.push({
          key: `cert-${c.certificationid}`,
          type: "cert",
          label: c.name,
          startD: safeParse(c.currentedc),
          endD: safeParse(c.validitydate),
          status: c.status,
          progress: 0, // no fake %; status conveys state
          color: CERT_CLR[c.status] ?? "#6366f1",
          badge: CERT_BADGE[c.status] ?? "",
          progId: prog.programmeid,
          raw: c,
        }));
      }
    });
    return result;
  }, [progData, expanded]);

  const totalH = HEADER_H + rows.length * ROW_H;

  // ── Sync scroll ──
  function onLeftScroll(e: React.UIEvent<HTMLDivElement>) {
    if (syncingRef.current) return;
    syncingRef.current = true;
    if (rightScrollRef.current) rightScrollRef.current.scrollTop = (e.target as HTMLElement).scrollTop;
    syncingRef.current = false;
  }
  function onRightScroll(e: React.UIEvent<HTMLDivElement>) {
    if (syncingRef.current) return;
    syncingRef.current = true;
    if (leftScrollRef.current) leftScrollRef.current.scrollTop = (e.target as HTMLElement).scrollTop;
    syncingRef.current = false;
  }

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">

      {/* ── Page header ── */}
      <div className="px-5 pt-5 pb-3 border-b bg-background shrink-0">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
              <CalendarDays className="size-5 text-primary" />
              Programme Gantt
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              Milestones & certifications across all programmes — expand rows to drill down
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Zoom preset */}
            <div className="flex items-center border rounded-lg overflow-hidden">
              {ZOOM_OPTIONS.map((z, i) => (
                <button key={z.label} onClick={() => setZoomIdx(i)}
                  className={`px-3 py-1.5 text-xs font-medium transition-colors ${i === zoomIdx ? "bg-primary text-primary-foreground" : "hover:bg-muted text-muted-foreground"}`}>
                  {z.label}
                </button>
              ))}
            </div>

            {/* Month range */}
            <div className="flex items-center border rounded-lg overflow-hidden">
              {[4, 6, 10, 14].map((n) => (
                <button key={n} onClick={() => setViewMonths(n)}
                  className={`px-2.5 py-1.5 text-xs font-medium transition-colors ${viewMonths === n ? "bg-primary text-primary-foreground" : "hover:bg-muted text-muted-foreground"}`}>
                  {n}M
                </button>
              ))}
            </div>

            {/* Navigate */}
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" className="size-8" onClick={() => setViewStart((d) => addMonths(d, -1))}>
                <ChevronLeft className="size-4" />
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs px-3"
                onClick={() => { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 2); setViewStart(d); }}>
                Today
              </Button>
              <Button variant="outline" size="icon" className="size-8" onClick={() => setViewStart((d) => addMonths(d, 1))}>
                <ChevronRight className="size-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-5 mt-2.5 flex-wrap">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Legend</span>
          {Object.entries(MS_CLR).map(([s, c]) => (
            <div key={s} className="flex items-center gap-1.5">
              <div className="size-2 rounded-full" style={{ background: c }} />
              <span className="text-[10px] text-muted-foreground">{s}</span>
            </div>
          ))}
          <div className="flex items-center gap-1.5 pl-3 border-l">
            <div className="w-2.5 h-2.5 rounded-sm border-2 border-indigo-500 bg-indigo-200/40" />
            <span className="text-[10px] text-muted-foreground">Certification</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-0.5 h-3.5 bg-red-500 rounded" />
            <span className="text-[10px] text-muted-foreground">Today</span>
          </div>
        </div>
      </div>

      {/* ── Gantt body: Left + Right panels ── */}
      <div className="flex flex-1 min-h-0 overflow-hidden">

        {/* ──── LEFT PANEL ──── */}
        <div className="shrink-0 border-r flex flex-col" style={{ width: LEFT_W }}>
          {/* Column headers */}
          <div className="flex shrink-0 border-b bg-muted/40" style={{ height: HEADER_H }}>
            <ColHdr w={COL_WIDTHS.name}>Task</ColHdr>
            <ColHdr w={COL_WIDTHS.start} align="center">Start</ColHdr>
            <ColHdr w={COL_WIDTHS.end} align="center">End</ColHdr>
            <ColHdr w={COL_WIDTHS.days} align="center">Days</ColHdr>
            <ColHdr w={COL_WIDTHS.status}>Status</ColHdr>
            <ColHdr w={COL_WIDTHS.progress}>Progress</ColHdr>
          </div>

          {/* Rows */}
          <div ref={leftScrollRef} onScroll={onLeftScroll} className="overflow-y-scroll flex-1 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
            {rows.map((row) => {
              const durDays = row.startD && row.endD ? differenceInDays(row.endD, row.startD) + 1 : null;
              const isProg  = row.type === "programme";
              const isCert  = row.type === "cert";
              const isExp   = expanded[row.progId] !== false;

              return (
                <div key={row.key}
                  className={`flex items-center border-b shrink-0 ${isProg ? "bg-muted/25 hover:bg-muted/50" : "hover:bg-muted/20"} transition-colors`}
                  style={{ height: ROW_H }}>

                  {/* Name column */}
                  <div className="border-r flex items-center gap-1.5 px-2 shrink-0 min-w-0" style={{ width: COL_WIDTHS.name }}>
                    {/* Indent for children */}
                    {!isProg && <span className="shrink-0 w-3" />}

                    {/* Expand toggle for programme rows */}
                    {isProg && (
                      <button onClick={() => setExpanded((p) => ({ ...p, [row.progId]: !isExp }))} className="shrink-0">
                        <ChevronDown className={`size-3.5 text-muted-foreground transition-transform ${isExp ? "" : "-rotate-90"}`} />
                      </button>
                    )}

                    {/* Icon */}
                    <div className="size-2 rounded-full shrink-0" style={{ background: row.color }} />
                    {isCert && <ShieldCheck className="size-2.5 text-indigo-500 -ml-0.5 shrink-0" />}

                    <div className="min-w-0 flex-1">
                      <p className={`truncate leading-none ${isProg ? "text-[12px] font-bold" : "text-[11px] font-medium"}`}>
                        {row.label}
                      </p>
                      {isProg && row.sub && (
                        <p className="text-[9px] text-muted-foreground truncate mt-0.5">{row.sub}</p>
                      )}
                    </div>
                  </div>

                  {/* Start */}
                  <div className="border-r flex items-center justify-center px-1 shrink-0" style={{ width: COL_WIDTHS.start }}>
                    <span className="text-[10px] text-muted-foreground">{fmtShort(row.startD)}</span>
                  </div>

                  {/* End */}
                  <div className="border-r flex items-center justify-center px-1 shrink-0" style={{ width: COL_WIDTHS.end }}>
                    <span className="text-[10px] text-muted-foreground">{fmtShort(row.endD)}</span>
                  </div>

                  {/* Days */}
                  <div className="border-r flex items-center justify-center shrink-0" style={{ width: COL_WIDTHS.days }}>
                    <span className="text-[10px] font-semibold">{durDays != null ? `${durDays}d` : "—"}</span>
                  </div>

                  {/* Status */}
                  <div className="border-r flex items-center px-1.5 shrink-0" style={{ width: COL_WIDTHS.status }}>
                    <Badge className={`text-[9px] px-1.5 py-0 font-semibold ${row.badge}`}>{row.status}</Badge>
                  </div>

                  {/* Progress column */}
                  <div className="flex items-center shrink-0" style={{ width: COL_WIDTHS.progress }}>
                    {isProg
                      ? <ProgressPill pct={row.progress} color={row.color} />
                      : <Badge className={`${row.badge} text-[9px] px-1.5 py-0 ml-1 font-medium`}>{row.status}</Badge>
                    }
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ──── RIGHT PANEL (SVG) ──── */}
        <div ref={rightScrollRef} onScroll={onRightScroll}
          className="flex-1 overflow-auto">
          <div style={{ width: timelineW, minWidth: timelineW }}>
            <svg width={timelineW} height={totalH} className="select-none" style={{ display: "block" }}>

              {/* ── Date header ── */}
              {/* Month bands */}
              {monthBands.map((m) => (
                <g key={m.idx}>
                  <rect x={m.x} y={0} width={m.width} height={HEADER_H}
                    fill={m.idx % 2 === 0 ? "var(--color-muted)" : "var(--color-background)"} fillOpacity={0.4} />
                  <text x={m.x + m.width / 2} y={18} textAnchor="middle"
                    fontSize={11} fontWeight={700} fill="var(--color-muted-foreground)" fontFamily="inherit">
                    {m.label}
                  </text>
                  {m.idx > 0 && <line x1={m.x} y1={0} x2={m.x} y2={totalH} stroke="var(--color-border)" strokeWidth={1} />}
                </g>
              ))}

              {/* Day ticks */}
              {dayTicks.map((t, i) => (
                <g key={i}>
                  <line x1={t.x} y1={30} x2={t.x} y2={HEADER_H} stroke="var(--color-border)" strokeWidth={0.5} />
                  <text x={t.x + effectivePpd / 2} y={44} textAnchor="middle"
                    fontSize={8} fill="var(--color-muted-foreground)" fontFamily="inherit">{t.label}</text>
                </g>
              ))}

              {/* Week gridlines */}
              {weekLines.map((x, i) => (
                <line key={i} x1={x} y1={HEADER_H} x2={x} y2={totalH}
                  stroke="var(--color-border)" strokeWidth={0.75} strokeDasharray="3,5" />
              ))}

              {/* Header border */}
              <line x1={0} y1={HEADER_H} x2={timelineW} y2={HEADER_H} stroke="var(--color-border)" strokeWidth={1.5} />

              {/* ── Rows ── */}
              {rows.map((row, ri) => {
                const rowY = HEADER_H + ri * ROW_H;
                const barY = rowY + (ROW_H - BAR_H) / 2;
                const isProg = row.type === "programme";
                const isCert = row.type === "cert";

                const sx = dateX(row.startD);
                const ex = dateX(row.endD);
                const bw = sx >= 0 && ex > sx ? Math.max(ex - sx + effectivePpd, 6) : 0;

                return (
                  <g key={row.key}>
                    {/* Row bg */}
                    <rect x={0} y={rowY} width={timelineW} height={ROW_H}
                      fill={isProg ? "var(--color-muted)" : "var(--color-background)"}
                      fillOpacity={isProg ? 0.15 : ri % 2 === 0 ? 0 : 0.04} />
                    <line x1={0} y1={rowY + ROW_H} x2={timelineW} y2={rowY + ROW_H}
                      stroke="var(--color-border)" strokeWidth={0.5} />

                    {/* Bar */}
                    {bw > 0 && (
                      <g
                        className="cursor-pointer"
                        onClick={() => {
                          if (!isProg && row.raw) {
                            const r = row.raw as Record<string, string>;
                            setPinDetail({
                              type: isCert ? "certification" : "milestone",
                              name: row.label,
                              status: row.status,
                              date: isCert ? (r.validitydate ?? "") : (r.targetedcompletiondate ?? ""),
                              prog: row.progId,
                              badge: row.badge,
                            });
                          }
                        }}
                      >
                        {/* Shadow */}
                        <rect x={sx + 1} y={barY + 2} width={bw} height={BAR_H - 2}
                          rx={BAR_R} fill="rgba(0,0,0,0.12)" />
                        {/* Base bar */}
                        <rect x={sx} y={barY} width={bw} height={BAR_H}
                          rx={BAR_R + (isProg ? 2 : 0)}
                          fill={row.color}
                          fillOpacity={isProg ? 0.15 : isCert ? 0.3 : 1}
                          stroke={row.color}
                          strokeWidth={isProg ? 1.5 : 0}
                          strokeOpacity={isProg ? 0.5 : 0}
                          strokeDasharray={isProg ? "4,3" : "0"} />
                        {/* Progress fill overlay — only for programme group bars */}
                        {isProg && row.progress > 0 && (
                          <rect x={sx} y={barY} width={bw * (row.progress / 100)} height={BAR_H}
                            rx={BAR_R}
                            fill="white"
                            fillOpacity={0.18} />
                        )}
                        {/* Label inside bar — just the name */}
                        {!isProg && bw > 32 && (
                          <>
                            <clipPath id={`clip-${row.key}`}>
                              <rect x={sx + 4} y={barY} width={bw - 8} height={BAR_H} />
                            </clipPath>
                            <text x={sx + 7} y={barY + BAR_H / 2 + 0.5}
                              fontSize={8.5} fontWeight={700} fill="white"
                              fontFamily="inherit" dominantBaseline="middle"
                              clipPath={`url(#clip-${row.key})`}>
                              {row.label}
                            </text>
                          </>
                        )}
                        {/* Cert diamond marker at start */}
                        {isCert && sx >= 0 && (
                          <polygon
                            points={`${sx},${barY + BAR_H / 2 - 7} ${sx + 7},${barY + BAR_H / 2} ${sx},${barY + BAR_H / 2 + 7} ${sx - 7},${barY + BAR_H / 2}`}
                            fill={row.color}
                            stroke="var(--color-background)"
                            strokeWidth={1.5} />
                        )}
                      </g>
                    )}
                  </g>
                );
              })}

              {/* ── Today line ── */}
              {todayX > 0 && todayX < timelineW && (
                <g>
                  <line x1={todayX} y1={0} x2={todayX} y2={totalH}
                    stroke="#ef4444" strokeWidth={1.5} strokeOpacity={0.7} />
                  <rect x={todayX - 20} y={0} width={40} height={20} rx={4} fill="#ef4444" fillOpacity={0.9} />
                  <text x={todayX} y={13} textAnchor="middle" fontSize={9}
                    fontWeight={700} fill="white" fontFamily="inherit">Today</text>
                </g>
              )}
            </svg>
          </div>
        </div>
      </div>

      {/* ── Detail dialog ── */}
      <Dialog open={!!pinDetail} onOpenChange={(o) => !o && setPinDetail(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <div className="flex items-center gap-2 mb-1">
              {pinDetail?.type === "milestone"
                ? <Flag className="size-4 text-blue-500" />
                : <ShieldCheck className="size-4 text-indigo-500" />}
              <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                {pinDetail?.type}
              </span>
            </div>
            <DialogTitle className="text-base leading-snug">{pinDetail?.name}</DialogTitle>
            <DialogDescription>Programme ID: {pinDetail?.prog}</DialogDescription>
          </DialogHeader>
          {pinDetail && (
            <div className="space-y-3 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Status</span>
                <Badge className={pinDetail.badge}>{pinDetail.status}</Badge>
              </div>
              <div className="rounded-lg bg-muted/40 p-3 flex items-center gap-2.5">
                <CalendarDays className="size-4 text-muted-foreground shrink-0" />
                <div>
                  <p className="text-[11px] text-muted-foreground">
                    {pinDetail.type === "milestone" ? "Target Completion" : "Validity Date"}
                  </p>
                  <p className="text-sm font-semibold">{pinDetail.date}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
