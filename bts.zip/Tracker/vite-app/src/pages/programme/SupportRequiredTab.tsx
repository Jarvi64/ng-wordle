import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useAppStore,
  SUPPORT_CATEGORIES,
  SUPPORT_CRITICALITIES,
  SUPPORT_STATUSES,
} from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, ArrowRight, CalendarDays } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { DatePicker } from "@/components/ui/date-picker";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const schema = z.object({
  supporttext: z.string().min(2, "Support description is required"),
  category: z.string().min(1, "Category is required"),
  criticality: z.string().min(1, "Criticality is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  deadline: z.string().min(1, "Deadline is required"),
  status: z.string().min(1, "Status is required"),
});

type FormData = z.infer<typeof schema>;

const CRITICALITY_COLORS: Record<string, string> = {
  Low: "bg-muted text-muted-foreground",
  Medium: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  High: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  Critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

const STATUS_COLORS: Record<string, string> = {
  Open: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "In Progress": "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  Resolved: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  Closed: "bg-muted text-muted-foreground",
};

export function SupportRequiredTab({ programmeId }: { programmeId: string }) {
  const {
    supportRequired,
    programmeOrgNodes,
    addSupportRequired,
    updateSupportRequired,
    deleteSupportRequired,
    addDateChangeLog,
  } = useAppStore();

  const items = supportRequired.filter((s) => s.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter(
    (n) => n.programmeid === programmeId && n.active === "Yes",
  );
  const orgNodeNames = orgNodes.map((n) => n.displayname);
  const categoryItems = [...SUPPORT_CATEGORIES];
  const criticalityItems = [...SUPPORT_CRITICALITIES];
  const statusItems = [...SUPPORT_STATUSES];

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  // Date change reason
  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDeadlineChange, setPendingDeadlineChange] = useState<{
    oldDate: string;
    newDate: string;
  } | null>(null);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<FormData | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const openAddDialog = () => {
    reset({
      supporttext: "",
      category: "",
      criticality: "",
      ownerorgnodeid: "",
      deadline: "",
      status: "",
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((s) => s.supportrequiredid === id);
    if (item) {
      reset({ ...item });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (editingId) {
      const existing = items.find((s) => s.supportrequiredid === editingId);
      if (existing && existing.deadline !== data.deadline) {
        setPendingDeadlineChange({
          oldDate: existing.deadline,
          newDate: data.deadline,
        });
        setPendingFormData(data);
        setDateChangeReason("");
        setShowReasonDialog(true);
        return;
      }
    }
    await saveData(data, "");
  };

  const saveData = async (data: FormData, reason: string) => {
    setIsSaving(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      if (editingId) {
        if (reason && pendingDeadlineChange) {
          const existing = items.find(
            (s) => s.supportrequiredid === editingId,
          )!;
          addDateChangeLog({
            programmeid: programmeId,
            module: "support_required",
            recordid: editingId,
            recordname: existing.supporttext.substring(0, 50),
            fieldname: "deadline",
            olddate: pendingDeadlineChange.oldDate,
            newdate: pendingDeadlineChange.newDate,
            reason,
          });
        }
        updateSupportRequired(editingId, { ...data, programmeid: programmeId });
        toast.success("Support item updated");
      } else {
        addSupportRequired({ ...data, programmeid: programmeId });
        toast.success("Support item added");
      }
      setIsDialogOpen(false);
      setPendingDeadlineChange(null);
      setPendingFormData(null);
    } catch {
      toast.error("Something went wrong");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReasonConfirm = async () => {
    if (!dateChangeReason.trim()) return;
    setShowReasonDialog(false);
    if (pendingFormData) {
      await saveData(pendingFormData, dateChangeReason.trim());
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      deleteSupportRequired(deleteTarget);
      toast.success("Support item deleted");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  const getOwnerName = (nodeId: string) =>
    orgNodes.find((n) => n.programmeorgnodeid === nodeId)?.displayname || "—";

  const formatDate = (d: string) => {
    if (!d) return "—";
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  return (
    <div className="flex flex-col gap-4 pt-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Support Required</h3>
          <p className="text-sm text-muted-foreground">
            Track support needs across programme categories.
          </p>
        </div>
        <Button onClick={openAddDialog}>
          <Plus data-icon="inline-start" />
          Add Support Item
        </Button>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="min-w-[200px]">Support</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Criticality</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Deadline</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="h-24 text-center text-muted-foreground"
                >
                  No support items yet.
                </TableCell>
              </TableRow>
            ) : (
              items.map((item) => {
                const isPastDeadline =
                  item.deadline &&
                  new Date(item.deadline) < new Date() &&
                  item.status !== "Resolved" &&
                  item.status !== "Closed";
                return (
                  <TableRow key={item.supportrequiredid}>
                    <TableCell className="font-medium text-foreground">
                      <p className="line-clamp-2 text-sm">{item.supporttext}</p>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          CRITICALITY_COLORS[item.criticality] ||
                          CRITICALITY_COLORS["Low"]
                        }
                      >
                        {item.criticality}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {getOwnerName(item.ownerorgnodeid)}
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap">
                      <span className={isPastDeadline ? "text-destructive font-medium" : ""}>
                        {formatDate(item.deadline)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          STATUS_COLORS[item.status] || STATUS_COLORS["Open"]
                        }
                      >
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            openEditDialog(item.supportrequiredid)
                          }
                        >
                          <Pencil />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() =>
                            setDeleteTarget(item.supportrequiredid)
                          }
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Support Item" : "Add Support Item"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Support required details form.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FieldGroup>
              <Field data-invalid={!!errors.supporttext || undefined}>
                <Label htmlFor="sup-text">Support Description</Label>
                <Textarea
                  id="sup-text"
                  {...register("supporttext")}
                  placeholder="Describe the support needed..."
                  aria-invalid={!!errors.supporttext || undefined}
                />
                {errors.supporttext && (
                  <FieldError>{errors.supporttext.message}</FieldError>
                )}
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.category || undefined}>
                  <Label>Category</Label>
                  <Controller
                    control={control}
                    name="category"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={categoryItems}
                      >
                        <ComboboxInput placeholder="Select category" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.category && (
                    <FieldError>{errors.category.message}</FieldError>
                  )}
                </Field>
                <Field data-invalid={!!errors.criticality || undefined}>
                  <Label>Criticality</Label>
                  <Controller
                    control={control}
                    name="criticality"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={criticalityItems}
                      >
                        <ComboboxInput placeholder="Select level" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.criticality && (
                    <FieldError>{errors.criticality.message}</FieldError>
                  )}
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.ownerorgnodeid || undefined}>
                  <Label>Owner</Label>
                  <Controller
                    control={control}
                    name="ownerorgnodeid"
                    render={({ field }) => {
                      const selectedName =
                        orgNodes.find(
                          (n) => n.programmeorgnodeid === field.value,
                        )?.displayname ?? null;
                      return (
                        <Combobox
                          value={selectedName}
                          onValueChange={(name: string | null) => {
                            const node = orgNodes.find(
                              (n) => n.displayname === name,
                            );
                            field.onChange(node?.programmeorgnodeid ?? "");
                          }}
                          items={orgNodeNames}
                        >
                          <ComboboxInput placeholder="Select owner" />
                          <ComboboxContent>
                            <ComboboxEmpty>No match.</ComboboxEmpty>
                            <ComboboxList>
                              {(name: string) => (
                                <ComboboxItem key={name} value={name}>
                                  {name}
                                </ComboboxItem>
                              )}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      );
                    }}
                  />
                  {errors.ownerorgnodeid && (
                    <FieldError>{errors.ownerorgnodeid.message}</FieldError>
                  )}
                </Field>
                <Field data-invalid={!!errors.status || undefined}>
                  <Label>Status</Label>
                  <Controller
                    control={control}
                    name="status"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={statusItems}
                      >
                        <ComboboxInput placeholder="Select status" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.status && (
                    <FieldError>{errors.status.message}</FieldError>
                  )}
                </Field>
              </div>

              <Field data-invalid={!!errors.deadline || undefined}>
                <Label>Deadline</Label>
                <Controller
                  control={control}
                  name="deadline"
                  render={({ field }) => (
                    <DatePicker
                      value={field.value}
                      onChange={field.onChange}
                      placeholder="Pick deadline"
                    />
                  )}
                />
                {errors.deadline && (
                  <FieldError>{errors.deadline.message}</FieldError>
                )}
              </Field>
            </FieldGroup>

            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline" disabled={isSaving}>
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <Spinner data-icon="inline-start" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Date Change Reason Dialog */}
      <Dialog open={showReasonDialog} onOpenChange={setShowReasonDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Deadline Change Reason</DialogTitle>
            <DialogDescription>
              The deadline was modified. Please provide a reason for audit.
            </DialogDescription>
          </DialogHeader>
          {pendingDeadlineChange && (
            <div className="flex items-center gap-2 text-sm rounded-lg bg-muted px-3 py-2">
              <CalendarDays className="size-3.5 text-muted-foreground shrink-0" />
              <span className="line-through text-destructive">
                {formatDate(pendingDeadlineChange.oldDate)}
              </span>
              <ArrowRight className="size-3.5 text-muted-foreground shrink-0" />
              <span className="font-medium">
                {formatDate(pendingDeadlineChange.newDate)}
              </span>
            </div>
          )}
          <FieldGroup>
            <Field>
              <Label htmlFor="sup-reason">Reason</Label>
              <Textarea
                id="sup-reason"
                value={dateChangeReason}
                onChange={(e) => setDateChangeReason(e.target.value)}
                placeholder="e.g., Budget approval delayed..."
              />
            </Field>
          </FieldGroup>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowReasonDialog(false);
                setPendingDeadlineChange(null);
                setPendingFormData(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleReasonConfirm}
              disabled={!dateChangeReason.trim()}
            >
              Confirm & Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete support item?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
