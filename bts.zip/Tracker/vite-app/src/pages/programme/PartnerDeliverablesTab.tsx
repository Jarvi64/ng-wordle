import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, AlertTriangle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { DatePicker } from "@/components/ui/date-picker";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DateChangePopover } from "@/components/ui/date-change-popover";

const STATUSES = ["Not Started", "In Progress", "Completed", "Delayed", "At Risk"];

const STATUS_COLORS: Record<string, string> = {
  "Not Started": "bg-muted text-muted-foreground",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "Completed": "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  "Delayed": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  "At Risk": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

const schema = z.object({
  partnername: z.string().min(1, "Partner Name is required"),
  deliverable: z.string().min(1, "Deliverable is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  targetedc: z.string().min(1, "Target EDC is required"),
  currentedc: z.string().min(1, "Current EDC is required"),
  status: z.string().min(1, "Status is required"),
  riskremarks: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export function PartnerDeliverablesTab({ programmeId }: { programmeId: string }) {
  const {
    partnerDeliverables,
    programmeOrgNodes,
    addPartnerDeliverable,
    updatePartnerDeliverable,
    deletePartnerDeliverable,
    addDateChangeLog,
    dateChangeLogs,
  } = useAppStore();

  const items = partnerDeliverables.filter((s) => s.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter(
    (n) => n.programmeid === programmeId && n.active === "Yes",
  );

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Date change Tracking
  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDateChangeData, setPendingDateChangeData] = useState<{
    formData: FormData;
    changes: { field: string; oldDate: string; newDate: string }[];
  } | null>(null);
  const [showReasonDialog, setShowReasonDialog] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const openAddDialog = () => {
    reset({
      partnername: "",
      deliverable: "",
      ownerorgnodeid: "",
      targetedc: "",
      currentedc: "",
      status: "Not Started",
      riskremarks: "",
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((s) => s.partnerdeliverableid === id);
    if (item) {
      reset({ ...item, riskremarks: item.riskremarks || "" });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (editingId) {
      const existing = items.find((s) => s.partnerdeliverableid === editingId);
      if (existing) {
        const changes: { field: string; oldDate: string; newDate: string }[] = [];
        if (existing.targetedc !== data.targetedc) {
          changes.push({ field: "targetedc", oldDate: existing.targetedc, newDate: data.targetedc });
        }
        if (existing.currentedc !== data.currentedc) {
          changes.push({ field: "currentedc", oldDate: existing.currentedc, newDate: data.currentedc });
        }

        if (changes.length > 0) {
          setPendingDateChangeData({ formData: data, changes });
          setShowReasonDialog(true);
          return; // Wait for reason
        }
      }
    }

    await saveItem(data);
  };

  const saveItem = async (data: FormData, reason?: string) => {
    setIsSaving(true);
    try {
      if (editingId) {
        updatePartnerDeliverable(editingId, data);
        
        // Log changes if provided
        if (pendingDateChangeData && reason) {
          const existing = items.find((s) => s.partnerdeliverableid === editingId)!;
          for (const change of pendingDateChangeData.changes) {
            addDateChangeLog({
              programmeid: programmeId,
              module: "partner_deliverable",
              recordid: editingId,
              recordname: data.deliverable,
              fieldname: change.field,
              olddate: change.oldDate,
              newdate: change.newDate,
              reason: reason,
            });
          }
        }
        toast.success("Deliverable updated successfully");
      } else {
        addPartnerDeliverable({ ...data, programmeid: programmeId, riskremarks: data.riskremarks || "" });
        toast.success("Deliverable added successfully");
      }
      setIsDialogOpen(false);
      setPendingDateChangeData(null);
      setDateChangeReason("");
    } catch (error) {
      toast.error("Failed to save deliverable");
    } finally {
      setIsSaving(false);
    }
  };

  const confirmDateChange = async () => {
    if (dateChangeReason.trim().length < 5) {
      toast.error("Please provide a valid reason (min 5 characters)");
      return;
    }
    if (pendingDateChangeData) {
      await saveItem(pendingDateChangeData.formData, dateChangeReason);
      setShowReasonDialog(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      deletePartnerDeliverable(deleteTarget);
      toast.success("Deliverable deleted successfully");
      setDeleteTarget(null);
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete deliverable");
    } finally {
      setIsDeleting(false);
    }
  };

  const getOwnerName = (nodeId: string) => {
    const node = programmeOrgNodes.find((n) => n.programmeorgnodeid === nodeId);
    return node ? node.displayname : "Unknown";
  };

  return (
    <div className="space-y-4 mt-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium leading-none">Partner & ToT/OEM Timeline</h3>
        <Button onClick={openAddDialog} size="sm">
          <Plus className="size-4 mr-2" />
          Add Deliverable
        </Button>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Partner</TableHead>
              <TableHead>Deliverable</TableHead>
              <TableHead>Target EDC</TableHead>
              <TableHead>Current EDC</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[80px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No partner deliverables recorded.
                </TableCell>
              </TableRow>
            ) : (
              items.map((item) => {
                const targetLogs = dateChangeLogs.filter((l) => l.recordid === item.partnerdeliverableid && l.module === "partner_deliverable" && l.fieldname === "targetedc");
                const currentLogs = dateChangeLogs.filter((l) => l.recordid === item.partnerdeliverableid && l.module === "partner_deliverable" && l.fieldname === "currentedc");
                
                return (
                <TableRow key={item.partnerdeliverableid}>
                  <TableCell className="font-medium">{item.partnername}</TableCell>
                  <TableCell>{item.deliverable}</TableCell>
                  <TableCell>
                    {targetLogs.length > 0 ? (
                      <DateChangePopover logs={targetLogs}>
                        {item.targetedc}
                        <AlertTriangle className="size-3.5 text-amber-500" />
                      </DateChangePopover>
                    ) : (
                      item.targetedc
                    )}
                  </TableCell>
                  <TableCell>
                    {currentLogs.length > 0 ? (
                      <DateChangePopover logs={currentLogs}>
                        {item.currentedc}
                        <AlertTriangle className="size-3.5 text-amber-500" />
                      </DateChangePopover>
                    ) : (
                      item.currentedc
                    )}
                  </TableCell>
                  <TableCell>{getOwnerName(item.ownerorgnodeid)}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={STATUS_COLORS[item.status] || ""}>
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:bg-muted"
                        onClick={() => openEditDialog(item.partnerdeliverableid)}
                      >
                        <Pencil className="size-4 text-muted-foreground" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => setDeleteTarget(item.partnerdeliverableid)}
                      >
                        <Trash2 className="size-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Primary Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px] overflow-hidden">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Deliverable" : "Add New Deliverable"}
            </DialogTitle>
            <DialogDescription>
              Details about partner and OEM handovers.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4 max-h-[60vh] overflow-y-auto px-1">
            <FieldGroup>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Partner Name</Label>
                  <Input {...register("partnername")} placeholder="e.g. AWS" />
                  {errors.partnername && <FieldError>{errors.partnername.message}</FieldError>}
                </Field>
                <Field>
                  <Label>Deliverable</Label>
                  <Input {...register("deliverable")} placeholder="API gateway setup" />
                  {errors.deliverable && <FieldError>{errors.deliverable.message}</FieldError>}
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Target EDC</Label>
                  <Controller
                    control={control}
                    name="targetedc"
                    render={({ field }) => (
                      <DatePicker
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="Pick target date"
                      />
                    )}
                  />
                  {errors.targetedc && <FieldError>{errors.targetedc.message}</FieldError>}
                </Field>
                <Field>
                  <Label>Current EDC</Label>
                  <Controller
                    control={control}
                    name="currentedc"
                    render={({ field }) => (
                      <DatePicker
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="Pick current expected date"
                      />
                    )}
                  />
                  {errors.currentedc && <FieldError>{errors.currentedc.message}</FieldError>}
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Owner (Org Node)</Label>
                  <Controller
                    control={control}
                    name="ownerorgnodeid"
                    render={({ field }) => (
                      <Combobox
                        value={field.value}
                        onValueChange={field.onChange}
                        items={orgNodes.map((n) => n.programmeorgnodeid)}
                      >
                        <ComboboxInput placeholder="Select owner..." />
                        <ComboboxContent>
                          <ComboboxEmpty>No active org nodes found</ComboboxEmpty>
                          <ComboboxList>
                            {(nodeId) => {
                              const node = orgNodes.find((n) => n.programmeorgnodeid === nodeId);
                              return (
                                <ComboboxItem key={nodeId} value={nodeId}>
                                  {node?.displayname} - {node?.title}
                                </ComboboxItem>
                              );
                            }}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.ownerorgnodeid && <FieldError>{errors.ownerorgnodeid.message}</FieldError>}
                </Field>
                <Field>
                  <Label>Status</Label>
                  <Controller
                    control={control}
                    name="status"
                    render={({ field }) => (
                      <Combobox
                        value={field.value}
                        onValueChange={field.onChange}
                        items={STATUSES}
                      >
                        <ComboboxInput placeholder="Select status..." />
                        <ComboboxContent>
                          <ComboboxEmpty>Status not found</ComboboxEmpty>
                          <ComboboxList>
                            {(status) => (
                              <ComboboxItem key={status} value={status}>
                                {status}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.status && <FieldError>{errors.status.message}</FieldError>}
                </Field>
              </div>

              <Field>
                <Label>Risk / Remarks (Optional)</Label>
                <Textarea
                  {...register("riskremarks")}
                  placeholder="Note any risks or delays..."
                  className="resize-none"
                  rows={2}
                />
              </Field>
            </FieldGroup>

            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline">
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? <Spinner className="mr-2 size-4" /> : null}
                Save Deliverable
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Date Change Reason Dialog */}
      <Dialog open={showReasonDialog} onOpenChange={(open) => !open && setShowReasonDialog(false)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Date Change Justification</DialogTitle>
            <DialogDescription>
              You are modifying dates. Please provide a reason to log this change.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {pendingDateChangeData?.changes.map((c, i) => (
              <div key={i} className="text-sm p-3 bg-muted/40 rounded-md mb-3 border">
                <strong>{c.field}:</strong> <span className="line-through opacity-70">{c.oldDate}</span> {" -> "} 
                <span className="font-semibold text-primary">{c.newDate}</span>
              </div>
            ))}
            <div className="space-y-2 mt-4">
              <Label>Reason for Date Change</Label>
              <Textarea
                placeholder="Brief justification for the delay/change..."
                value={dateChangeReason}
                onChange={(e) => setDateChangeReason(e.target.value)}
                rows={3}
                className="resize-none"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReasonDialog(false)} type="button">
              Cancel
            </Button>
            <Button onClick={confirmDateChange} disabled={isSaving || dateChangeReason.trim().length < 5}>
              {isSaving && <Spinner className="mr-2 h-4 w-4" />}
              Confirm Change
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this deliverable entry.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button variant="destructive" onClick={confirmDelete} disabled={isDeleting}>
              {isDeleting ? <Spinner className="mr-2 size-4" /> : null}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
