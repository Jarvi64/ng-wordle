import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore, MILESTONE_STATUSES } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, AlertTriangle, ArrowRight, Clock } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { DatePicker } from "@/components/ui/date-picker";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

const schema = z.object({
  name: z.string().min(2, "Name is required"),
  startdate: z.string().min(1, "Start date is required"),
  originaltargetedcompletiondate: z.string().min(1, "Original target date is required"),
  targetedcompletiondate: z.string().min(1, "Current target date is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  status: z.string().min(1, "Status is required"),
  remarks: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const STATUS_COLORS: Record<string, string> = {
  "Not Started": "bg-muted text-muted-foreground",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  Completed: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  Delayed: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "At Risk": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export function MilestonesTab({ programmeId }: { programmeId: string }) {
  const {
    milestones,
    programmeOrgNodes,
    dateChangeLogs,
    addMilestone,
    updateMilestone,
    deleteMilestone,
    addDateChangeLog,
  } = useAppStore();

  const items = milestones.filter((m) => m.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter((n) => n.programmeid === programmeId && n.active === "Yes");
  const orgNodeNames = orgNodes.map((n) => n.displayname);
  const statusItems = [...MILESTONE_STATUSES];

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  // Date change reason dialog
  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDateChanges, setPendingDateChanges] = useState<Array<{ field: string; oldDate: string; newDate: string }>>([]);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<FormData | null>(null);
  // Date history dialog
  const [historyMilestoneId, setHistoryMilestoneId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const openAddDialog = () => {
    reset({
      name: "",
      startdate: "",
      originaltargetedcompletiondate: "",
      targetedcompletiondate: "",
      ownerorgnodeid: "",
      status: "",
      remarks: "",
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((m) => m.milestoneid === id);
    if (item) {
      reset({
        name: item.name,
        startdate: item.startdate,
        originaltargetedcompletiondate: item.originaltargetedcompletiondate,
        targetedcompletiondate: item.targetedcompletiondate,
        ownerorgnodeid: item.ownerorgnodeid,
        status: item.status,
        remarks: item.remarks,
      });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (editingId) {
      const existing = items.find((m) => m.milestoneid === editingId);
      if (existing) {
        const dateFields = [
          { field: "startdate", label: "Start Date" },
          { field: "originaltargetedcompletiondate", label: "Original Target Date" },
          { field: "targetedcompletiondate", label: "Target Completion Date" },
        ] as const;

        const changes = dateFields
          .filter((f) => existing[f.field] !== data[f.field])
          .map((f) => ({
            field: f.field,
            oldDate: existing[f.field],
            newDate: data[f.field],
          }));

        if (changes.length > 0) {
          setPendingDateChanges(changes);
          setPendingFormData(data);
          setDateChangeReason("");
          setShowReasonDialog(true);
          return;
        }
      }
    }
    await saveData(data, "");
  };

  const saveData = async (data: FormData, reason: string) => {
    setIsSaving(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      if (editingId) {
        const existing = items.find((m) => m.milestoneid === editingId)!;
        if (reason && pendingDateChanges.length > 0) {
          for (const change of pendingDateChanges) {
            addDateChangeLog({
              programmeid: programmeId,
              module: "milestone",
              recordid: editingId,
              recordname: existing.name,
              fieldname: change.field,
              olddate: change.oldDate,
              newdate: change.newDate,
              reason,
            });
          }
        }
        updateMilestone(editingId, {
          ...data,
          remarks: data.remarks || "",
          changecount: existing.changecount + (pendingDateChanges.length > 0 ? 1 : 0),
          lastchangereason: reason || existing.lastchangereason,
        });
        toast.success("Milestone updated");
      } else {
        addMilestone({
          ...data,
          programmeid: programmeId,
          remarks: data.remarks || "",
        });
        toast.success("Milestone added");
      }
      setIsDialogOpen(false);
      setPendingDateChanges([]);
      setPendingFormData(null);
    } catch {
      toast.error("Something went wrong");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReasonConfirm = async () => {
    if (!dateChangeReason.trim()) return;
    setShowReasonDialog(false);
    if (pendingFormData) {
      await saveData(pendingFormData, dateChangeReason.trim());
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      deleteMilestone(deleteTarget);
      toast.success("Milestone deleted");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  const getOwnerName = (nodeId: string) =>
    orgNodes.find((n) => n.programmeorgnodeid === nodeId)?.displayname || "—";

  const formatDate = (d: string) => {
    if (!d) return "—";
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const formatDateTime = (d: string) => {
    if (!d) return "—";
    const date = new Date(d);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const fieldLabel = (field: string) => {
    const map: Record<string, string> = {
      startdate: "Start Date",
      originaltargetedcompletiondate: "Original Target",
      targetedcompletiondate: "Target Completion",
    };
    return map[field] || field;
  };

  // Get date change history for a specific milestone
  const getHistoryForMilestone = (milestoneId: string) =>
    dateChangeLogs
      .filter((l) => l.recordid === milestoneId && l.module === "milestone")
      .sort((a, b) => new Date(b.changedon).getTime() - new Date(a.changedon).getTime());

  const historyMilestone = historyMilestoneId
    ? items.find((m) => m.milestoneid === historyMilestoneId)
    : null;
  const historyLogs = historyMilestoneId
    ? getHistoryForMilestone(historyMilestoneId)
    : [];

  return (
    <div className="flex flex-col gap-4 pt-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Milestones</h3>
          <p className="text-sm text-muted-foreground">
            Track key milestones and target date changes.
          </p>
        </div>
        <Button onClick={openAddDialog}>
          <Plus data-icon="inline-start" />
          Add Milestone
        </Button>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Milestone</TableHead>
              <TableHead>Start</TableHead>
              <TableHead>Original Target</TableHead>
              <TableHead>Current Target</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-center">Changes</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={8}
                  className="h-24 text-center text-muted-foreground"
                >
                  No milestones yet. Click "Add Milestone" to get started.
                </TableCell>
              </TableRow>
            ) : (
              items.map((item) => {
                const isDateShifted =
                  item.targetedcompletiondate !==
                  item.originaltargetedcompletiondate;
                const hasHistory =
                  dateChangeLogs.some(
                    (l) =>
                      l.recordid === item.milestoneid &&
                      l.module === "milestone",
                  );
                return (
                  <TableRow key={item.milestoneid}>
                    <TableCell className="font-medium text-foreground max-w-[200px]">
                      <div>{item.name}</div>
                      {item.remarks && (
                        <p className="text-xs text-muted-foreground mt-0.5 truncate">
                          {item.remarks}
                        </p>
                      )}
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap">
                      {formatDate(item.startdate)}
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap">
                      {formatDate(item.originaltargetedcompletiondate)}
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap">
                      {isDateShifted || hasHistory ? (
                        <button
                          onClick={() =>
                            setHistoryMilestoneId(item.milestoneid)
                          }
                          className="flex items-center gap-1.5 hover:underline cursor-pointer group/date transition-colors"
                        >
                          <span className={isDateShifted ? "text-amber-600 font-medium" : ""}>
                            {formatDate(item.targetedcompletiondate)}
                          </span>
                          {isDateShifted && (
                            <AlertTriangle className="size-3.5 text-amber-500 group-hover/date:text-amber-600" />
                          )}
                        </button>
                      ) : (
                        formatDate(item.targetedcompletiondate)
                      )}
                    </TableCell>
                    <TableCell className="text-sm">
                      {getOwnerName(item.ownerorgnodeid)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          STATUS_COLORS[item.status] || STATUS_COLORS["Not Started"]
                        }
                      >
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {item.changecount > 0 ? (
                        <button
                          onClick={() =>
                            setHistoryMilestoneId(item.milestoneid)
                          }
                          className="cursor-pointer"
                        >
                          <Badge variant="outline" className="font-mono hover:bg-muted transition-colors">
                            {item.changecount}
                          </Badge>
                        </button>
                      ) : (
                        <span className="text-muted-foreground text-xs">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditDialog(item.milestoneid)}
                        >
                          <Pencil />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() => setDeleteTarget(item.milestoneid)}
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Milestone" : "Add Milestone"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Milestone details form.
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[65vh] pr-4">
            <form onSubmit={handleSubmit(onSubmit)}>
              <FieldGroup>
                <Field data-invalid={!!errors.name || undefined}>
                  <Label htmlFor="ms-name">Milestone Name</Label>
                  <Input
                    id="ms-name"
                    {...register("name")}
                    placeholder="e.g., Architecture Review"
                    aria-invalid={!!errors.name || undefined}
                  />
                  {errors.name && <FieldError>{errors.name.message}</FieldError>}
                </Field>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.startdate || undefined}>
                    <Label>Start Date</Label>
                    <Controller
                      control={control}
                      name="startdate"
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="Pick start date"
                        />
                      )}
                    />
                    {errors.startdate && (
                      <FieldError>{errors.startdate.message}</FieldError>
                    )}
                  </Field>
                  <Field data-invalid={!!errors.originaltargetedcompletiondate || undefined}>
                    <Label>Original Target</Label>
                    <Controller
                      control={control}
                      name="originaltargetedcompletiondate"
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="Pick target date"
                        />
                      )}
                    />
                    {errors.originaltargetedcompletiondate && (
                      <FieldError>
                        {errors.originaltargetedcompletiondate.message}
                      </FieldError>
                    )}
                  </Field>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.targetedcompletiondate || undefined}>
                    <Label>Current Target</Label>
                    <Controller
                      control={control}
                      name="targetedcompletiondate"
                      render={({ field }) => (
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="Pick current target"
                        />
                      )}
                    />
                    {errors.targetedcompletiondate && (
                      <FieldError>
                        {errors.targetedcompletiondate.message}
                      </FieldError>
                    )}
                  </Field>
                  <Field data-invalid={!!errors.status || undefined}>
                    <Label>Status</Label>
                    <Controller
                      control={control}
                      name="status"
                      render={({ field }) => (
                        <Combobox
                          value={field.value || null}
                          onValueChange={(v: string | null) =>
                            field.onChange(v ?? "")
                          }
                          items={statusItems}
                        >
                          <ComboboxInput placeholder="Select status" />
                          <ComboboxContent>
                            <ComboboxEmpty>No match.</ComboboxEmpty>
                            <ComboboxList>
                              {(item: string) => (
                                <ComboboxItem key={item} value={item}>
                                  {item}
                                </ComboboxItem>
                              )}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      )}
                    />
                    {errors.status && (
                      <FieldError>{errors.status.message}</FieldError>
                    )}
                  </Field>
                </div>

                <Field data-invalid={!!errors.ownerorgnodeid || undefined}>
                  <Label>Owner</Label>
                  <Controller
                    control={control}
                    name="ownerorgnodeid"
                    render={({ field }) => {
                      const selectedName =
                        orgNodes.find(
                          (n) => n.programmeorgnodeid === field.value,
                        )?.displayname ?? null;
                      return (
                        <Combobox
                          value={selectedName}
                          onValueChange={(name: string | null) => {
                            const node = orgNodes.find(
                              (n) => n.displayname === name,
                            );
                            field.onChange(node?.programmeorgnodeid ?? "");
                          }}
                          items={orgNodeNames}
                        >
                          <ComboboxInput placeholder="Select owner" />
                          <ComboboxContent>
                            <ComboboxEmpty>No match.</ComboboxEmpty>
                            <ComboboxList>
                              {(name: string) => (
                                <ComboboxItem key={name} value={name}>
                                  {name}
                                </ComboboxItem>
                              )}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      );
                    }}
                  />
                  {errors.ownerorgnodeid && (
                    <FieldError>{errors.ownerorgnodeid.message}</FieldError>
                  )}
                </Field>

                <Field>
                  <Label htmlFor="ms-remarks">Remarks</Label>
                  <Textarea
                    id="ms-remarks"
                    {...register("remarks")}
                    placeholder="Additional notes..."
                  />
                </Field>
              </FieldGroup>

              <DialogFooter className="mt-6">
                <DialogClose asChild>
                  <Button type="button" variant="outline" disabled={isSaving}>
                    Cancel
                  </Button>
                </DialogClose>
                <Button type="submit" disabled={isSaving}>
                  {isSaving && <Spinner data-icon="inline-start" />}
                  Save
                </Button>
              </DialogFooter>
            </form>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Date Change Reason Dialog */}
      <Dialog open={showReasonDialog} onOpenChange={setShowReasonDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Date Change Reason</DialogTitle>
            <DialogDescription>
              The following date(s) were modified. Please provide a reason — this
              will be logged for audit.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            {pendingDateChanges.map((c) => (
              <div
                key={c.field}
                className="flex items-center gap-2 text-sm rounded-lg bg-muted px-3 py-2"
              >
                <span className="text-muted-foreground text-xs font-medium">
                  {fieldLabel(c.field)}:
                </span>
                <span className="line-through text-destructive">
                  {formatDate(c.oldDate)}
                </span>
                <ArrowRight className="size-3 text-muted-foreground shrink-0" />
                <span className="font-medium">{formatDate(c.newDate)}</span>
              </div>
            ))}
          </div>
          <FieldGroup>
            <Field>
              <Label htmlFor="change-reason">Reason</Label>
              <Textarea
                id="change-reason"
                value={dateChangeReason}
                onChange={(e) => setDateChangeReason(e.target.value)}
                placeholder="e.g., Stakeholder review delayed..."
              />
            </Field>
          </FieldGroup>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowReasonDialog(false);
                setPendingDateChanges([]);
                setPendingFormData(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleReasonConfirm}
              disabled={!dateChangeReason.trim()}
            >
              Confirm & Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Date History Dialog — shows when clicking a shifted date or change count */}
      <Dialog
        open={!!historyMilestoneId}
        onOpenChange={(open) => {
          if (!open) setHistoryMilestoneId(null);
        }}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              Date Change History
            </DialogTitle>
            <DialogDescription>
              {historyMilestone
                ? `Change log for "${historyMilestone.name}"`
                : "Date change history"}
            </DialogDescription>
          </DialogHeader>

          {historyLogs.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground text-sm">
              No date changes recorded for this milestone.
            </div>
          ) : (
            <ScrollArea className="max-h-[50vh]">
              <div className="flex flex-col gap-3">
                {historyLogs.map((log) => {
                  const sevenDaysAgo = new Date(Date.now() - 7 * 86400000);
                  const isRecent = new Date(log.changedon) >= sevenDaysAgo;
                  return (
                    <div
                      key={log.datechangelogid}
                      className={`rounded-lg border px-4 py-3 transition-colors ${
                        isRecent
                          ? "border-amber-200 bg-amber-50/50 dark:border-amber-800/30 dark:bg-amber-950/10"
                          : "bg-card"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <Badge variant="secondary" className="text-xs font-normal">
                          {fieldLabel(log.fieldname)}
                        </Badge>
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Clock className="size-3" />
                          {formatDateTime(log.changedon)}
                          {isRecent && (
                            <Badge
                              variant="destructive"
                              className="px-1.5 py-0 text-[10px] leading-4"
                            >
                              Recent
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="line-through text-destructive">
                          {formatDate(log.olddate)}
                        </span>
                        <ArrowRight className="size-3 text-muted-foreground shrink-0" />
                        <span className="font-medium">
                          {formatDate(log.newdate)}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1.5 italic">
                        "{log.reason}"
                      </p>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setHistoryMilestoneId(null)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete milestone?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this milestone. This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
