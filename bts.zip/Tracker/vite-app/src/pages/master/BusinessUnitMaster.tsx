import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const schema = z.object({
  name: z.string().min(2, "Name is required"),
  description: z.string().min(1, "Description is required"),
  capabilityid: z.string().min(1, "Capability selection is required"),
});

type FormData = z.infer<typeof schema>;

export function BusinessUnitMaster() {
  const {
    businessUnits,
    capabilities,
    addBusinessUnit,
    updateBusinessUnit,
    deleteBusinessUnit,
  } = useAppStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const capabilityNames = capabilities.map((c) => c.name);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const openAddDialog = () => {
    reset({ name: "", description: "", capabilityid: "" });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = businessUnits.find((b) => b.businessunitid === id);
    if (item) {
      reset({
        name: item.name,
        description: item.description,
        capabilityid: item.capabilityid,
      });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    setIsSaving(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      if (editingId) {
        updateBusinessUnit(editingId, data);
        toast.success("Business Unit updated successfully");
      } else {
        addBusinessUnit(data);
        toast.success("Business Unit added successfully");
      }
      setIsDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      deleteBusinessUnit(deleteTarget);
      toast.success("Business Unit deleted successfully");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete business unit");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-foreground">
            Business Units
          </h2>
          <p className="text-muted-foreground mt-1">
            Manage global business units under capabilities.
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddDialog}>
              <Plus data-icon="inline-start" />
              Add Business Unit
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Edit Business Unit" : "Add Business Unit"}
              </DialogTitle>
              <DialogDescription className="sr-only">
                Make changes to your business unit data here.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)}>
              <FieldGroup>
                <Field data-invalid={!!errors.capabilityid || undefined}>
                  <Label htmlFor="bu-cap">Capability Context</Label>
                  <Controller
                    control={control}
                    name="capabilityid"
                    render={({ field }) => {
                      const selectedName =
                        capabilities.find(
                          (c) => c.capabilityid === field.value,
                        )?.name ?? null;
                      return (
                        <Combobox
                          value={selectedName}
                          onValueChange={(name: string | null) => {
                            const cap = capabilities.find(
                              (c) => c.name === name,
                            );
                            field.onChange(cap?.capabilityid ?? "");
                          }}
                          items={capabilityNames}
                        >
                          <ComboboxInput placeholder="Select a capability" />
                          <ComboboxContent>
                            <ComboboxEmpty>
                              No capabilities found.
                            </ComboboxEmpty>
                            <ComboboxList>
                              {(name: string) => (
                                <ComboboxItem key={name} value={name}>
                                  {name}
                                </ComboboxItem>
                              )}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      );
                    }}
                  />
                  {errors.capabilityid && (
                    <FieldError>{errors.capabilityid.message}</FieldError>
                  )}
                </Field>

                <Field data-invalid={!!errors.name || undefined}>
                  <Label htmlFor="bu-name">Name</Label>
                  <Input
                    id="bu-name"
                    {...register("name")}
                    placeholder="e.g., Digital Marketing"
                    aria-invalid={!!errors.name || undefined}
                  />
                  {errors.name && (
                    <FieldError>{errors.name.message}</FieldError>
                  )}
                </Field>

                <Field data-invalid={!!errors.description || undefined}>
                  <Label htmlFor="bu-desc">Description</Label>
                  <Textarea
                    id="bu-desc"
                    {...register("description")}
                    placeholder="Details about this BU"
                    aria-invalid={!!errors.description || undefined}
                  />
                  {errors.description && (
                    <FieldError>{errors.description.message}</FieldError>
                  )}
                </Field>
              </FieldGroup>

              <DialogFooter className="mt-6">
                <DialogClose asChild>
                  <Button type="button" variant="outline" disabled={isSaving}>
                    Cancel
                  </Button>
                </DialogClose>
                <Button type="submit" disabled={isSaving}>
                  {isSaving && <Spinner data-icon="inline-start" />}
                  Save
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Business Unit</TableHead>
              <TableHead>Capability</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="w-[120px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {businessUnits.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={4}
                  className="h-24 text-center text-muted-foreground"
                >
                  No business units found.
                </TableCell>
              </TableRow>
            ) : (
              businessUnits.map((item) => {
                const capabilityName =
                  capabilities.find(
                    (c) => c.capabilityid === item.capabilityid,
                  )?.name || "Unknown";
                return (
                  <TableRow key={item.businessunitid}>
                    <TableCell className="font-medium text-foreground">
                      {item.name}
                    </TableCell>
                    <TableCell>{capabilityName}</TableCell>
                    <TableCell className="text-muted-foreground truncate max-w-[200px]">
                      {item.description}
                    </TableCell>
                    <TableCell className="text-right flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(item.businessunitid)}
                      >
                        <Pencil />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => setDeleteTarget(item.businessunitid)}
                      >
                        <Trash2 />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Controlled delete confirmation dialog */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this business unit. This action cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
