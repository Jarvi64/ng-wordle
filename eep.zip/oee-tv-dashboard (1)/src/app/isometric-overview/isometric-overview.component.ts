import { Component, inject, signal, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../data.service';
import { LineData } from '../models';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

interface IsoWorkcenter extends LineData {
  mesh?: THREE.Group;
  status: string;
}

@Component({
  selector: 'app-isometric-overview',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule, DecimalPipe],
  template: `
    <div class="min-h-screen bg-[#f0f4f8] text-slate-900 overflow-hidden flex flex-col font-sans">
      <!-- Header -->
      <header class="bg-[#0f4a8a] text-white px-6 py-0 flex justify-between items-center z-20 shadow-md h-16">
        <div class="flex items-center gap-4 h-full">
          <div class="flex items-center gap-2 mr-8">
            <mat-icon class="text-orange-400">rocket_launch</mat-icon>
            <h1 class="text-xl font-bold tracking-tight">AMMO-TECH MFG</h1>
          </div>
          <nav class="flex h-full">
            <a routerLink="/" class="px-4 flex items-center h-full border-b-4 border-transparent hover:bg-white/10 transition-colors">Dashboard</a>
            <a routerLink="/overview" class="px-4 flex items-center h-full border-b-4 border-white bg-white/10 font-medium">Floor Plan</a>
            <a routerLink="/" class="px-4 flex items-center h-full border-b-4 border-transparent hover:bg-white/10 transition-colors">Equipment</a>
            <a routerLink="/" class="px-4 flex items-center h-full border-b-4 border-transparent hover:bg-white/10 transition-colors">Reports</a>
            <a routerLink="/" class="px-4 flex items-center h-full border-b-4 border-transparent hover:bg-white/10 transition-colors">Settings</a>
          </nav>
        </div>
      </header>

      <!-- Main Content -->
      <div class="flex-1 flex relative overflow-hidden bg-[#f0f4f8]">
        
        <!-- Three.js Container -->
        <div #rendererContainer class="flex-1 relative outline-none" 
             (click)="onCanvasClick($any($event))"
             (keydown.enter)="onCanvasClick($any($event))"
             tabindex="0"
             role="application"
             aria-label="3D Plant Floor View">
          <!-- Loading Overlay -->
          @if (isLoading()) {
            <div class="absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#f0f4f8]">
              <div class="w-16 h-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mb-4"></div>
              <p class="text-blue-600 font-bold tracking-widest uppercase animate-pulse">Initializing 3D Environment...</p>
            </div>
          }

          <!-- Title Overlay -->
          <h2 class="absolute top-6 left-6 text-3xl font-bold text-slate-800 z-10 pointer-events-none">Live Shopfloor Monitor & OEE Dashboard</h2>

          <!-- Line OEE Overlay -->
          <div class="absolute top-20 left-6 flex flex-col gap-4 pointer-events-none z-10 transition-all duration-500 ease-in-out" [class.-translate-x-full]="selectedWc()">
            <div class="bg-white/90 backdrop-blur-sm border border-slate-200 px-5 py-4 rounded-xl shadow-lg flex flex-col items-start min-w-[280px]">
              <div class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                <mat-icon class="text-sm">speed</mat-icon> Live Line OEE
              </div>
              <div class="flex flex-col gap-4 w-full">
                @for (line of getLineOEEs(); track line.name) {
                  <div class="flex flex-col w-full">
                    <div class="flex justify-between items-center w-full mb-1.5">
                      <span class="text-sm font-bold text-slate-700">{{ line.name }}</span>
                      <span class="text-sm font-bold" [ngClass]="{'text-emerald-600': line.oee >= 80, 'text-amber-600': line.oee >= 60 && line.oee < 80, 'text-rose-600': line.oee < 60}">{{ line.oee | number:'1.1-1' }}%</span>
                    </div>
                    <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div class="h-full rounded-full transition-all duration-1000" [ngClass]="{'bg-emerald-500': line.oee >= 80, 'bg-amber-500': line.oee >= 60 && line.oee < 80, 'bg-rose-500': line.oee < 60}" [style.width.%]="line.oee"></div>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Controls Help -->
          <div class="absolute bottom-6 left-6 bg-white/80 backdrop-blur-sm p-3 rounded-xl border border-slate-200 text-[10px] text-slate-600 font-medium uppercase tracking-wider flex gap-4 shadow-sm pointer-events-none">
            <div class="flex items-center gap-2"><mat-icon class="text-sm w-4 h-4">mouse</mat-icon> Rotate</div>
            <div class="flex items-center gap-2"><mat-icon class="text-sm w-4 h-4">pan_tool</mat-icon> Right Click Pan</div>
            <div class="flex items-center gap-2"><mat-icon class="text-sm w-4 h-4">zoom_in</mat-icon> Scroll Zoom</div>
          </div>
        </div>

        <!-- Sidebar Details -->
        <div class="w-[400px] bg-white border-l-4 border-[#0f4a8a] shadow-2xl flex flex-col transition-all duration-500 ease-in-out z-30 m-4 rounded-xl overflow-hidden"
             [class.translate-x-[120%]]="!selectedWc()"
             [class.absolute]="true"
             [class.right-0]="true"
             [class.top-0]="true"
             [class.bottom-0]="true">
          
          @if (selectedWc(); as wc) {
            <div class="bg-[#0f4a8a] text-white p-4 flex justify-between items-center">
              <h2 class="text-lg font-bold tracking-tight">{{ wc.lineName }}</h2>
              <button (click)="deselectWorkcenter()" class="text-white/70 hover:text-white transition-colors">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="p-6 flex-1 overflow-y-auto custom-scrollbar">
              
              <!-- Top Section: Gauge and Stats -->
              <div class="flex gap-6 mb-8">
                <!-- OEE Gauge -->
                <div class="flex-1 flex flex-col items-center justify-center">
                  <div class="relative w-32 h-20 overflow-hidden mb-2">
                    <svg class="w-full h-full" viewBox="0 0 100 50">
                      <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke="#e2e8f0" stroke-width="12" stroke-linecap="round" />
                      <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" [attr.stroke]="getOeeColor(wc.oee)" stroke-width="12"
                            stroke-dasharray="125.6" [attr.stroke-dashoffset]="125.6 - (125.6 * wc.oee / 100)"
                            stroke-linecap="round" class="transition-all duration-1000 ease-out" />
                    </svg>
                    <div class="absolute bottom-0 left-0 w-full text-center">
                      <span class="text-2xl font-bold text-slate-800">{{ wc.oee | number:'1.0-0' }}%</span>
                    </div>
                  </div>
                  <div class="text-xs font-bold text-slate-500 uppercase tracking-wider">OEE</div>
                </div>

                <!-- Plant OEE Stats -->
                <div class="flex-1 flex flex-col justify-center gap-2 text-sm">
                  <div class="flex justify-between items-center">
                    <span class="text-slate-600 font-medium">Availability</span>
                    <span class="font-bold text-slate-800">{{ wc.availabilityRate | number:'1.0-0' }}%</span>
                  </div>
                  <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div class="bg-blue-500 h-full" [style.width.%]="wc.availabilityRate"></div>
                  </div>
                  
                  <div class="flex justify-between items-center mt-2">
                    <span class="text-slate-600 font-medium">Performance</span>
                    <span class="font-bold text-slate-800">{{ wc.performanceRate | number:'1.0-0' }}%</span>
                  </div>
                  <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div class="bg-blue-500 h-full" [style.width.%]="wc.performanceRate"></div>
                  </div>

                  <div class="flex justify-between items-center mt-2">
                    <span class="text-slate-600 font-medium">Quality</span>
                    <span class="font-bold text-slate-800">{{ wc.qualityRate | number:'1.0-0' }}%</span>
                  </div>
                  <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div class="bg-blue-500 h-full" [style.width.%]="wc.qualityRate"></div>
                  </div>
                </div>
              </div>

              <!-- Current Production -->
              <div class="mb-6 border-t border-slate-200 pt-4">
                <div class="text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Current Status</div>
                <div class="flex items-center gap-3">
                  <div class="w-4 h-4 rounded-full shadow-inner" [style.backgroundColor]="getStatusColor(wc)"></div>
                  <div class="text-lg font-bold text-slate-800">
                    {{ wc.downtimeReason ? 'Downtime: ' + wc.downtimeReason : (wc.oee < 75 ? 'Warning' : 'Running') }}
                  </div>
                </div>
              </div>

              <!-- Status Feeds -->
              <div class="grid grid-cols-2 gap-4 border-t border-slate-200 pt-4">
                <div>
                  <div class="text-xs font-bold text-slate-700 mb-3">Machine Status Feed</div>
                  <div class="flex justify-between items-center mb-2 text-xs">
                    <span class="text-slate-600">Power</span>
                    <span class="w-3 h-3 rounded-full" [class.bg-emerald-500]="!wc.downtimeReason" [class.bg-rose-500]="wc.downtimeReason"></span>
                  </div>
                  <div class="flex justify-between items-center mb-2 text-xs">
                    <span class="text-slate-600">Motor</span>
                    <span class="w-3 h-3 rounded-full" [class.bg-emerald-500]="wc.performanceRate > 80" [class.bg-amber-500]="wc.performanceRate <= 80"></span>
                  </div>
                  <div class="flex justify-between items-center mb-2 text-xs">
                    <span class="text-slate-600">Conveyor</span>
                    <span class="w-3 h-3 rounded-full" [class.bg-emerald-500]="wc.availabilityRate > 80" [class.bg-amber-500]="wc.availabilityRate <= 80"></span>
                  </div>
                  <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-600">Sensors</span>
                    <span class="w-3 h-3 rounded-full" [class.bg-emerald-500]="wc.qualityRate > 90" [class.bg-amber-500]="wc.qualityRate <= 90"></span>
                  </div>
                </div>
                
                <div>
                  <div class="text-xs font-bold text-slate-700 mb-3">Maintenance Alerts</div>
                  @if (wc.downtimeReason) {
                    <div class="flex items-center gap-2 mb-2 text-xs text-rose-600 font-medium">
                      <mat-icon class="text-rose-500 text-[16px] w-[16px] h-[16px]">error</mat-icon>
                      <span>{{ wc.downtimeReason }}</span>
                    </div>
                  }
                  @if (wc.performanceRate < 80) {
                    <div class="flex items-center gap-2 mb-2 text-xs text-amber-600">
                      <mat-icon class="text-amber-500 text-[16px] w-[16px] h-[16px]">warning</mat-icon>
                      <span>Inspect belt tension</span>
                    </div>
                  }
                  @if (wc.qualityRate < 90) {
                    <div class="flex items-center gap-2 text-xs text-amber-600">
                      <mat-icon class="text-amber-500 text-[16px] w-[16px] h-[16px]">warning</mat-icon>
                      <span>Clean optical sensors</span>
                    </div>
                  }
                  @if (!wc.downtimeReason && wc.performanceRate >= 80 && wc.qualityRate >= 90) {
                    <div class="flex items-center gap-2 text-xs text-slate-500 italic">
                      <mat-icon class="text-emerald-500 text-[16px] w-[16px] h-[16px]">check_circle</mat-icon>
                      <span>No active alerts</span>
                    </div>
                  }
                </div>
              </div>

              <a [routerLink]="['/line', wc.id]" class="mt-6 w-full flex items-center justify-center gap-2 py-3 bg-[#0f4a8a] hover:bg-blue-800 text-white rounded-lg font-bold text-sm transition-colors">
                <mat-icon class="text-lg">analytics</mat-icon>
                View Full Details
              </a>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    .custom-scrollbar::-webkit-scrollbar {
      width: 4px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
      background: transparent;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 10px;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
  `]
})
export class IsometricOverviewComponent implements AfterViewInit, OnDestroy {
  @ViewChild('rendererContainer') rendererContainer!: ElementRef;
  
  dataService = inject(DataService);
  lines = this.dataService.lines;
  selectedWc = signal<IsoWorkcenter | null>(null);
  isLoading = signal(true);

  // Three.js Core
  private scene!: THREE.Scene;
  private camera!: THREE.OrthographicCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private animationId!: number;

  // Objects
  private workcenterMeshes: IsoWorkcenter[] = [];
  private floor!: THREE.Mesh;
  private zones: THREE.Group[] = [];
  private conveyors: THREE.Mesh[] = [];
  private products: THREE.Mesh[] = [];
  private gears: THREE.Mesh[] = [];
  private agvs: THREE.Group[] = [];
  private robotArms: THREE.Group[] = [];
  private trolleys: THREE.Group[] = [];
  private forklifts: THREE.Group[] = [];
  private clock = new THREE.Clock();

  // Reusable Resources
  private sharedGeometries: Record<string, THREE.BufferGeometry> = {};
  private sharedMaterials: Record<string, THREE.Material> = {};
  private textures: Record<string, THREE.CanvasTexture> = {};

  getLineOEEs() {
    const lines = new Map<string, { totalOee: number, count: number }>();
    this.lines().forEach(wc => {
      const current = lines.get(wc.lineName) || { totalOee: 0, count: 0 };
      lines.set(wc.lineName, { totalOee: current.totalOee + wc.oee, count: current.count + 1 });
    });
    return Array.from(lines.entries()).map(([name, data]) => ({
      name,
      oee: data.totalOee / data.count
    }));
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.initThree();
      this.initSharedResources();
      this.createEnvironment();
      this.createPlantLayout();
      this.animate();
      this.isLoading.set(false);
    }, 100);
  }

  private initSharedResources() {
    this.textures['floor'] = this.createFloorTexture();
    this.textures['warning'] = this.createWarningTexture();
    this.textures['conveyor'] = this.createConveyorTexture();

    this.sharedGeometries = {
      base: new THREE.BoxGeometry(140, 20, 140),
      body: new THREE.BoxGeometry(110, 120, 110), // Fixed height for performance
      cap: new THREE.BoxGeometry(120, 15, 120),
      panel: new THREE.BoxGeometry(15, 50, 40),
      screen: new THREE.PlaneGeometry(30, 30),
      arm: new THREE.CylinderGeometry(5, 5, 80),
      pole: new THREE.CylinderGeometry(3, 3, 80),
      bulb: new THREE.CylinderGeometry(8, 8, 20),
      ring: new THREE.TorusGeometry(80, 2, 16, 32),
      pipe: new THREE.CylinderGeometry(12, 12, 6000, 12),
      support: new THREE.BoxGeometry(20, 400, 20),
      vent: new THREE.PlaneGeometry(40, 40),
      gear: new THREE.CylinderGeometry(15, 15, 5, 16)
    };

    this.sharedMaterials = {
      base: new THREE.MeshLambertMaterial({ color: 0x94a3b8 }),
      machineBlue: new THREE.MeshLambertMaterial({ color: 0x1d4ed8 }),
      machineGrey: new THREE.MeshLambertMaterial({ color: 0xe2e8f0 }),
      baseWarning: new THREE.MeshLambertMaterial({ map: this.textures['warning'] }),
      cap: new THREE.MeshLambertMaterial({ color: 0xe2e8f0 }),
      panel: new THREE.MeshLambertMaterial({ color: 0xcbd5e1 }),
      screen: new THREE.MeshBasicMaterial({ color: 0x0f172a }),
      arm: new THREE.MeshLambertMaterial({ color: 0xf97316 }), // Orange robot arms
      pole: new THREE.MeshLambertMaterial({ color: 0x64748b }),
      pipe: new THREE.MeshLambertMaterial({ color: 0xcbd5e1 }),
      support: new THREE.MeshLambertMaterial({ color: 0x94a3b8 }),
      floor: new THREE.MeshLambertMaterial({ color: 0xf0f4f8 }), // Solid flat floor
      vent: new THREE.MeshBasicMaterial({ color: 0x334155 }),
      gear: new THREE.MeshLambertMaterial({ color: 0x64748b })
    };
  }

  private createFloorTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;
    
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, 512, 512);
    
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2;
    for (let i = 0; i <= 512; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }

    for (let i = 0; i < 5000; i++) {
      ctx.fillStyle = Math.random() > 0.5 ? 'rgba(0,0,0,0.03)' : 'rgba(0,0,0,0.01)';
      ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 2);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(20, 20);
    return texture;
  }

  private createWarningTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    
    ctx.fillStyle = '#facc15';
    ctx.fillRect(0, 0, 256, 256);
    
    ctx.fillStyle = '#000000';
    for (let i = -256; i < 512; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + 128, 256);
      ctx.lineTo(i + 128 + 32, 256);
      ctx.lineTo(i + 32, 0);
      ctx.fill();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  private createConveyorTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;
    
    // Base color
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(0, 0, 128, 128);
    
    // Tread pattern
    ctx.fillStyle = '#94a3b8';
    for (let i = 0; i < 8; i++) {
      ctx.fillRect(0, i * 16 + 4, 128, 8);
    }
    
    // Side rails
    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, 0, 10, 128);
    ctx.fillRect(118, 0, 10, 128);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  ngOnDestroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
    if (this.controls) {
      this.controls.dispose();
    }

    // Cleanup Dynamic Resources
    this.conveyors.forEach(c => {
      if (c.material instanceof THREE.Material) c.material.dispose();
      if (c.userData['texture']) c.userData['texture'].dispose();
    });
    this.products.forEach(p => {
      if (p.material instanceof THREE.Material) p.material.dispose();
    });

    // Cleanup Shared Resources
    if (this.sharedGeometries) {
      Object.values(this.sharedGeometries).forEach((g) => g.dispose());
    }
    if (this.sharedMaterials) {
      Object.values(this.sharedMaterials).forEach((m) => m.dispose());
    }
    if (this.textures) {
      Object.values(this.textures).forEach((t) => t.dispose());
    }
  }

  @HostListener('window:resize')
  onWindowResize() {
    if (!this.rendererContainer) return;
    const width = this.rendererContainer.nativeElement.clientWidth;
    const height = this.rendererContainer.nativeElement.clientHeight;
    
    const aspect = width / height;
    const d = 1200;
    this.camera.left = -d * aspect;
    this.camera.right = d * aspect;
    this.camera.top = d;
    this.camera.bottom = -d;
    
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private initThree() {
    const width = this.rendererContainer.nativeElement.clientWidth;
    const height = this.rendererContainer.nativeElement.clientHeight;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xf0f4f8);

    // Camera
    const aspect = width / height;
    const d = 1200;
    this.camera = new THREE.OrthographicCamera(-d * aspect, d * aspect, d, -d, 1, 10000);
    this.camera.position.set(1500, 1500, 1500);
    this.camera.lookAt(0, 0, 0);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.rendererContainer.nativeElement.appendChild(this.renderer.domElement);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2.1;
    this.controls.minZoom = 0.2;
    this.controls.maxZoom = 5;
    this.controls.target.set(0, 0, 0);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 2.5);
    this.scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.2);
    directionalLight.position.set(1000, 2000, 1000);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 4096;
    directionalLight.shadow.mapSize.height = 4096;
    directionalLight.shadow.camera.left = -3000;
    directionalLight.shadow.camera.right = 3000;
    directionalLight.shadow.camera.top = 3000;
    directionalLight.shadow.camera.bottom = -3000;
    directionalLight.shadow.bias = -0.001;
    this.scene.add(directionalLight);
  }

  private createEnvironment() {
    // Floor
    const floorSize = 6000;
    const floorGeometry = new THREE.PlaneGeometry(floorSize, floorSize);
    this.floor = new THREE.Mesh(floorGeometry, this.sharedMaterials['floor']);
    this.floor.rotation.x = -Math.PI / 2;
    this.floor.receiveShadow = true;
    this.scene.add(this.floor);

    // Yellow Paths
    this.createGangways();

    // Racks and AGVs
    this.createPalletRacks();
    this.createAGVs();
    
    // Add Forklifts
    for(let i=0; i<4; i++) {
        const forklift = this.createForklift();
        forklift.position.set((Math.random() - 0.5) * 3000, 0, (Math.random() - 0.5) * 3000);
        forklift.rotation.y = Math.random() * Math.PI * 2;
        
        forklift.userData = {
          speed: 80 + Math.random() * 40,
          direction: Math.random() > 0.5 ? 1 : -1,
          axis: Math.random() > 0.5 ? 'x' : 'z',
          bounds: 1500
        };
        
        this.forklifts.push(forklift);
        this.scene.add(forklift);
    }
    
    // Add Trolleys
    for(let i=0; i<3; i++) {
        const trolley = this.createTrolley();
        trolley.position.set((Math.random() - 0.5) * 3000, 0, (Math.random() - 0.5) * 3000);
        trolley.rotation.y = Math.random() * Math.PI * 2;
        
        trolley.userData = {
          speed: 60 + Math.random() * 30,
          direction: Math.random() > 0.5 ? 1 : -1,
          axis: Math.random() > 0.5 ? 'x' : 'z',
          bounds: 1500
        };
        
        this.trolleys.push(trolley);
        this.scene.add(trolley);
    }

    // Add Robot Arms
    for(let i=0; i<4; i++) {
        const robot = this.createRobotArm();
        robot.position.set((Math.random() - 0.5) * 2000, 0, (Math.random() - 0.5) * 2000);
        robot.rotation.y = Math.random() * Math.PI * 2;
        
        robot.userData = {
          baseRotationSpeed: (Math.random() - 0.5) * 2,
          armRotationSpeed: (Math.random() - 0.5) * 3
        };
        
        this.robotArms.push(robot);
        this.scene.add(robot);
    }

    // Add Safety Fences
    this.scene.add(this.createSafetyFence(-1000, -1000, 1000, 0));
    this.scene.add(this.createSafetyFence(1000, -1000, 1000, 0));
    this.scene.add(this.createSafetyFence(-1000, 1000, 1000, 0));
    this.scene.add(this.createSafetyFence(1000, 1000, 1000, 0));
    this.scene.add(this.createSafetyFence(-1500, 0, 2000, Math.PI / 2));
    this.scene.add(this.createSafetyFence(1500, 0, 2000, Math.PI / 2));
  }

  private createGangways() {
    const gangways = new THREE.Group();
    const createPath = (w: number, l: number, x: number, z: number, rotY: number) => {
      const group = new THREE.Group();
      const greenMat = new THREE.MeshLambertMaterial({ color: 0x22c55e }); // Green
      const yellowMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 }); // Yellow
      
      const floor = new THREE.Mesh(new THREE.PlaneGeometry(w, l), greenMat);
      floor.rotation.x = -Math.PI / 2;
      floor.receiveShadow = true;
      group.add(floor);

      const border1 = new THREE.Mesh(new THREE.PlaneGeometry(10, l), yellowMat);
      border1.rotation.x = -Math.PI / 2;
      border1.position.set(-w/2 + 5, 0.5, 0);
      group.add(border1);

      const border2 = new THREE.Mesh(new THREE.PlaneGeometry(10, l), yellowMat);
      border2.rotation.x = -Math.PI / 2;
      border2.position.set(w/2 - 5, 0.5, 0);
      group.add(border2);

      group.position.set(x, 1, z);
      group.rotation.y = rotY;
      return group;
    };

    // Main horizontal path
    gangways.add(createPath(300, 6000, 0, 0, Math.PI / 2));
    
    // Vertical paths
    gangways.add(createPath(300, 3000, -1000, 0, 0));
    gangways.add(createPath(300, 3000, 1000, 0, 0));

    this.scene.add(gangways);
  }

  private createPalletRacks() {
    const rackGroup = new THREE.Group();
    const rackMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, metalness: 0.6, roughness: 0.4 }); // Blue racks
    const shelfMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.2, roughness: 0.8 });
    const boxMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.9 }); // Cardboard

    const createRackUnit = (x: number, z: number) => {
      const unit = new THREE.Group();
      
      // Uprights
      for (let i = 0; i < 2; i++) {
        for (let j = 0; j < 2; j++) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(4, 200, 4), rackMat);
          post.position.set(i * 100 - 50, 100, j * 40 - 20);
          post.castShadow = true;
          unit.add(post);
        }
      }

      // Shelves and Boxes
      for (let level = 1; level <= 4; level++) {
        const shelf = new THREE.Mesh(new THREE.BoxGeometry(104, 2, 44), shelfMat);
        shelf.position.set(0, level * 40, 0);
        shelf.castShadow = true;
        unit.add(shelf);

        // Add random boxes on shelf
        if (Math.random() > 0.2) {
          const box = new THREE.Mesh(new THREE.BoxGeometry(30, 25, 30), boxMat);
          box.position.set((Math.random() - 0.5) * 50, level * 40 + 13.5, 0);
          box.castShadow = true;
          unit.add(box);
        }
      }
      
      unit.position.set(x, 0, z);
      return unit;
    };

    // Add rows of racks
    for (let i = -2000; i <= 2000; i += 110) {
      rackGroup.add(createRackUnit(i, -1500));
      rackGroup.add(createRackUnit(i, 1500));
    }

    this.scene.add(rackGroup);
  }

  private createAGVs() {
    const agvGeom = new THREE.BoxGeometry(60, 20, 40);
    const agvMat = new THREE.MeshLambertMaterial({ color: 0xf59e0b });
    const wheelGeom = new THREE.CylinderGeometry(8, 8, 44, 16);
    const wheelMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });

    for (let i = 0; i < 5; i++) {
      const agv = new THREE.Group();
      
      const body = new THREE.Mesh(agvGeom, agvMat);
      body.position.y = 15;
      body.castShadow = true;
      agv.add(body);

      const wheels = new THREE.Mesh(wheelGeom, wheelMat);
      wheels.rotation.x = Math.PI / 2;
      wheels.position.y = 8;
      wheels.castShadow = true;
      agv.add(wheels);

      // Add a small load
      if (Math.random() > 0.3) {
        const load = new THREE.Mesh(new THREE.BoxGeometry(40, 30, 30), new THREE.MeshLambertMaterial({ color: 0x64748b }));
        load.position.y = 40;
        load.castShadow = true;
        agv.add(load);
      }

      agv.position.set((Math.random() - 0.5) * 4000, 0, (Math.random() > 0.5 ? 1 : -1) * 1000);
      agv.userData = {
        speed: 80 + Math.random() * 40,
        direction: Math.random() > 0.5 ? 1 : -1,
        axis: Math.random() > 0.5 ? 'x' : 'z',
        bounds: 2000
      };
      
      this.agvs.push(agv);
      this.scene.add(agv);
    }
  }

  private createForklift(): THREE.Group {
    const group = new THREE.Group();
    const yellowMat = new THREE.MeshLambertMaterial({ color: 0xfacc15 });
    const darkMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const greyMat = new THREE.MeshLambertMaterial({ color: 0x94a3b8 });

    // Body
    const body = new THREE.Mesh(new THREE.BoxGeometry(40, 20, 25), yellowMat);
    body.position.y = 15;
    body.castShadow = true;
    group.add(body);

    // Cabin
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(20, 25, 20), darkMat);
    cabin.position.set(-5, 35, 0);
    cabin.castShadow = true;
    group.add(cabin);

    // Mast
    const mast = new THREE.Mesh(new THREE.BoxGeometry(5, 50, 20), greyMat);
    mast.position.set(22.5, 30, 0);
    mast.castShadow = true;
    group.add(mast);

    // Forks
    const fork1 = new THREE.Mesh(new THREE.BoxGeometry(30, 2, 4), greyMat);
    fork1.position.set(40, 5, 6);
    fork1.castShadow = true;
    group.add(fork1);

    const fork2 = new THREE.Mesh(new THREE.BoxGeometry(30, 2, 4), greyMat);
    fork2.position.set(40, 5, -6);
    fork2.castShadow = true;
    group.add(fork2);

    // Wheels
    const wheelGeom = new THREE.CylinderGeometry(6, 6, 4, 16);
    const wheelPositions = [
      [-12, 6, 14], [12, 6, 14],
      [-12, 6, -14], [12, 6, -14]
    ];
    
    wheelPositions.forEach(pos => {
      const wheel = new THREE.Mesh(wheelGeom, darkMat);
      wheel.position.set(pos[0], pos[1], pos[2]);
      wheel.rotation.x = Math.PI / 2;
      wheel.castShadow = true;
      group.add(wheel);
    });

    return group;
  }

  private createTrolley(): THREE.Group {
    const group = new THREE.Group();
    const mat = new THREE.MeshLambertMaterial({ color: 0x475569 }); // Slate 600
    const wheelMat = new THREE.MeshLambertMaterial({ color: 0x111111 });

    // Base
    const base = new THREE.Mesh(new THREE.BoxGeometry(20, 2, 30), mat);
    base.position.y = 4;
    base.castShadow = true;
    group.add(base);

    // Sides
    const side1 = new THREE.Mesh(new THREE.BoxGeometry(20, 15, 2), mat);
    side1.position.set(0, 12.5, 14);
    side1.castShadow = true;
    group.add(side1);

    const side2 = new THREE.Mesh(new THREE.BoxGeometry(20, 15, 2), mat);
    side2.position.set(0, 12.5, -14);
    side2.castShadow = true;
    group.add(side2);

    const side3 = new THREE.Mesh(new THREE.BoxGeometry(2, 15, 26), mat);
    side3.position.set(9, 12.5, 0);
    side3.castShadow = true;
    group.add(side3);

    const side4 = new THREE.Mesh(new THREE.BoxGeometry(2, 15, 26), mat);
    side4.position.set(-9, 12.5, 0);
    side4.castShadow = true;
    group.add(side4);

    // Wheels
    const wheelGeom = new THREE.CylinderGeometry(3, 3, 2, 8);
    wheelGeom.rotateZ(Math.PI / 2);
    const positions = [
      [-8, 3, 12], [8, 3, 12], [-8, 3, -12], [8, 3, -12]
    ];
    positions.forEach(pos => {
      const wheel = new THREE.Mesh(wheelGeom, wheelMat);
      wheel.position.set(pos[0], pos[1], pos[2]);
      wheel.castShadow = true;
      group.add(wheel);
    });

    return group;
  }

  private createRobotArm(): THREE.Group {
    const robot = new THREE.Group();
    
    // Base
    const baseGeom = new THREE.CylinderGeometry(15, 20, 10, 16);
    const baseMat = new THREE.MeshLambertMaterial({ color: 0x334155 });
    const base = new THREE.Mesh(baseGeom, baseMat);
    base.position.y = 5;
    base.castShadow = true;
    robot.add(base);

    // Lower Arm
    const lowerArmGeom = new THREE.BoxGeometry(10, 40, 10);
    const armMat = new THREE.MeshLambertMaterial({ color: 0x0ea5e9 }); // Light blue
    const lowerArm = new THREE.Mesh(lowerArmGeom, armMat);
    lowerArm.position.y = 30;
    lowerArm.castShadow = true;
    robot.add(lowerArm);

    // Joint 1
    const joint1Geom = new THREE.SphereGeometry(8, 16, 16);
    const jointMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const joint1 = new THREE.Mesh(joint1Geom, jointMat);
    joint1.position.y = 50;
    joint1.castShadow = true;
    robot.add(joint1);

    // Upper Arm
    const upperArmGeom = new THREE.BoxGeometry(8, 30, 8);
    const upperArm = new THREE.Mesh(upperArmGeom, armMat);
    upperArm.position.set(0, 65, 10);
    upperArm.rotation.x = Math.PI / 4;
    upperArm.castShadow = true;
    robot.add(upperArm);

    // Joint 2
    const joint2 = new THREE.Mesh(joint1Geom, jointMat);
    joint2.position.set(0, 75, 20);
    joint2.castShadow = true;
    robot.add(joint2);

    // End Effector
    const effectorGeom = new THREE.CylinderGeometry(4, 4, 15, 8);
    const effectorMat = new THREE.MeshLambertMaterial({ color: 0x94a3b8 });
    const effector = new THREE.Mesh(effectorGeom, effectorMat);
    effector.position.set(0, 70, 30);
    effector.rotation.x = Math.PI / 2;
    effector.castShadow = true;
    robot.add(effector);

    return robot;
  }

  private createSafetyFence(x: number, z: number, length: number, rotation: number): THREE.Group {
    const fenceGroup = new THREE.Group();
    const postGeom = new THREE.CylinderGeometry(2, 2, 40, 8);
    const postMat = new THREE.MeshLambertMaterial({ color: 0xfacc15 }); // Yellow
    const railGeom = new THREE.CylinderGeometry(1.5, 1.5, length, 8);
    const railMat = new THREE.MeshLambertMaterial({ color: 0xfacc15 });

    // Posts
    for (let i = 0; i <= length; i += 50) {
      const post = new THREE.Mesh(postGeom, postMat);
      post.position.set(i - length / 2, 20, 0);
      post.castShadow = true;
      fenceGroup.add(post);
    }

    // Rails
    const topRail = new THREE.Mesh(railGeom, railMat);
    topRail.rotation.z = Math.PI / 2;
    topRail.position.set(0, 35, 0);
    topRail.castShadow = true;
    fenceGroup.add(topRail);

    const midRail = new THREE.Mesh(railGeom, railMat);
    midRail.rotation.z = Math.PI / 2;
    midRail.position.set(0, 15, 0);
    midRail.castShadow = true;
    fenceGroup.add(midRail);

    fenceGroup.position.set(x, 0, z);
    fenceGroup.rotation.y = rotation;

    return fenceGroup;
  }

  private createWorker(): THREE.Group {
    const worker = new THREE.Group();
    
    // Body (Hi-vis vest)
    const bodyGeom = new THREE.CylinderGeometry(8, 8, 25, 8);
    const bodyMat = new THREE.MeshLambertMaterial({ color: 0xf97316 }); // Orange hi-vis
    const body = new THREE.Mesh(bodyGeom, bodyMat);
    body.position.y = 25;
    body.castShadow = true;
    worker.add(body);

    // Head (Hard hat)
    const headGeom = new THREE.SphereGeometry(6, 16, 16);
    const headMat = new THREE.MeshLambertMaterial({ color: 0xfacc15 }); // Yellow hard hat
    const head = new THREE.Mesh(headGeom, headMat);
    head.position.y = 42;
    head.castShadow = true;
    worker.add(head);

    // Legs
    const legGeom = new THREE.CylinderGeometry(3, 3, 15, 8);
    const legMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const leftLeg = new THREE.Mesh(legGeom, legMat);
    leftLeg.position.set(-3, 7.5, 0);
    const rightLeg = new THREE.Mesh(legGeom, legMat);
    rightLeg.position.set(3, 7.5, 0);
    worker.add(leftLeg, rightLeg);

    return worker;
  }

  private createZone(color: number, x: number, z: number, w: number, l: number) {
    const zoneGroup = new THREE.Group();
    
    // Zone Floor Highlight
    const rectGeom = new THREE.PlaneGeometry(w, l);
    const rectMat = new THREE.MeshBasicMaterial({ 
      color: color, 
      transparent: true, 
      opacity: 0.03,
      side: THREE.DoubleSide
    });
    const rect = new THREE.Mesh(rectGeom, rectMat);
    rect.rotation.x = -Math.PI / 2;
    rect.position.set(x, 0.2, z);
    zoneGroup.add(rect);

    // Zone Border
    const borderGeom = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-w/2, 0, -l/2),
      new THREE.Vector3(w/2, 0, -l/2),
      new THREE.Vector3(w/2, 0, l/2),
      new THREE.Vector3(-w/2, 0, l/2),
      new THREE.Vector3(-w/2, 0, -l/2),
    ]);
    const borderMat = new THREE.LineBasicMaterial({ color: color, transparent: true, opacity: 0.2 });
    const border = new THREE.Line(borderGeom, borderMat);
    border.position.set(x, 0.5, z);
    zoneGroup.add(border);

    this.scene.add(zoneGroup);
    this.zones.push(zoneGroup);
  }

  private createPlantLayout() {
    const rawLines = this.lines();
    const lineMap = new Map<string, LineData[]>();
    for (const wc of rawLines) {
      if (!lineMap.has(wc.lineName)) lineMap.set(wc.lineName, []);
      lineMap.get(wc.lineName)!.push(wc);
    }

    // Complex Layout Configuration
    const lineConfigs = [
      { name: 'Cup Line', x: -2400, z: -800, angle: 0, color: 0x6366f1, type: 'linear' },
      { name: 'Case Line', x: -2400, z: 600, angle: 0, color: 0x6366f1, type: 'parallel' },
      { name: 'Priming Line', x: -600, z: -800, angle: 0, color: 0x10b981, type: 'linear' },
      { name: 'Sealing Line', x: -600, z: 600, angle: 0, color: 0x10b981, type: 'linear' },
      { name: 'Bullet Line', x: 1400, z: -800, angle: 0, color: 0xf59e0b, type: 'linear' },
      { name: 'Loading Line', x: 1400, z: 600, angle: 0, color: 0xf59e0b, type: 'linear' },
    ];

    lineConfigs.forEach(config => {
      const workcenters = lineMap.get(config.name);
      if (!workcenters) return;

      workcenters.sort((a, b) => a.stage - b.stage);

      const lineGroup = new THREE.Group();
      lineGroup.position.set(config.x, 0, config.z);
      lineGroup.rotation.y = config.angle;
      this.scene.add(lineGroup);

      // Create Line Path (Conveyor)
      const lineLength = workcenters.length * 250;
      const conveyorGeom = new THREE.BoxGeometry(lineLength, 8, 60);
      
      // Animated Material for Conveyor
      const lineTexture = this.textures['conveyor'].clone();
      lineTexture.repeat.set(lineLength / 100, 1);
      const conveyorMat = new THREE.MeshStandardMaterial({ 
        map: lineTexture,
        roughness: 0.6,
        metalness: 0.2
      });
      
      const conveyor = new THREE.Mesh(conveyorGeom, conveyorMat);
      conveyor.position.set(lineLength/2 - 125, 4, 0);
      conveyor.receiveShadow = true;
      lineGroup.add(conveyor);
      
      // Store for animation
      this.conveyors.push(conveyor);
      conveyor.userData['texture'] = lineTexture;

      // Add Moving Products
      const productGeom = new THREE.BoxGeometry(25, 25, 25);
      for (let p = 0; p < 6; p++) {
        const productMat = new THREE.MeshLambertMaterial({ 
          color: 0xd97706, // Cardboard box color
        });
        const product = new THREE.Mesh(productGeom, productMat);
        product.position.set(Math.random() * lineLength - 125, 18, 0);
        product.castShadow = true;
        lineGroup.add(product);
        
        product.userData = {
          lineLength: lineLength,
          speed: 50 + Math.random() * 30,
          offset: Math.random() * lineLength
        };
        this.products.push(product);
      }

      // Add Workcenters
      workcenters.forEach((wc, idx) => {
        const posX = idx * 250;
        let posZ = 0;

        // Handle parallel or complex positioning
        if (config.type === 'parallel' && idx > 1 && idx < 4) {
          posZ = (idx % 2 === 0) ? 100 : -100;
          // Add connecting conveyor for parallel
          const connectorGeom = new THREE.BoxGeometry(20, 8, Math.abs(posZ) + 60);
          const connector = new THREE.Mesh(connectorGeom, conveyorMat);
          connector.position.set(posX, 4, posZ/2);
          lineGroup.add(connector);
        }

        const wcGroup = this.createDetailedWorkcenter(wc, config.color);
        wcGroup.position.set(posX, 8, posZ);
        lineGroup.add(wcGroup);

        const isoWc: IsoWorkcenter = {
          ...wc,
          mesh: wcGroup,
          status: wc.downtimeReason ? 'downtime' : (wc.oee < 75 ? 'warning' : 'running')
        };
        this.workcenterMeshes.push(isoWc);
      });
    });
  }

  private createDetailedWorkcenter(wc: LineData, baseColor: number): THREE.Group {
    const idNum = parseInt(wc.id.replace(/\D/g, '') || '0', 10);
    const type = idNum % 3;
    
    if (type === 0) {
      return this.createVasiniWorkcenter(wc);
    } else if (type === 1) {
      return this.createPressingMachine(wc);
    } else {
      return this.createStandardWorkcenter(wc);
    }
  }

  private createEscalatorHopper(redMat: THREE.Material, whiteMat: THREE.Material, darkMat: THREE.Material): THREE.Group {
    const group = new THREE.Group();
    
    // Slanted Conveyor Belt with Texture
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const context = canvas.getContext('2d');
    if (context) {
      context.fillStyle = '#334155';
      context.fillRect(0, 0, 64, 64);
      context.fillStyle = '#1e293b';
      context.fillRect(0, 0, 64, 16);
      context.fillRect(0, 32, 64, 16);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 10);
    
    const beltMat = new THREE.MeshLambertMaterial({ map: texture });
    const belt = new THREE.Mesh(new THREE.BoxGeometry(15, 100, 5), beltMat);
    belt.rotation.x = Math.PI / 4;
    belt.position.set(0, 35, 35);
    belt.userData = { isEscalatorBelt: true, texture: texture };
    group.add(belt);
    
    // Side rails
    const rail1 = new THREE.Mesh(new THREE.BoxGeometry(2, 100, 8), redMat);
    rail1.rotation.x = Math.PI / 4;
    rail1.position.set(8.5, 35, 35);
    group.add(rail1);
    
    const rail2 = new THREE.Mesh(new THREE.BoxGeometry(2, 100, 8), redMat);
    rail2.rotation.x = Math.PI / 4;
    rail2.position.set(-8.5, 35, 35);
    group.add(rail2);

    // Top Hopper
    const hopper = new THREE.Mesh(new THREE.CylinderGeometry(15, 5, 20, 4), whiteMat);
    hopper.rotation.y = Math.PI / 4;
    hopper.position.set(0, 70, 0);
    group.add(hopper);

    // Bottom Collection Bin / Trolley
    const trolley = this.createTrolley();
    trolley.position.set(0, 0, 75);
    group.add(trolley);

    return group;
  }

  private createVasiniWorkcenter(wc: LineData): THREE.Group {
    const group = new THREE.Group();
    const redMat = new THREE.MeshLambertMaterial({ color: 0xdc2626 });
    const whiteMat = new THREE.MeshLambertMaterial({ color: 0xf8fafc });
    const darkMat = new THREE.MeshLambertMaterial({ color: 0x334155 });
    const greyMat = new THREE.MeshLambertMaterial({ color: 0x94a3b8 });

    // Base Platform
    const baseMat = wc.downtimeReason ? this.sharedMaterials['baseWarning'] : this.sharedMaterials['base'];
    const base = new THREE.Mesh(this.sharedGeometries['base'], baseMat);
    base.position.y = 10;
    base.castShadow = true;
    base.receiveShadow = true;
    group.add(base);

    // Left Table (Frame)
    const leftTable = new THREE.Mesh(new THREE.BoxGeometry(50, 30, 40), redMat);
    leftTable.position.set(-45, 35, 0);
    leftTable.castShadow = true;
    group.add(leftTable);

    // Vibratory Bowls / Hoppers
    const hopperGeom = new THREE.CylinderGeometry(15, 5, 20, 8);
    const hopper1 = new THREE.Mesh(hopperGeom, greyMat);
    hopper1.position.set(-45, 60, -10);
    hopper1.rotation.x = -0.2;
    group.add(hopper1);

    const hopper2 = new THREE.Mesh(hopperGeom, greyMat);
    hopper2.position.set(-45, 60, 10);
    hopper2.rotation.x = 0.2;
    group.add(hopper2);

    // Connecting Conveyor
    const conv = new THREE.Mesh(new THREE.BoxGeometry(40, 5, 10), darkMat);
    conv.position.set(-10, 52, 0);
    group.add(conv);

    // Main Enclosure (Red Frame)
    const mainEnc = new THREE.Mesh(new THREE.BoxGeometry(50, 80, 50), redMat);
    mainEnc.position.set(35, 60, 0);
    mainEnc.castShadow = true;
    group.add(mainEnc);

    // Inner machine part
    const innerMach = new THREE.Mesh(new THREE.BoxGeometry(40, 60, 40), darkMat);
    innerMach.position.set(35, 55, 0);
    group.add(innerMach);

    // Output Chute
    const chute = new THREE.Mesh(new THREE.BoxGeometry(20, 5, 15), greyMat);
    chute.position.set(65, 40, 0);
    chute.rotation.z = -Math.PI / 4;
    group.add(chute);

    // Status Light Tower
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 20), darkMat);
    pole.position.set(15, 110, 20);
    group.add(pole);

    const bulbColor = wc.downtimeReason ? 0xff0000 : (wc.oee < 75 ? 0xffaa00 : 0x00ff00);
    const bulb = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 10), new THREE.MeshBasicMaterial({ color: bulbColor }));
    bulb.position.set(15, 125, 20);
    group.add(bulb);

    // Hopper Elevator (Vertical)
    const elevatorGroup = new THREE.Group();
    const rail = new THREE.Mesh(new THREE.BoxGeometry(5, 100, 5), greyMat);
    rail.position.set(-75, 70, 0);
    elevatorGroup.add(rail);

    const elevatorBin = new THREE.Mesh(new THREE.BoxGeometry(15, 15, 15), redMat);
    elevatorBin.position.set(-75, 30, 0);
    elevatorBin.userData = { isElevatorBin: true, phase: Math.random() * Math.PI * 2 };
    elevatorGroup.add(elevatorBin);

    group.add(elevatorGroup);

    // Static Trolley at output
    const outTrolley = this.createTrolley();
    outTrolley.position.set(75, 0, 0);
    group.add(outTrolley);

    // Add a worker nearby
    if (Math.random() > 0.3) {
      const worker = this.createWorker();
      worker.position.set(70, 0, 40);
      worker.rotation.y = -Math.PI / 4;
      worker.userData = {
        isWorker: true,
        animationOffset: Math.random() * Math.PI * 2,
        speed: 1 + Math.random(),
        baseZ: 40
      };
      group.add(worker);
    }

    group.userData = { id: wc.id };
    return group;
  }

  private createStandardWorkcenter(wc: LineData): THREE.Group {
    const group = new THREE.Group();
    const redMat = new THREE.MeshLambertMaterial({ color: 0xdc2626 });
    const whiteMat = new THREE.MeshLambertMaterial({ color: 0xf8fafc });
    const darkMat = new THREE.MeshLambertMaterial({ color: 0x334155 });

    // Base Platform
    const baseMat = wc.downtimeReason ? this.sharedMaterials['baseWarning'] : this.sharedMaterials['base'];
    const base = new THREE.Mesh(this.sharedGeometries['base'], baseMat);
    base.position.y = 10;
    base.castShadow = true;
    base.receiveShadow = true;
    group.add(base);

    // Main Machinery Body
    const bodyGeom = new THREE.BoxGeometry(60, 50, 40);
    const body = new THREE.Mesh(bodyGeom, whiteMat);
    body.position.y = 45;
    body.castShadow = true;
    group.add(body);

    // Top component
    const topGeom = new THREE.BoxGeometry(40, 20, 30);
    const top = new THREE.Mesh(topGeom, redMat);
    top.position.y = 80;
    top.castShadow = true;
    group.add(top);

    // Control Panel
    const panelGeom = new THREE.BoxGeometry(10, 20, 30);
    const panel = new THREE.Mesh(panelGeom, darkMat);
    panel.position.set(35, 45, 0);
    group.add(panel);

    // Status Light
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 20), darkMat);
    pole.position.set(15, 95, 10);
    group.add(pole);

    const bulbColor = wc.downtimeReason ? 0xff0000 : (wc.oee < 75 ? 0xffaa00 : 0x00ff00);
    const bulb = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 10), new THREE.MeshBasicMaterial({ color: bulbColor }));
    bulb.position.set(15, 110, 10);
    group.add(bulb);

    // Escalator Hopper
    const escalator = this.createEscalatorHopper(redMat, whiteMat, darkMat);
    escalator.position.set(-50, 0, 0);
    escalator.rotation.y = Math.PI / 2;
    group.add(escalator);

    // Add a worker nearby
    if (Math.random() > 0.3) {
      const worker = this.createWorker();
      worker.position.set(0, 0, 40);
      worker.userData = { isWorker: true, speed: 1.5 + Math.random(), animationOffset: Math.random() * Math.PI, baseZ: 40 };
      group.add(worker);
    }

    // Store data for raycasting
    group.userData = { id: wc.id };

    return group;
  }

  private createPressingMachine(wc: LineData): THREE.Group {
    const group = new THREE.Group();
    const redMat = new THREE.MeshLambertMaterial({ color: 0xdc2626 });
    const whiteMat = new THREE.MeshLambertMaterial({ color: 0xf8fafc });
    const darkMat = new THREE.MeshLambertMaterial({ color: 0x334155 });

    // Base Platform
    const baseMat = wc.downtimeReason ? this.sharedMaterials['baseWarning'] : this.sharedMaterials['base'];
    const base = new THREE.Mesh(this.sharedGeometries['base'], baseMat);
    base.position.y = 10;
    base.castShadow = true;
    base.receiveShadow = true;
    group.add(base);

    // Machine Base
    const machBase = new THREE.Mesh(new THREE.BoxGeometry(60, 20, 60), darkMat);
    machBase.position.y = 20;
    machBase.castShadow = true;
    group.add(machBase);

    // Pillars
    const pillarGeom = new THREE.CylinderGeometry(4, 4, 100);
    const positions = [[-20, -20], [20, -20], [-20, 20], [20, 20]];
    positions.forEach(pos => {
      const pillar = new THREE.Mesh(pillarGeom, whiteMat);
      pillar.position.set(pos[0], 70, pos[1]);
      pillar.castShadow = true;
      group.add(pillar);
    });

    // Top Press Head
    const top = new THREE.Mesh(new THREE.BoxGeometry(60, 30, 60), redMat);
    top.position.y = 120;
    top.castShadow = true;
    group.add(top);

    // Moving Press Part
    const press = new THREE.Mesh(new THREE.BoxGeometry(50, 20, 50), whiteMat);
    press.position.y = 90;
    press.castShadow = true;
    press.userData = { isPress: true, phase: Math.random() * Math.PI * 2 };
    group.add(press);

    // Control Panel
    const panel = new THREE.Mesh(new THREE.BoxGeometry(15, 30, 10), whiteMat);
    panel.position.set(35, 40, 0);
    group.add(panel);

    // Status Light
    const bulbColor = wc.downtimeReason ? 0xff0000 : (wc.oee < 75 ? 0xffaa00 : 0x00ff00);
    const bulb = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 10), new THREE.MeshBasicMaterial({ color: bulbColor }));
    bulb.position.set(0, 140, 0);
    group.add(bulb);

    // Add Escalator Hopper
    const escalator = this.createEscalatorHopper(redMat, whiteMat, darkMat);
    escalator.position.set(-50, 0, 0);
    escalator.rotation.y = Math.PI / 2;
    group.add(escalator);

    // Add a worker nearby
    if (Math.random() > 0.3) {
      const worker = this.createWorker();
      worker.position.set(0, 0, 45);
      worker.userData = { isWorker: true, speed: 1.5 + Math.random(), animationOffset: Math.random() * Math.PI, baseZ: 45 };
      group.add(worker);
    }

    group.userData = { id: wc.id };
    return group;
  }

  private animate() {
    this.animationId = requestAnimationFrame(() => this.animate());
    
    if (this.controls) {
      this.controls.update();
    }

    const delta = this.clock.getDelta();
    const time = Date.now() * 0.002;

    // Animate Conveyors
    this.conveyors.forEach(c => {
      if (c.userData['texture']) {
        c.userData['texture'].offset.x -= delta * 0.4;
      }
    });

    // Animate Products
    this.products.forEach(p => {
      p.position.x += delta * p.userData['speed'];
      const limit = p.userData['lineLength'] - 125;
      if (p.position.x > limit) {
        p.position.x = -125;
      }
      p.rotation.y += delta;
    });

    // Animate Gears
    this.gears.forEach(g => {
      g.rotation.x += delta * 2;
    });

    // Animate AGVs
    this.agvs.forEach(agv => {
      const data = agv.userData;
      if (data['axis'] === 'x') {
        agv.position.x += data['speed'] * data['direction'] * delta;
        if (Math.abs(agv.position.x) > data['bounds']) {
          data['direction'] *= -1;
        }
      } else {
        agv.position.z += data['speed'] * data['direction'] * delta;
        if (Math.abs(agv.position.z) > data['bounds']) {
          data['direction'] *= -1;
        }
      }
    });
    
    // Animate Trolleys
    this.trolleys.forEach(trolley => {
      const data = trolley.userData;
      if (data['axis'] === 'x') {
        trolley.position.x += data['speed'] * data['direction'] * delta;
        if (Math.abs(trolley.position.x) > data['bounds']) {
          data['direction'] *= -1;
          trolley.rotation.y += Math.PI;
        }
      } else {
        trolley.position.z += data['speed'] * data['direction'] * delta;
        if (Math.abs(trolley.position.z) > data['bounds']) {
          data['direction'] *= -1;
          trolley.rotation.y += Math.PI;
        }
      }
    });

    // Animate Workers and Elevator Bins
    this.workcenterMeshes.forEach(isoWc => {
      if (isoWc.mesh) {
        isoWc.mesh.children.forEach(child => {
          if (child.userData['isWorker']) {
            const data = child.userData;
            const head = child.children[1];
            const leftLeg = child.children[2];
            const rightLeg = child.children[3];
            
            if(head) {
               head.rotation.y = Math.sin(time * data['speed'] + data['animationOffset']) * 0.3;
            }
            if(leftLeg) {
               leftLeg.rotation.x = Math.sin(time * data['speed'] * 2 + data['animationOffset']) * 0.2;
            }
            if(rightLeg) {
               rightLeg.rotation.x = -Math.sin(time * data['speed'] * 2 + data['animationOffset']) * 0.2;
            }
            if (data['baseZ'] !== undefined) {
               child.position.z = data['baseZ'] + Math.sin(time * data['speed'] * 0.5 + data['animationOffset']) * 10;
            }
          }
          
          if (child.userData['isPress']) {
            const data = child.userData;
            child.position.y = 90 + Math.sin(time * 3 + data['phase']) * 15;
          }

          if (child instanceof THREE.Group) {
            child.children.forEach(subChild => {
              if (subChild.userData['isElevatorBin']) {
                const data = subChild.userData;
                subChild.position.y = 30 + Math.abs(Math.sin(time * 2 + data['phase'])) * 60;
              }
              if (subChild.userData['isEscalatorBelt']) {
                const texture = subChild.userData['texture'];
                if (texture) {
                  texture.offset.y -= delta * 0.5;
                }
              }
            });
          }
        });
      }
    });
    // Animate Robot Arms
    this.robotArms.forEach(robot => {
      const data = robot.userData;
      robot.rotation.y += data['baseRotationSpeed'] * delta;
      
      const lowerArm = robot.children[1];
      const upperArm = robot.children[3];
      
      if(lowerArm) {
        lowerArm.rotation.x = Math.sin(time * data['armRotationSpeed'] * 0.5) * 0.2;
      }
      if(upperArm) {
        upperArm.rotation.x = Math.PI / 4 + Math.sin(time * data['armRotationSpeed']) * 0.5;
      }
    });
    
    this.workcenterMeshes.forEach(wc => {
      if (wc.mesh) {
        // Find the bulb and animate it
        const bulb = wc.mesh.children.find(c => c instanceof THREE.Mesh && c.geometry instanceof THREE.SphereGeometry);
        if (bulb) {
          const mat = (bulb as THREE.Mesh).material as THREE.MeshBasicMaterial;
          if (wc.status === 'downtime') {
            mat.opacity = 0.5 + Math.sin(time * 8) * 0.5;
            mat.transparent = true;
          } else if (wc.status === 'warning') {
            mat.opacity = 0.7 + Math.sin(time * 3) * 0.3;
            mat.transparent = true;
          } else {
            mat.opacity = 1;
            mat.transparent = false;
          }
        }

        // Animate rings
        const ring = wc.mesh.children.find(c => c instanceof THREE.Mesh && c.geometry instanceof THREE.TorusGeometry);
        if (ring) {
          ring.scale.setScalar(1 + Math.sin(time * 2) * 0.05);
          (ring as THREE.Mesh).rotation.z += 0.01;
        }
      }
    });

    this.renderer.render(this.scene, this.camera);
  }

  onCanvasClick(event: MouseEvent | KeyboardEvent) {
    if (!this.rendererContainer) return;

    const rect = this.rendererContainer.nativeElement.getBoundingClientRect();
    
    let clientX, clientY;
    if (event instanceof MouseEvent) {
      clientX = event.clientX;
      clientY = event.clientY;
    } else {
      // For keyboard, just pick the center of the container
      clientX = rect.left + rect.width / 2;
      clientY = rect.top + rect.height / 2;
    }

    this.mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    if (intersects.length > 0) {
      let obj = intersects[0].object;
      while (obj.parent && !obj.userData['id']) {
        obj = obj.parent;
      }

      if (obj.userData['id']) {
        const wc = this.workcenterMeshes.find(w => w.id === obj.userData['id']);
        if (wc) {
          this.selectWorkcenter(wc);
          return;
        }
      }
    }
  }

  selectWorkcenter(wc: IsoWorkcenter) {
    this.selectedWc.set(wc);
    
    if (wc.mesh) {
      const targetPos = wc.mesh.getWorldPosition(new THREE.Vector3());
      // Smoothly move controls target
      const startPos = this.controls.target.clone();
      const duration = 500;
      const startTime = Date.now();

      const animateCamera = () => {
        const now = Date.now();
        const t = Math.min((now - startTime) / duration, 1);
        const easedT = t * (2 - t); // easeOutQuad
        
        this.controls.target.lerpVectors(startPos, targetPos, easedT);
        
        if (t < 1) requestAnimationFrame(animateCamera);
      };
      animateCamera();
    }
  }

  deselectWorkcenter() {
    this.selectedWc.set(null);
  }

  getStatusColor(wc: LineData): string {
    if (wc.downtimeReason) return '#ef4444';
    if (wc.oee < 75) return '#f59e0b';
    return '#10b981';
  }

  getOeeColor(oee: number): string {
    if (oee >= 85) return '#10b981';
    if (oee >= 75) return '#f59e0b';
    return '#ef4444';
  }
}
