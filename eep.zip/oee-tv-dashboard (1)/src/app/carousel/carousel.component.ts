import { Component, OnInit, OnDestroy, inject, signal, input, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { DataService } from '../data.service';

@Component({
  selector: 'app-carousel',
  standalone: true,
  imports: [CommonModule, DashboardComponent],
  template: `
    <div class="h-screen w-screen overflow-hidden bg-slate-50 dark:bg-slate-950 relative">
      @if (lines().length > 0) {
        <!-- Progress Bar for Carousel -->
        <div class="absolute top-0 left-0 right-0 h-1.5 bg-slate-200/50 dark:bg-slate-800/50 z-50">
          <div class="h-full bg-indigo-500 transition-all duration-75 ease-linear" [style.width.%]="progress()"></div>
        </div>
        
        <!-- Current Dashboard -->
        <div class="w-full h-full animate-fade-in">
          <app-dashboard [lineId]="lines()[currentIndex()]" [isEmbedded]="isEmbedded()" [disableAutoRotate]="true"></app-dashboard>
        </div>
        
        <!-- Overlay indicator -->
        <div class="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex gap-2 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-slate-200 dark:border-slate-700">
          @for (line of lines(); track line; let i = $index) {
            <div class="w-2.5 h-2.5 rounded-full transition-all duration-300"
                 [class.bg-indigo-500]="i === currentIndex()"
                 [class.scale-125]="i === currentIndex()"
                 [class.bg-slate-300]="i !== currentIndex()"
                 [class.dark:bg-slate-600]="i !== currentIndex()">
            </div>
          }
        </div>
      } @else {
        <div class="h-full w-full flex items-center justify-center text-slate-500 dark:text-slate-400">
          <p class="text-xl">Please provide workcenter or lines in the URL, e.g., ?workcenter=WC-1 or ?lines=1,2</p>
        </div>
      }
    </div>
  `,
  styles: [`
    .animate-fade-in {
      animation: fadeIn 0.5s ease-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.98); }
      to { opacity: 1; transform: scale(1); }
    }
  `]
})
export class CarouselComponent implements OnInit, OnDestroy {
  private route = inject(ActivatedRoute);
  private dataService = inject(DataService);
  
  workcenters = input<string[]>();
  isEmbedded = input<boolean>(false);
  
  lines = signal<string[]>([]);
  currentIndex = signal<number>(0);
  progress = signal<number>(0);
  
  private rotateInterval: ReturnType<typeof setInterval> | undefined;
  private startTime = 0;
  private readonly DURATION = 30000; // 30 seconds per line

  constructor() {
    effect(() => {
      const wcs = this.workcenters();
      if (wcs && wcs.length > 0) {
        const allLines = this.dataService.lines();
        const newLines = allLines.filter(l => wcs.includes(l.workcenterName)).map(l => l.id);
        
        // Only update and restart rotation if the actual line IDs changed
        const currentLines = this.lines();
        const linesChanged = newLines.length !== currentLines.length || !newLines.every((val, index) => val === currentLines[index]);
        
        if (linesChanged && newLines.length > 0) {
          this.lines.set(newLines);
          this.startRotation();
        }
      }
    });
  }

  ngOnInit() {
    this.route.queryParamMap.subscribe(params => {
      // Only process URL params if no input is provided
      if (!this.workcenters()) {
        const workcenterParam = params.get('workcenter');
        const linesParam = params.get('lines');
        
        let newLines: string[] = [];
        if (workcenterParam) {
          const wcs = workcenterParam.split(',').map(w => w.trim()).filter(w => w);
          const allLines = this.dataService.lines();
          newLines = allLines.filter(l => wcs.includes(l.workcenterName)).map(l => l.id);
        } else if (linesParam) {
          newLines = linesParam.split(',').map(l => l.trim()).filter(l => l);
        }
        
        if (newLines.length > 0) {
          this.lines.set(newLines);
          this.startRotation();
        }
      }
      
      if (params.has('theme')) {
        const isDark = params.get('theme') === 'dark';
        if (isDark) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    });
  }

  ngOnDestroy() {
    this.stopRotation();
  }

  private startRotation() {
    this.stopRotation();
    if (this.lines().length <= 1) return; // No need to rotate if only 1 line

    this.startTime = Date.now();
    this.rotateInterval = setInterval(() => {
      const elapsed = Date.now() - this.startTime;
      if (elapsed >= this.DURATION) {
        // Next slide
        this.currentIndex.update(i => (i + 1) % this.lines().length);
        this.startTime = Date.now();
        this.progress.set(0);
      } else {
        this.progress.set((elapsed / this.DURATION) * 100);
      }
    }, 50);
  }

  private stopRotation() {
    if (this.rotateInterval) {
      clearInterval(this.rotateInterval);
      this.rotateInterval = undefined;
    }
  }
}
