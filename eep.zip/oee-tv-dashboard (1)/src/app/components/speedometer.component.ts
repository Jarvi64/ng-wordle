import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-speedometer',
  standalone: true,
  imports: [DecimalPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative flex flex-col items-center justify-center w-full h-full">
      <svg viewBox="0 0 200 120" class="w-full max-w-[420px] drop-shadow-sm overflow-visible">
        <defs>
          <!-- Brass Gradient for Casing -->
          <linearGradient id="brass" x1="93" y1="0" x2="107" y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#8a6727" />
            <stop offset="20%" stop-color="#eadd97" />
            <stop offset="40%" stop-color="#cdae56" />
            <stop offset="80%" stop-color="#8a6727" />
            <stop offset="100%" stop-color="#5c4313" />
          </linearGradient>
          <!-- Copper Gradient for Bullet -->
          <linearGradient id="copper" x1="97" y1="0" x2="103" y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#6b331c" />
            <stop offset="30%" stop-color="#d98c6a" />
            <stop offset="60%" stop-color="#b85d38" />
            <stop offset="100%" stop-color="#4a2010" />
          </linearGradient>
          <!-- Drop Shadow for Needle -->
          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="4" stdDeviation="4" flood-opacity="0.3" />
          </filter>
        </defs>

        <!-- Background track -->
        <path 
          d="M 20 100 A 80 80 0 0 1 180 100" 
          fill="none" 
          stroke="currentColor" 
          stroke-width="16" 
          stroke-linecap="round" 
          class="text-slate-100 dark:text-slate-800" 
          pathLength="100" 
        />
        <!-- Value track -->
        <path 
          d="M 20 100 A 80 80 0 0 1 180 100" 
          fill="none" 
          stroke="currentColor" 
          stroke-width="16" 
          stroke-linecap="round"
          [class]="colorClass()"
          pathLength="100"
          stroke-dasharray="100"
          [attr.stroke-dashoffset]="100 - percentage()"
          class="transition-all duration-1000 ease-out" 
        />
        
        <!-- Ticks/Labels -->
        <text x="20" y="120" class="text-[12px] font-bold fill-slate-400 dark:fill-slate-500" text-anchor="middle">0</text>
        <text x="180" y="120" class="text-[12px] font-bold fill-slate-400 dark:fill-slate-500" text-anchor="middle">{{ max() }}</text>

        <!-- 5.56mm Cartridge Needle -->
        <g [style.transform]="'rotate(' + needleAngle() + 'deg)'" style="transform-origin: 100px 100px; transition: transform 1s cubic-bezier(0.34, 1.56, 0.64, 1);">
          <g filter="url(#shadow)">
            <!-- Rim -->
            <rect x="93" y="96" width="14" height="4" fill="url(#brass)" rx="1" />
            <!-- Extractor Groove -->
            <rect x="95" y="92" width="10" height="4" fill="url(#brass)" />
            <rect x="95" y="92" width="10" height="4" fill="#000" opacity="0.3" /> <!-- Darken groove -->
            <!-- Body -->
            <rect x="94" y="55" width="12" height="37" fill="url(#brass)" />
            <!-- Shoulder -->
            <polygon points="94,55 106,55 103,45 97,45" fill="url(#brass)" />
            <!-- Neck -->
            <rect x="97" y="35" width="6" height="10" fill="url(#brass)" />
            <!-- Bullet -->
            <path d="M 97 35 L 103 35 Q 103 15 100 0 Q 97 15 97 35 Z" fill="url(#copper)" />
          </g>
          <!-- Pivot Pin -->
          <circle cx="100" cy="100" r="5" fill="#1e293b" class="dark:fill-slate-800" />
          <circle cx="100" cy="100" r="2" fill="#64748b" class="dark:fill-slate-600" />
        </g>
      </svg>
      
      <div class="absolute bottom-0 flex flex-col items-center">
        <span class="text-6xl font-mono font-bold tracking-tight text-slate-800 dark:text-white leading-none">
          {{ value() | number:'1.0-1' }}
        </span>
        <span class="text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider text-sm mt-2">
          Parts / Min
        </span>
      </div>
    </div>
  `
})
export class SpeedometerComponent {
  value = input.required<number>();
  max = input.required<number>();

  percentage = computed(() => {
    if (this.max() === 0) return 0;
    const p = (this.value() / this.max()) * 100;
    return Math.min(100, Math.max(0, p));
  });

  needleAngle = computed(() => {
    return (this.percentage() / 100) * 180 - 90;
  });

  colorClass = computed(() => {
    const p = this.percentage();
    if (p >= 85) return 'text-emerald-500';
    if (p >= 70) return 'text-amber-500';
    return 'text-rose-500';
  });
}
