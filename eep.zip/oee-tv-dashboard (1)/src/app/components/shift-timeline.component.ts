import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-shift-timeline',
  standalone: true,
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div [class]="containerClass()" class="rounded-3xl p-6 flex flex-col gap-5 shadow-sm border-2 transition-colors duration-500 relative overflow-hidden">
      <!-- Top Row: Status & Numbers -->
      <div class="flex items-center justify-between z-10">
        <!-- Status -->
        <div class="flex items-center gap-6">
          <div [class]="iconBgClass()" class="w-16 h-16 rounded-full flex items-center justify-center shrink-0 shadow-inner">
            <mat-icon class="scale-150">{{ iconName() }}</mat-icon>
          </div>
          <div>
            <h3 [class]="statusTextClass()" class="font-bold text-3xl tracking-tight">{{ statusText() }}</h3>
            <p [class]="subStatusTextClass()" class="font-semibold text-lg mt-0.5">
              {{ subStatusText() }}
            </p>
          </div>
        </div>

        <!-- Time Metrics -->
        <div class="flex items-center gap-8 text-right bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm py-3 px-6 rounded-2xl border border-white/50 dark:border-slate-700/50 shadow-sm transition-colors duration-500">
          <div class="flex flex-col items-end">
            <div class="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 mb-1">
              <div class="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]"></div>
              <span class="text-xs font-bold uppercase tracking-wider">Run Time</span>
            </div>
            <span class="text-2xl font-mono font-bold text-slate-800 dark:text-white">{{ formatTime(runTime()) }}</span>
          </div>
          <div class="w-px h-10 bg-slate-300/50 dark:bg-slate-700/50"></div>
          <div class="flex flex-col items-end">
            <div class="flex items-center gap-1.5 text-rose-600 dark:text-rose-400 mb-1">
              <div class="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]"></div>
              <span class="text-xs font-bold uppercase tracking-wider">Downtime</span>
            </div>
            <span class="text-2xl font-mono font-bold text-slate-800 dark:text-white">{{ formatTime(downtime()) }}</span>
          </div>
          <div class="w-px h-10 bg-slate-300/50 dark:bg-slate-700/50"></div>
          <div class="flex flex-col items-end">
            <div class="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 mb-1">
              <div class="w-2.5 h-2.5 rounded-full bg-slate-400 dark:bg-slate-500"></div>
              <span class="text-xs font-bold uppercase tracking-wider">Remaining</span>
            </div>
            <span class="text-2xl font-mono font-bold text-slate-800 dark:text-white">{{ formatTime(remainingTime()) }}</span>
          </div>
        </div>
      </div>

      <!-- Bottom Row: Timeline Bar -->
      <div class="h-6 w-full bg-white/60 dark:bg-slate-900/60 rounded-full overflow-hidden flex shadow-inner border border-slate-200/50 dark:border-slate-700/50 z-10 relative backdrop-blur-sm transition-colors duration-500">
        <!-- Run Time -->
        <div class="h-full bg-emerald-500 transition-all duration-1000 relative flex items-center justify-end" 
             [class.animate-pulse]="!isDown() && runPercent() > 0"
             [style.width.%]="runPercent()">
          <div class="absolute inset-0 bg-white/20 w-full h-1/2"></div>
        </div>
        <!-- Downtime -->
        <div class="h-full bg-rose-500 transition-all duration-1000 relative flex items-center justify-end" 
             [class.animate-pulse]="isDown() && downPercent() > 0"
             [style.width.%]="downPercent()">
          <div class="absolute inset-0 bg-white/20 w-full h-1/2"></div>
          <div class="absolute inset-0 opacity-20" style="background-image: repeating-linear-gradient(45deg, transparent, transparent 10px, #000 10px, #000 20px);"></div>
        </div>
      </div>
      
      <!-- Decorative background element -->
      <mat-icon class="absolute -bottom-16 -right-8 text-[280px] opacity-[0.04] dark:opacity-[0.02] z-0 rotate-[-15deg] pointer-events-none text-slate-900 dark:text-white">
        {{ iconName() }}
      </mat-icon>
    </div>
  `
})
export class ShiftTimelineComponent {
  runTime = input.required<number>();
  downtime = input.required<number>();
  isDown = input.required<boolean>();
  downtimeReason = input<string | null>(null);
  totalTime = input<number>(480);

  hasData = computed(() => this.runTime() > 0 || this.downtime() > 0);

  safeTotal = computed(() => {
    const total = this.totalTime();
    if (!total) return 480;
    return Math.max(total, this.runTime() + this.downtime());
  });
  
  runPercent = computed(() => {
    if (this.safeTotal() === 0) return 0;
    return (this.runTime() / this.safeTotal()) * 100;
  });
  
  downPercent = computed(() => {
    if (this.safeTotal() === 0) return 0;
    return (this.downtime() / this.safeTotal()) * 100;
  });
  
  remainingTime = computed(() => Math.max(0, this.totalTime() - this.runTime() - this.downtime()));

  containerClass = computed(() => {
    if (!this.hasData()) return 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800';
    return this.isDown() ? 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/50' : 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/50';
  });

  iconBgClass = computed(() => {
    if (!this.hasData()) return 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 border border-slate-200 dark:border-slate-700';
    return this.isDown() ? 'bg-rose-100 dark:bg-rose-900/50 text-rose-600 dark:text-rose-400 border border-rose-200/50 dark:border-rose-800/50' : 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50';
  });

  statusTextClass = computed(() => {
    if (!this.hasData()) return 'text-slate-600 dark:text-slate-400';
    return this.isDown() ? 'text-rose-800 dark:text-rose-400' : 'text-emerald-800 dark:text-emerald-400';
  });

  subStatusTextClass = computed(() => {
    if (!this.hasData()) return 'text-slate-500 dark:text-slate-500';
    return this.isDown() ? 'text-rose-600 dark:text-rose-500' : 'text-emerald-600 dark:text-emerald-500';
  });

  statusText = computed(() => {
    if (!this.hasData()) return 'No Production Data';
    return this.isDown() ? 'Line Down' : 'Line Running';
  });

  subStatusText = computed(() => {
    if (!this.hasData()) return 'Awaiting line activity...';
    return this.isDown() && this.downtimeReason() ? `Reason: ${this.downtimeReason()}` : (this.isDown() ? 'Unknown Issue' : 'Operating at optimal capacity');
  });

  iconName = computed(() => {
    if (!this.hasData()) return 'pending';
    return this.isDown() ? 'warning' : 'check_circle';
  });

  formatTime(minutes: number | null | undefined): string {
    if (minutes == null || isNaN(minutes)) return '--';
    if (minutes === 0) return '0 min';
    
    const h = Math.floor(minutes / 60);
    const m = Math.floor(minutes % 60);
    
    if (h > 0) {
      return `${h} hr ${m} min`;
    }
    return `${m} min`;
  }
}
