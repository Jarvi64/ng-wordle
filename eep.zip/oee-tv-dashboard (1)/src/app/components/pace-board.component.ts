import { Component, input, computed, ChangeDetectionStrategy, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-pace-board',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full flex gap-6">
      <!-- Time Section (Left Column) -->
      <div class="w-1/4 bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col justify-between transition-colors duration-500">
        <div>
          <h2 class="text-2xl font-bold text-slate-700 dark:text-slate-200 tracking-tight uppercase">Shift Time</h2>
          
          <div class="text-6xl 2xl:text-7xl font-mono font-bold text-indigo-600 dark:text-indigo-400 mt-6 tabular-nums tracking-tighter">
            {{ time() | date:'HH:mm' }}<span class="text-3xl 2xl:text-4xl text-indigo-400 dark:text-indigo-600 ml-1">{{ time() | date:'ss' }}</span>
          </div>
          
          <div class="text-3xl font-bold text-slate-800 dark:text-white mt-10">Shift {{ shiftName() }}</div>
          
          <div class="mt-12 space-y-8">
            <div class="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800">
              <div class="text-lg font-semibold text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Elapsed
              </div>
              <div class="text-5xl 2xl:text-6xl font-mono font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{{ formatElapsed() }}</div>
            </div>
            
            <div class="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800">
              <div class="text-lg font-semibold text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Remaining
              </div>
              <div class="text-5xl 2xl:text-6xl font-mono font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{{ formatRemaining() }}</div>
            </div>
          </div>
        </div>
        
        <div class="mt-12">
          <div class="flex justify-between items-end mb-4">
            <div class="text-2xl font-bold text-slate-700 dark:text-slate-300">Shift Progress</div>
            <div class="text-2xl font-black text-indigo-500">{{ shiftProgress() | number:'1.0-0' }}%</div>
          </div>
          <div class="h-6 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200 dark:border-slate-700">
            <div class="h-full bg-indigo-500 rounded-full transition-all duration-1000" [style.width.%]="shiftProgress()"></div>
          </div>
        </div>
      </div>

      <!-- Right Section (Pace & Quality) -->
      <div class="w-3/4 flex flex-col gap-6">
        <!-- Pace Master Block -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl p-10 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col flex-1 relative overflow-hidden transition-colors duration-500">
          <!-- Big watermark status -->
          <div class="absolute -bottom-16 -right-10 text-[16rem] font-black opacity-[0.02] dark:opacity-[0.04] leading-none pointer-events-none uppercase whitespace-nowrap">
            {{ isAhead() ? 'AHEAD' : 'BEHIND' }}
          </div>

          <div class="flex justify-between items-start mb-8 z-10 w-full relative">
            <h2 class="text-3xl font-bold text-slate-700 dark:text-slate-200 tracking-tight uppercase">Production Pace</h2>
            
            <div class="absolute right-0 top-0 flex items-center gap-4 px-8 py-4 rounded-3xl border-2 shadow-sm" [class.bg-emerald-50]="isAhead()" [class.border-emerald-100]="isAhead()" [class.dark:bg-emerald-900/40]="isAhead()" [class.dark:border-emerald-800/50]="isAhead()" [class.bg-rose-50]="!isAhead()" [class.border-rose-100]="!isAhead()" [class.dark:bg-rose-900/40]="!isAhead()" [class.dark:border-rose-800/50]="!isAhead()">
              <div class="text-4xl 2xl:text-5xl font-black tabular-nums tracking-tighter" [class.text-emerald-700]="isAhead()" [class.dark:text-emerald-400]="isAhead()" [class.text-rose-700]="!isAhead()" [class.dark:text-rose-400]="!isAhead()">
                 {{ isAhead() ? '+' : '' }}{{ (actual() - idealProduction()) | number }}
                 <span class="text-xl 2xl:text-2xl font-bold uppercase tracking-widest opacity-80 ml-2">Delta</span>
              </div>
              <div class="w-12 h-12 2xl:w-14 2xl:h-14 rounded-full flex items-center justify-center shrink-0 ml-4" [class.bg-emerald-200]="isAhead()" [class.dark:bg-emerald-800]="isAhead()" [class.bg-rose-200]="!isAhead()" [class.dark:bg-rose-800]="!isAhead()">
                <svg class="w-8 h-8 2xl:w-10 2xl:h-10" [class.text-emerald-700]="isAhead()" [class.dark:text-emerald-300]="isAhead()" [class.text-rose-700]="!isAhead()" [class.dark:text-rose-300]="!isAhead()" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  @if (isAhead()) {
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  } @else {
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  }
                </svg>
              </div>
            </div>
          </div>

          <!-- The Big Numbers -->
          <div class="flex flex-wrap gap-16 2xl:gap-32 mb-16 mt-8 z-10">
            <div>
              <div class="text-xl font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Ideal Right Now</div>
              <div class="text-6xl 2xl:text-8xl font-mono font-black text-slate-500 dark:text-slate-400 tabular-nums">{{ idealProduction() | number }}</div>
            </div>
            <div>
              <div class="text-xl font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Actual (OK Parts)</div>
              <div class="text-6xl 2xl:text-8xl font-mono font-black text-slate-800 dark:text-white tabular-nums tracking-tighter" [class.text-emerald-600]="isAhead()" [class.dark:text-emerald-400]="isAhead()" [class.text-rose-600]="!isAhead()" [class.dark:text-rose-400]="!isAhead()">{{ actual() | number }}</div>
            </div>
          </div>

          <!-- Massive Progress Bar -->
          <div class="flex-1 flex flex-col justify-end z-10 mb-4">
             <div class="flex justify-between items-end mb-4 pr-2">
                <div class="text-2xl font-bold font-mono text-slate-600 dark:text-slate-300">0</div>
                <div class="text-right">
                  <div class="text-lg font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-widest mb-1">Shift Target</div>
                  <div class="text-4xl 2xl:text-5xl font-mono font-black text-indigo-500 dark:text-indigo-400 tabular-nums">{{ target() | number }}</div>
                </div>
             </div>
            <div class="relative h-20 2xl:h-24 bg-slate-100 dark:bg-slate-800 rounded-3xl border-2 border-slate-200 dark:border-slate-700 overflow-visible shadow-inner flex items-center px-2">

              <!-- Actual Bar -->
              <div class="absolute left-0 top-1/2 -translate-y-1/2 h-[calc(100%-16px)] rounded-2xl mx-2 transition-all duration-1000 ease-out flex items-center justify-end pr-6 text-white font-black text-2xl 2xl:text-3xl shadow-lg border-2 border-transparent"
                  [class.bg-emerald-500]="isAhead()" 
                  [class.border-emerald-400]="isAhead()"
                  [class.shadow-emerald-500/30]="isAhead()"
                  [class.bg-rose-500]="!isAhead()"
                  [class.border-rose-400]="!isAhead()"
                  [class.shadow-rose-500/30]="!isAhead()"
                  [style.width]="'calc(' + currentBarWidth() + '% - 16px)'"
                  [style.min-width.px]="60">
                  
                  <div class="absolute inset-0 opacity-20 rounded-xl overflow-hidden" style="background-image: linear-gradient(45deg, rgba(255,255,255,0.2) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0.2) 75%, transparent 75%, transparent); background-size: 2.5rem 2.5rem;"></div>
                  <span class="relative z-10 drop-shadow-md">{{ currentPercentage() | number:'1.0-0' }}%</span>
                  
                  <!-- Actual Label Marker (Bottom) -->
                  <div class="absolute -bottom-14 right-0 translate-x-1/2 bg-slate-700 dark:bg-slate-300 text-white dark:text-slate-900 text-lg 2xl:text-xl font-bold py-1.5 px-4 rounded-xl whitespace-nowrap shadow-xl flex flex-col items-center">
                    ACTUAL
                  </div>
                  <!-- Triangle pointer pointing up -->
                  <div class="absolute -bottom-4 right-0 translate-x-1/2 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[12px] border-b-slate-700 dark:border-b-slate-300"></div>
              </div>

              <!-- Ideal Marker / Tick -->
              <div class="absolute top-0 bottom-0 w-1.5 bg-slate-900 dark:bg-white z-20 shadow-[0_0_15px_rgba(0,0,0,0.5)] transition-all duration-1000" [style.left.%]="idealPercentage()">
                  <div class="absolute -top-12 left-1/2 -translate-x-1/2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-lg 2xl:text-xl font-bold py-1.5 px-4 rounded-xl whitespace-nowrap shadow-xl flex flex-col items-center">
                    IDEAL
                  </div>
                  <!-- Triangle pointer -->
                  <div class="absolute -top-3 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[12px] border-t-slate-900 dark:border-t-white"></div>
              </div>

            </div>
          </div>
        </div>

        <!-- Bottom Quality Row -->
        <div class="h-44 bg-white dark:bg-slate-900 rounded-3xl p-8 px-10 shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 transition-colors duration-500">
          <div class="flex items-center gap-8">
            <div class="w-24 h-24 2xl:w-28 2xl:h-28 rounded-3xl bg-rose-100 dark:bg-rose-900/30 flex items-center justify-center text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
              <svg class="w-12 h-12 2xl:w-14 2xl:h-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div>
              <div class="text-2xl font-bold text-slate-500 dark:text-slate-400 tracking-widest uppercase mb-1">Defect Parts (NOK)</div>
              <div class="text-6xl 2xl:text-7xl font-mono font-black text-rose-600 dark:text-rose-400 mt-2 tabular-nums tracking-tighter">{{ nokQty() | number }} <span class="text-3xl font-bold opacity-70 ml-2 tracking-normal">pcs</span></div>
            </div>
          </div>
          
          <div class="w-px h-full bg-slate-200 dark:bg-slate-800"></div>

          <div class="text-right flex flex-col justify-center">
            <div class="text-2xl font-bold text-slate-500 dark:text-slate-400 tracking-widest uppercase mb-1">Defect Rate</div>
            <div class="text-6xl 2xl:text-8xl font-mono font-black text-slate-800 dark:text-white tabular-nums tracking-tighter mt-1">{{ defectRate() | number:'1.1-1' }}<span class="text-4xl text-slate-400 ml-2 font-bold tracking-normal">%</span></div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PaceBoardComponent implements OnDestroy {
  target = input.required<number>();
  actual = input.required<number>();
  nokQty = input.required<number>();
  ppm = input.required<number>();
  runTime = input.required<number>();
  
  time = signal<Date>(new Date());
  private timer: ReturnType<typeof setInterval>;

  constructor() {
    this.timer = setInterval(() => {
      this.time.set(new Date());
    }, 1000);
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }

  defectRate = computed(() => {
    const total = this.actual() + this.nokQty();
    if (total === 0) return 0;
    return (this.nokQty() / total) * 100;
  });

  shiftInfo = computed(() => {
    const now = this.time();
    const hours = now.getHours();
    const mins = now.getMinutes();
    const secs = now.getSeconds();
    
    let shiftStartHour = 6;
    let shiftName = 'A';
    if (hours >= 14 && hours < 22) {
      shiftStartHour = 14;
      shiftName = 'B';
    } else if (hours >= 22 || hours < 6) {
      shiftStartHour = 22;
      shiftName = 'C';
    }
    
    let elapsedMins = 0;
    if (shiftStartHour === 22 && hours < 6) {
      elapsedMins = ((hours + 24) - 22) * 60 + mins + secs/60;
    } else {
      elapsedMins = (hours - shiftStartHour) * 60 + mins + secs/60;
    }
    
    const progress = Math.min(100, Math.max(0, (elapsedMins / 480) * 100)); // 480 mins = 8 hours
    
    return { shiftName, progress, elapsedMins, shiftStartHour };
  });

  shiftName = computed(() => this.shiftInfo().shiftName);
  shiftProgress = computed(() => this.shiftInfo().progress);
  
  formatElapsed = computed(() => {
    const totalMins = Math.floor(this.shiftInfo().elapsedMins);
    const hrs = Math.floor(totalMins / 60);
    const mins = totalMins % 60;
    return `${hrs.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m`;
  });

  formatRemaining = computed(() => {
    const elapsedMins = Math.floor(this.shiftInfo().elapsedMins);
    const totalShiftMins = 480;
    const remainingMins = Math.max(0, totalShiftMins - elapsedMins);
    const hrs = Math.floor(remainingMins / 60);
    const mins = remainingMins % 60;
    return `${hrs.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m`;
  });

  idealProduction = computed(() => {
    return Math.round(this.ppm() * this.runTime());
  });

  isAhead = computed(() => {
    return this.actual() >= this.idealProduction();
  });

  idealPercentage = computed(() => {
    // Cap at 100 for display tracking so the line doesn't go off the bar
    return Math.min(100, (this.idealProduction() / this.target()) * 100);
  });
  
  currentPercentage = computed(() => {
    if (this.target() === 0) return 0;
    return (this.actual() / this.target()) * 100;
  });

  currentBarWidth = computed(() => {
    // Cap bar visual at 100%
    return Math.min(100, this.currentPercentage());
  });
}
