import { Injectable, signal } from '@angular/core';
import { LineData, LineHistory } from './models';

export type LineDisplayMode = 'single' | 'combined' | 'carousel';

export interface LineTvConfig {
  lineName: string;
  mode: LineDisplayMode;
}

@Injectable({ providedIn: 'root' })
export class DataService {
  private mockData: LineData[] = this.generateAllLines();

  public readonly lineTvConfigs: LineTvConfig[] = [
    { lineName: 'Cup Line', mode: 'combined' },
    { lineName: 'Case Line', mode: 'carousel' },
    { lineName: 'Priming Line', mode: 'single' },
    { lineName: 'Sealing Line', mode: 'combined' },
    { lineName: 'Bullet Line', mode: 'carousel' },
    { lineName: 'Loading Line', mode: 'combined' }
  ];

  lines = signal<LineData[]>(this.mockData);

  constructor() {
    setInterval(() => {
      this.lines.update(lines => lines.map(line => this.updateMockLine(line)));
    }, 5000);
  }

  getLine(id: string): LineData | undefined {
    return this.lines().find(l => l.id === id);
  }

  getLineByWorkcenter(wc: string): LineData | undefined {
    return this.lines().find(l => l.workcenterName === wc);
  }

  getWorkcentersByLine(lineName: string): LineData[] {
    return this.lines().filter(l => l.lineName === lineName);
  }

  getCombinedData(lineName: string): LineData | undefined {
    const linesToCombine = this.getWorkcentersByLine(lineName);
    if (linesToCombine.length === 0) return undefined;
    if (linesToCombine.length === 1) return linesToCombine[0];

    let totalOk = 0;
    let totalNok = 0;
    let totalTarget = 0;
    let totalRunTime = 0;
    let totalDowntime = 0;
    let combinedPpm = 0;
    const activeDowntimeReasons: string[] = [];

    linesToCombine.forEach(l => {
      totalOk += l.okQty;
      totalNok += l.nokQty;
      totalTarget += l.target;
      totalRunTime += l.runTime;
      totalDowntime += l.downtimeMin;
      combinedPpm += l.ppm;
      if (l.downtimeReason) {
        activeDowntimeReasons.push(`${l.workcenterName}: ${l.downtimeReason}`);
      }
    });

    const totalProduced = totalOk + totalNok;
    const availabilityRate = totalRunTime + totalDowntime > 0 ? (totalRunTime / (totalRunTime + totalDowntime)) * 100 : 0;
      
    let totalExpected = 0;
    linesToCombine.forEach(l => {
      totalExpected += l.runTime * l.ppm;
    });
    const performanceRate = totalExpected > 0 ? (totalProduced / totalExpected) * 100 : 0;
    const qualityRate = totalProduced > 0 ? (totalOk / totalProduced) * 100 : 0;
    const oee = (availabilityRate * performanceRate * qualityRate) / 10000;

    const combinedHistory: LineHistory[] = [];
    const historyLength = linesToCombine[0].history.length;
    
    for (let i = 0; i < historyLength; i++) {
      let hOk = 0, hNok = 0, hDown = 0, hExpected = 0, hRun = 0;
      
      linesToCombine.forEach(l => {
        const h = l.history[i];
        if (h) {
          hOk += h.okQty;
          hNok += h.nokQty;
          hDown += h.downtime;
          const intervalRun = Math.max(0, 15 - h.downtime);
          hRun += intervalRun;
          hExpected += intervalRun * l.ppm;
        }
      });

      const hTotal = hOk + hNok;
      const hAvail = hRun + hDown > 0 ? (hRun / (hRun + hDown)) * 100 : 0;
      const hPerf = hExpected > 0 ? (hTotal / hExpected) * 100 : 0;
      const hQual = hTotal > 0 ? (hOk / hTotal) * 100 : 0;
      
      combinedHistory.push({
        time: linesToCombine[0].history[i].time,
        okQty: hOk,
        nokQty: hNok,
        downtime: hDown,
        availability: hAvail,
        performance: hPerf,
        quality: hQual,
        oee: (hAvail * hPerf * hQual) / 10000
      });
    }

    return {
      id: `combined-${lineName}`,
      workcenterName: linesToCombine.map(l => l.workcenterName).join(', '),
      lineName: lineName,
      stage: 0,
      stageName: 'Combined',
      ppm: combinedPpm,
      target: totalTarget,
      okQty: totalOk,
      nokQty: totalNok,
      materialDesc: 'Multiple Products',
      runTime: totalRunTime / linesToCombine.length,
      downtimeMin: totalDowntime / linesToCombine.length,
      downtimeReason: activeDowntimeReasons.length > 0 ? activeDowntimeReasons.join(' | ') : null,
      oee,
      qualityRate,
      performanceRate,
      availabilityRate,
      history: combinedHistory
    };
  }

  private generateAllLines(): LineData[] {
    const allWorkcenters: LineData[] = [];
    let idCounter = 1;

    const createWc = (lineName: string, stage: number, stageName: string, workcenterName: string, materialDesc: string, basePpm: number) => {
      const wc = this.generateMockWorkcenter(idCounter.toString(), lineName, stage, stageName, workcenterName, materialDesc, basePpm);
      allWorkcenters.push(wc);
      idCounter++;
    };

    // Cup Line
    createWc('Cup Line', 1, 'Blanking', 'Blanking Press', 'Brass Strip', 800);
    createWc('Cup Line', 2, 'Cupping', 'Cupping Press A', 'Brass Cups', 400);
    createWc('Cup Line', 2, 'Cupping', 'Cupping Press B', 'Brass Cups', 400);
    createWc('Cup Line', 3, 'Wash', 'Wash & Dry', 'Clean Cups', 800);

    // Case Line
    createWc('Case Line', 1, 'Draw 1', 'Draw Press 1', 'Draw 1 Case', 600);
    createWc('Case Line', 2, 'Draw 2', 'Draw Press 2', 'Draw 2 Case', 600);
    createWc('Case Line', 3, 'Draw 3', 'Draw Press 3', 'Draw 3 Case', 600);
    createWc('Case Line', 4, 'Trim', 'Trim Machine A', 'Trimmed Case', 300);
    createWc('Case Line', 4, 'Trim', 'Trim Machine B', 'Trimmed Case', 300);
    createWc('Case Line', 5, 'Head Turn', 'Head Turn Lathe', 'Finished Case', 600);

    // Priming Line
    createWc('Priming Line', 1, 'Insert', 'Primer Insert A', 'Primed Case', 300);
    createWc('Priming Line', 1, 'Insert', 'Primer Insert B', 'Primed Case', 300);
    createWc('Priming Line', 2, 'Crimp', 'Primer Crimp', 'Crimped Case', 600);

    // Sealing Line
    createWc('Sealing Line', 1, 'Apply', 'Sealant Apply', 'Sealed Case', 600);
    createWc('Sealing Line', 2, 'Cure', 'UV Cure A', 'Cured Case', 300);
    createWc('Sealing Line', 2, 'Cure', 'UV Cure B', 'Cured Case', 300);

    // Bullet Line
    createWc('Bullet Line', 1, 'Extrude', 'Lead Extrude', 'Lead Wire', 800);
    createWc('Bullet Line', 2, 'Swage', 'Swage Press A', 'Lead Core', 400);
    createWc('Bullet Line', 2, 'Swage', 'Swage Press B', 'Lead Core', 400);
    createWc('Bullet Line', 3, 'Jacket', 'Jacket Press', 'Jacketed Bullet', 800);
    createWc('Bullet Line', 4, 'Size', 'Sizing Press', 'Finished Bullet', 800);

    // Loading Line
    createWc('Loading Line', 1, 'Powder', 'Powder Drop A', 'Charged Case', 300);
    createWc('Loading Line', 1, 'Powder', 'Powder Drop B', 'Charged Case', 300);
    createWc('Loading Line', 2, 'Seat', 'Bullet Seat A', 'Seated Round', 300);
    createWc('Loading Line', 2, 'Seat', 'Bullet Seat B', 'Seated Round', 300);
    createWc('Loading Line', 3, 'Crimp', 'Final Crimp', 'Finished Round', 600);
    createWc('Loading Line', 4, 'Pack', 'Packager A', 'Boxed Ammo', 300);
    createWc('Loading Line', 4, 'Pack', 'Packager B', 'Boxed Ammo', 300);

    return allWorkcenters;
  }

  private generateMockWorkcenter(id: string, lineName: string, stage: number, stageName: string, workcenterName: string, materialDesc: string, ppm: number): LineData {
    const isDown = Math.random() > 0.9;
    const target = ppm * 480;
    const runTime = 300 + Math.floor(Math.random() * 100);
    const downtimeMin = isDown ? 15 + Math.floor(Math.random() * 45) : Math.floor(Math.random() * 10);
    
    const performanceRate = 80 + Math.random() * 15;
    const qualityRate = 95 + Math.random() * 4.9;
    const availabilityRate = (runTime / (runTime + downtimeMin)) * 100;
    const oee = (availabilityRate * performanceRate * qualityRate) / 10000;

    const totalProduced = Math.floor(runTime * ppm * (performanceRate / 100));
    const okQty = Math.floor(totalProduced * (qualityRate / 100));
    const nokQty = totalProduced - okQty;
    
    const history: LineHistory[] = [];
    let currentOk = 0;
    let currentNok = 0;
    let currentDown = 0;
    for (let i = 0; i < 32; i++) {
      const intervalOk = Math.floor(Math.random() * (ppm * 15 * 0.9));
      const intervalNok = Math.floor(Math.random() * 5);
      const intervalDown = Math.random() > 0.9 ? Math.floor(Math.random() * 10) : 0;
      
      currentOk += intervalOk;
      currentNok += intervalNok;
      currentDown += intervalDown;
      
      const avail = Math.max(0, 100 - (currentDown / ((i + 1) * 15)) * 100);
      const perf = Math.min(100, 80 + Math.random() * 20);
      const qual = (currentOk / (currentOk + currentNok)) * 100;
      
      const hour = Math.floor(i / 4) + 6;
      const min = (i % 4) * 15;
      
      history.push({
        time: `${hour.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`,
        oee: (avail * perf * qual) / 10000,
        availability: avail,
        performance: perf,
        quality: qual,
        okQty: intervalOk,
        nokQty: intervalNok,
        downtime: intervalDown
      });
    }

    return {
      id,
      workcenterName,
      lineName,
      stage,
      stageName,
      ppm,
      target,
      okQty,
      nokQty,
      materialDesc,
      runTime,
      downtimeMin,
      downtimeReason: isDown ? ['Material Shortage', 'Machine Fault', 'Quality Check', 'Tool Change'][Math.floor(Math.random() * 4)] : null,
      oee,
      qualityRate,
      performanceRate,
      availabilityRate,
      history
    };
  }

  private updateMockLine(line: LineData): LineData {
    const isDown = line.downtimeReason !== null;
    const willRecover = isDown && Math.random() > 0.8;
    const willFail = !isDown && Math.random() > 0.95;

    let newDowntimeReason = line.downtimeReason;
    if (willRecover) newDowntimeReason = null;
    else if (willFail) newDowntimeReason = ['Material Shortage', 'Machine Fault', 'Quality Check', 'Tool Change'][Math.floor(Math.random() * 4)];

    const active = newDowntimeReason === null;
    
    const partsToAdd = active ? Math.floor(line.ppm * (line.performanceRate / 100)) : 0;
    const isNok = Math.random() > (line.qualityRate / 100);
    
    return {
      ...line,
      okQty: line.okQty + (active && !isNok ? partsToAdd : 0),
      nokQty: line.nokQty + (active && isNok ? partsToAdd : 0),
      downtimeMin: line.downtimeMin + (!active ? 1 : 0),
      runTime: line.runTime + (active ? 1 : 0),
      downtimeReason: newDowntimeReason,
      oee: Math.min(100, Math.max(0, line.oee + (Math.random() * 2 - 1))),
      qualityRate: Math.min(100, Math.max(0, line.qualityRate + (Math.random() * 1 - 0.5))),
      performanceRate: Math.min(100, Math.max(0, line.performanceRate + (Math.random() * 2 - 1))),
      availabilityRate: Math.min(100, Math.max(0, line.availabilityRate + (Math.random() * 2 - 1))),
      history: line.history
    };
  }
}
