/**
 * AI Assistant — Premium Chat Interface
 *
 * Modern chat UI with Gemini integration and full programme database context.
 */

import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useAppStore } from "@/lib/store";
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Plus,
  Trash2,
  MessageSquare,
  Sparkles,
  User,
  Loader2,
  Lightbulb,
  Database,
  ArrowDown,
  MoreHorizontal,
  Copy,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

// ─── Constants ────────────────────────────────────────────────────
const GEMINI_API_KEY = "AQ.Ab8RN6JG6Xb2_UyLrLm2FbI19BkAe5aBvO7_9qnSdGtaNZ7Ltw";
const GEMINI_MODEL = "gemini-2.5-flash";
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

// ─── Types ────────────────────────────────────────────────────────
interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
}

// ─── Suggested prompts ────────────────────────────────────────────
const SUGGESTED_PROMPTS = [
  { icon: "🚩", title: "At-Risk Milestones", text: "Which milestones are at risk or delayed right now?" },
  { icon: "💰", title: "Budget Status", text: "Summarize the CAPEX budget status across all programmes" },
  { icon: "📊", title: "Executive Summary", text: "Give me an executive summary of all programmes" },
  { icon: "⚠️", title: "Critical Support", text: "What are the critical open support items?" },
  { icon: "📅", title: "Date Changes", text: "Which milestones have had their dates changed recently?" },
  { icon: "👥", title: "Hiring Gaps", text: "What's the hiring gap across programmes?" },
];

// ─── Build system context from store ──────────────────────────────
function buildSystemContext(store: ReturnType<typeof useAppStore.getState>): string {
  const {
    programmes, businessUnits, capabilities, users,
    milestones, supportRequired, certifications,
    capexBudgets, opexBudgets, supplyChains,
    partnerDeliverables, manpowerPlans, dateChangeLogs,
    programmeOrgNodes,
  } = store;

  const lines: string[] = [
    "You are an AI assistant for the Programme Tracker application at Adani Defence & Aerospace.",
    "You have access to the full programme database. Answer questions using the data below.",
    "Be concise, use markdown tables when showing structured data, and highlight risks/concerns with bold text.",
    "Use INR Crores for financials. Today's date is " + new Date().toISOString().split("T")[0] + ".",
    "",
    "=== CAPABILITIES ===",
    JSON.stringify(capabilities.map(c => ({ id: c.capabilityid, name: c.name }))),
    "",
    "=== BUSINESS UNITS ===",
    JSON.stringify(businessUnits.map(b => ({ id: b.businessunitid, name: b.name, capability: capabilities.find(c => c.capabilityid === b.capabilityid)?.name }))),
    "",
    "=== USERS ===",
    JSON.stringify(users.map(u => ({ id: u.userid, name: u.name }))),
    "",
    "=== PROGRAMMES ===",
    JSON.stringify(programmes.map(p => ({
      id: p.programmeid, name: p.name,
      bu: businessUnits.find(b => b.businessunitid === p.businessid)?.name,
      poc1: users.find(u => u.userid === p.poc1userid)?.name,
      poc2: users.find(u => u.userid === p.poc2userid)?.name,
      lastReportingWeek: p.lastreportingweek, notes: p.notes,
    }))),
    "",
    "=== MILESTONES ===",
    JSON.stringify(milestones.map(m => ({
      programme: programmes.find(p => p.programmeid === m.programmeid)?.name,
      name: m.name, status: m.status,
      start: m.startdate, originalTarget: m.originaltargetedcompletiondate,
      currentTarget: m.targetedcompletiondate,
      owner: programmeOrgNodes.find(n => n.programmeorgnodeid === m.ownerorgnodeid)?.displayname,
      remarks: m.remarks, changeCount: m.changecount,
    }))),
    "",
    "=== SUPPORT REQUIRED ===",
    JSON.stringify(supportRequired.map(s => ({
      programme: programmes.find(p => p.programmeid === s.programmeid)?.name,
      text: s.supporttext, category: s.category, criticality: s.criticality,
      status: s.status, deadline: s.deadline,
      owner: programmeOrgNodes.find(n => n.programmeorgnodeid === s.ownerorgnodeid)?.displayname,
    }))),
    "",
    "=== CERTIFICATIONS ===",
    JSON.stringify(certifications.map(c => ({
      programme: programmes.find(p => p.programmeid === c.programmeid)?.name,
      name: c.name, status: c.status, validity: c.validitydate,
    }))),
    "",
    "=== CAPEX BUDGETS ===",
    JSON.stringify(capexBudgets.map(c => ({
      programme: programmes.find(p => p.programmeid === c.programmeid)?.name,
      item: c.item, budgetCr: c.budgetcr, actualCr: c.actualcr,
    }))),
    "",
    "=== OPEX BUDGETS ===",
    JSON.stringify(opexBudgets.map(o => ({
      programme: programmes.find(p => p.programmeid === o.programmeid)?.name,
      item: o.item, supplier: o.supplier, unitCostCr: o.unitcostcr, targetCostCr: o.targetcostcr,
    }))),
    "",
    "=== SUPPLY CHAIN ===",
    JSON.stringify(supplyChains.map(s => ({
      programme: programmes.find(p => p.programmeid === s.programmeid)?.name,
      item: s.item, supplier: s.supplier, status: s.status,
    }))),
    "",
    "=== PARTNER DELIVERABLES ===",
    JSON.stringify(partnerDeliverables.map(pd => ({
      programme: programmes.find(p => p.programmeid === pd.programmeid)?.name,
      partner: pd.partnername, deliverable: pd.deliverable,
      targetEDC: pd.targetedc, currentEDC: pd.currentedc, status: pd.status,
    }))),
    "",
    "=== MANPOWER / HIRING ===",
    JSON.stringify(manpowerPlans.map(mp => ({
      programme: programmes.find(p => p.programmeid === mp.programmeid)?.name,
      role: mp.role, required: mp.requiredqty, filled: mp.filledqty,
      gap: mp.requiredqty - mp.filledqty, priority: mp.priority,
    }))),
    "",
    "=== RECENT DATE CHANGES (last 30 days) ===",
    JSON.stringify(dateChangeLogs.filter(l => new Date(l.changedon) >= new Date(Date.now() - 30 * 86400000)).map(l => ({
      programme: programmes.find(p => p.programmeid === l.programmeid)?.name,
      module: l.module, record: l.recordname, field: l.fieldname,
      oldDate: l.olddate, newDate: l.newdate, reason: l.reason,
    }))),
  ];

  return lines.join("\n");
}

// ─── Markdown renderer ────────────────────────────────────────────
function renderMarkdown(text: string): React.ReactNode {
  const lines = text.split("\n");
  const elements: React.ReactNode[] = [];
  let inCodeBlock = false;
  let codeBuffer: string[] = [];
  let inLatexBlock = false;
  let latexBuffer: string[] = [];

  lines.forEach((line, i) => {
    // LaTeX block: $$ ... $$
    if (line.trim().startsWith("$$") && !inLatexBlock && !inCodeBlock) {
      const rest = line.trim().slice(2);
      if (rest.endsWith("$$") && rest.length > 2) {
        const expr = rest.slice(0, -2).trim();
        elements.push(
          <div key={`math-${i}`} className="my-2 px-4 py-3 rounded-lg bg-muted/50 border border-border/30 font-mono text-xs text-foreground overflow-x-auto">
            <span className="text-[9px] text-violet-500 font-semibold mr-2">MATH</span>{cleanLatex(expr)}
          </div>
        );
      } else {
        inLatexBlock = true;
        if (rest.trim()) latexBuffer.push(rest.trim());
      }
      return;
    }
    if (inLatexBlock) {
      if (line.trim().endsWith("$$")) {
        const partial = line.trim().replace(/\$\$$/, "").trim();
        if (partial) latexBuffer.push(partial);
        elements.push(
          <div key={`math-${i}`} className="my-2 px-4 py-3 rounded-lg bg-muted/50 border border-border/30 font-mono text-xs text-foreground overflow-x-auto">
            <span className="text-[9px] text-violet-500 font-semibold mr-2">MATH</span>{cleanLatex(latexBuffer.join(" "))}
          </div>
        );
        latexBuffer = [];
        inLatexBlock = false;
      } else {
        latexBuffer.push(line);
      }
      return;
    }

    if (line.startsWith("```")) {
      if (inCodeBlock) {
        elements.push(
          <pre key={`code-${i}`} className="bg-neutral-950 text-neutral-200 rounded-xl p-4 text-xs overflow-x-auto my-3 font-mono border border-neutral-800">
            <code>{codeBuffer.join("\n")}</code>
          </pre>
        );
        codeBuffer = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      return;
    }
    if (inCodeBlock) { codeBuffer.push(line); return; }

    if (line.startsWith("### ")) {
      elements.push(<h4 key={i} className="text-sm font-bold mt-4 mb-1.5 text-foreground">{line.slice(4)}</h4>);
    } else if (line.startsWith("## ")) {
      elements.push(<h3 key={i} className="text-base font-bold mt-4 mb-1.5 text-foreground">{line.slice(3)}</h3>);
    } else if (line.startsWith("# ")) {
      elements.push(<h2 key={i} className="text-lg font-bold mt-4 mb-1.5 text-foreground">{line.slice(2)}</h2>);
    } else if (line.startsWith("|")) {
      const cells = line.split("|").filter(c => c.trim() !== "");
      const isSeparator = cells.every(c => /^[-:]+$/.test(c.trim()));
      if (!isSeparator) {
        const isHeader = i + 1 < lines.length && lines[i + 1]?.startsWith("|") && lines[i + 1]?.includes("---");
        elements.push(
          <div key={i} className={`grid gap-0 text-[12px] border-b border-border/40 dark:border-border/60 ${isHeader ? "font-semibold text-foreground bg-muted/50 dark:bg-muted/30" : "text-foreground/70 dark:text-foreground/80"}`} style={{ gridTemplateColumns: `repeat(${cells.length}, minmax(60px, 1fr))` }}>
            {cells.map((cell, ci) => (
              <span key={ci} className="px-2 py-1.5 break-words min-w-0" dangerouslySetInnerHTML={{ __html: inlineFormat(cell.trim()) }} />
            ))}
          </div>
        );
      }
    } else if (line.match(/^[\s]*[-*]\s/)) {
      const indent = line.match(/^(\s*)/)?.[1]?.length ?? 0;
      elements.push(
        <div key={i} className="flex items-start gap-2.5 text-[13px] leading-relaxed" style={{ paddingLeft: `${indent * 4 + 4}px` }}>
          <span className="text-violet-500 mt-[7px] shrink-0 size-1 rounded-full bg-violet-500" />
          <span dangerouslySetInnerHTML={{ __html: inlineFormat(line.replace(/^[\s]*[-*]\s/, "")) }} />
        </div>
      );
    } else if (line.match(/^[\s]*\d+\.\s/)) {
      const num = line.match(/^[\s]*(\d+)\./)?.[1];
      elements.push(
        <div key={i} className="flex items-start gap-2.5 text-[13px] leading-relaxed pl-1">
          <span className="text-violet-500 font-bold shrink-0 tabular-nums">{num}.</span>
          <span dangerouslySetInnerHTML={{ __html: inlineFormat(line.replace(/^[\s]*\d+\.\s/, "")) }} />
        </div>
      );
    } else if (line.trim() === "") {
      elements.push(<div key={i} className="h-2.5" />);
    } else {
      elements.push(<p key={i} className="text-[13px] leading-relaxed" dangerouslySetInnerHTML={{ __html: inlineFormat(line) }} />);
    }
  });
  return <div className="space-y-0.5">{elements}</div>;
}

function inlineFormat(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold text-foreground">$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code class="px-1.5 py-0.5 rounded-md bg-muted text-[11px] font-mono text-foreground">$1</code>')
    // Inline math: $...$
    .replace(/\$([^$]+?)\$/g, '<span class="font-mono text-[11px] bg-muted/50 px-1 rounded">$1</span>');
}

// Clean LaTeX to readable text
function cleanLatex(tex: string): string {
  return tex
    .replace(/\\text\{([^}]+)\}/g, '$1')
    .replace(/\\mathbf\{([^}]+)\}/g, '$1')
    .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1 / $2)')
    .replace(/\\left\(/g, '(')
    .replace(/\\left\[/g, '[')
    .replace(/\\right\)/g, ')')
    .replace(/\\right\]/g, ']')
    .replace(/\\times/g, '×')
    .replace(/\\Delta/g, 'Δ')
    .replace(/\\%/g, '%')
    .replace(/\\\\/g, ' ')
    .trim();
}

// ─── Copy button for messages ─────────────────────────────────────
function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    const plain = text
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/`(.+?)`/g, '$1')
      .replace(/^#{1,3}\s/gm, '')
      .replace(/^[-*]\s/gm, '• ')
      .replace(/\$\$[^$]*\$\$/g, (m) => cleanLatex(m.replace(/\$\$/g, '')));
    await navigator.clipboard.writeText(plain);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button onClick={copy} className="p-1 rounded-md hover:bg-muted/80 text-muted-foreground/40 hover:text-muted-foreground transition-all" title="Copy">
      {copied ? <Check className="size-3 text-emerald-500" /> : <Copy className="size-3" />}
    </button>
  );
}

// ─── Message bubble ───────────────────────────────────────────────
function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 380, damping: 30 }}
      className={`group flex items-start gap-2.5 ${isUser ? "flex-row-reverse" : ""}`}
    >
      {/* Avatar */}
      <div className={`shrink-0 size-7 rounded-lg flex items-center justify-center mt-0.5 ${isUser
        ? "bg-gradient-to-br from-primary to-primary/80 text-primary-foreground"
        : "bg-gradient-to-br from-violet-500/20 to-blue-500/20 ring-1 ring-violet-500/20 dark:from-violet-500/30 dark:to-blue-500/30 dark:ring-violet-400/30"
        }`}>
        {isUser ? <User className="size-3" /> : <Sparkles className="size-3 text-violet-600 dark:text-violet-300" />}
      </div>

      {/* Content */}
      <div className={`min-w-0 ${isUser ? "max-w-[70%]" : "max-w-[90%]"}`}>
        <div className={`relative rounded-2xl px-4 py-2.5 ${isUser
          ? "bg-primary text-primary-foreground rounded-tr-sm"
          : "bg-card dark:bg-card/80 border border-border/50 dark:border-border rounded-tl-sm shadow-sm dark:shadow-md"
          }`}>
          {/* Inline header inside bubble */}
          <p className={`text-[9px] font-medium mb-1 ${isUser ? "text-primary-foreground/60" : "text-violet-600/70 dark:text-violet-400/70"
            }`}>
            {isUser ? "You" : "AI Assistant"} · {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
          {isUser ? (
            <p className="text-[13px] leading-relaxed">{message.content}</p>
          ) : (
            <div className="text-foreground/80 dark:text-foreground/85">
              {renderMarkdown(message.content)}
            </div>
          )}
          {/* Copy button */}
          {!isUser && (
            <div className="absolute -bottom-3 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-0.5 bg-background border rounded-lg shadow-sm p-0.5">
              <CopyButton text={message.content} />
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ─── Spin verbs for loading states ────────────────────────────────
const SPIN_VERBS = [
  "Thinking...",
  "Analyzing programme data...",
  "Processing your query...",
  "Searching milestones & budgets...",
  "Cross-referencing records...",
  "Crunching the numbers...",
  "Reviewing support items...",
  "Generating insights...",
  "Almost there...",
];

function TypingIndicator() {
  const [verbIdx, setVerbIdx] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setVerbIdx(prev => (prev + 1) % SPIN_VERBS.length);
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="flex items-start gap-2.5"
    >
      {/* Avatar with pulse */}
      <div className="relative shrink-0 size-7 rounded-lg bg-gradient-to-br from-violet-500/20 to-blue-500/20 ring-1 ring-violet-500/20 dark:from-violet-500/30 dark:to-blue-500/30 dark:ring-violet-400/30 flex items-center justify-center mt-0.5">
        <motion.div
          className="absolute inset-0 rounded-lg bg-violet-500/20"
          animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0, 0.3] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        />
        <Sparkles className="size-3 text-violet-600 dark:text-violet-300 relative z-10" />
      </div>

      {/* Spinner bubble */}
      <div className="bg-card dark:bg-card/80 border border-border/50 dark:border-border rounded-2xl rounded-tl-sm shadow-sm dark:shadow-md px-4 py-2.5">
        <div className="flex items-center gap-2.5">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          >
            <Loader2 className="size-4 text-violet-500" />
          </motion.div>
          <AnimatePresence mode="wait">
            <motion.span
              key={verbIdx}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
              className="text-xs font-medium text-muted-foreground"
            >
              {SPIN_VERBS[verbIdx]}
            </motion.span>
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

// ─── Main component ───────────────────────────────────────────────
export function AiAssistant() {
  const store = useAppStore();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const activeConv = conversations.find(c => c.id === activeConvId) ?? null;

  const systemContext = useMemo(() => buildSystemContext(store), [
    store.programmes, store.milestones, store.supportRequired,
    store.certifications, store.capexBudgets, store.supplyChains,
  ]);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => { scrollToBottom(); }, [activeConv?.messages.length]);

  const handleScroll = useCallback(() => {
    const el = chatContainerRef.current;
    if (!el) return;
    setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > 80);
  }, []);

  const newConversation = useCallback(() => {
    const conv: Conversation = {
      id: `conv-${Date.now()}`,
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
    };
    setConversations(prev => [conv, ...prev]);
    setActiveConvId(conv.id);
    setInput("");
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const deleteConversation = useCallback((id: string) => {
    setConversations(prev => prev.filter(c => c.id !== id));
    if (activeConvId === id) setActiveConvId(null);
  }, [activeConvId]);

  const sendMessage = useCallback(async (text?: string) => {
    const msgText = (text ?? input).trim();
    if (!msgText || isLoading) return;

    let convId = activeConvId;
    if (!convId) {
      const conv: Conversation = {
        id: `conv-${Date.now()}`,
        title: msgText.slice(0, 50),
        messages: [],
        createdAt: new Date(),
      };
      setConversations(prev => [conv, ...prev]);
      convId = conv.id;
      setActiveConvId(convId);
    }

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: msgText,
      timestamp: new Date(),
    };

    setConversations(prev => prev.map(c =>
      c.id === convId
        ? { ...c, messages: [...c.messages, userMsg], title: c.messages.length === 0 ? msgText.slice(0, 50) : c.title }
        : c
    ));
    setInput("");
    setIsLoading(true);

    try {
      const currentConv = conversations.find(c => c.id === convId);
      const history = currentConv?.messages ?? [];

      const chatHistory = [
        { role: "user" as const, parts: [{ text: systemContext }] },
        { role: "model" as const, parts: [{ text: "Understood. I have access to the full programme database. How can I help?" }] },
        ...history.map(m => ({
          role: (m.role === "user" ? "user" : "model") as "user" | "model",
          parts: [{ text: m.content }],
        })),
      ];

      // Min 3s spinner + 90s timeout
      const minWait = new Promise(r => setTimeout(r, 3000));
      const timeout = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("Request timed out after 90 seconds")), 90000)
      );

      const apiCall = ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: [
          ...chatHistory,
          { role: "user" as const, parts: [{ text: msgText }] },
        ],
        config: { temperature: 0.7, maxOutputTokens: 4096 },
      });

      const [response] = await Promise.all([
        Promise.race([apiCall, timeout]),
        minWait,
      ]);

      const aiText = response.text ?? "Sorry, I couldn't generate a response.";
      const aiMsg: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        role: "assistant",
        content: aiText,
        timestamp: new Date(),
      };
      setConversations(prev => prev.map(c =>
        c.id === convId ? { ...c, messages: [...c.messages, aiMsg] } : c
      ));
    } catch (err) {
      const errorMsg: ChatMessage = {
        id: `msg-${Date.now()}-err`,
        role: "assistant",
        content: `⚠️ **Error:** ${err instanceof Error ? err.message : "Failed to get response"}.\n\nPlease check your API key and try again.`,
        timestamp: new Date(),
      };
      setConversations(prev => prev.map(c =>
        c.id === convId ? { ...c, messages: [...c.messages, errorMsg] } : c
      ));
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, activeConvId, conversations, systemContext]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const dataStats = useMemo(() => ({
    programmes: store.programmes.length,
    milestones: store.milestones.length,
    support: store.supportRequired.length,
    certs: store.certifications.length,
  }), [store.programmes, store.milestones, store.supportRequired, store.certifications]);

  return (
    <div className="flex h-[calc(100vh-3rem)] -m-6 overflow-hidden min-h-0">

      {/* ═══════════════════════════════════════════════════════ */}
      {/* LEFT: Conversation Sidebar                              */}
      {/* ═══════════════════════════════════════════════════════ */}
      <div className="w-56 max-w-[30%] shrink-0 border-r bg-muted/15 flex flex-col min-h-0">

        {/* Header */}
        <div className="p-2 border-b shrink-0">
          <Button onClick={newConversation} className="w-full gap-1.5 text-[11px] h-8 rounded-lg" variant="outline">
            <Plus className="size-3" />
            New Chat
          </Button>
        </div>

        {/* Chat list */}
        <ScrollArea className="flex-1 min-h-0">
          <div className="p-1.5 space-y-0.5">
            {conversations.length === 0 ? (
              <div className="py-8 text-center px-3">
                <div className="size-10 mx-auto rounded-xl bg-gradient-to-br from-violet-500/10 to-blue-500/10 flex items-center justify-center mb-2">
                  <MessageSquare className="size-4 text-muted-foreground/30" />
                </div>
                <p className="text-[11px] text-muted-foreground font-medium">No conversations yet</p>
                <p className="text-[10px] text-muted-foreground/60 mt-0.5">Start a new chat</p>
              </div>
            ) : (
              conversations.map(conv => (
                <motion.button
                  key={conv.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  onClick={() => setActiveConvId(conv.id)}
                  className={`w-full group flex items-center gap-2 rounded-lg px-2 py-2 text-left transition-all ${activeConvId === conv.id
                    ? "bg-primary/8 text-foreground border border-primary/10"
                    : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                    }`}
                >
                  <MessageSquare className="size-3 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <span className="text-[11px] truncate block font-medium">{conv.title}</span>
                    <span className="text-[9px] text-muted-foreground/60">{conv.messages.length} messages</span>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); deleteConversation(conv.id); }}
                    className="opacity-0 group-hover:opacity-100 shrink-0 p-0.5 rounded hover:bg-destructive/10 text-destructive/60 hover:text-destructive transition-all"
                  >
                    <Trash2 className="size-2.5" />
                  </button>
                </motion.button>
              ))
            )}
          </div>
        </ScrollArea>

        {/* Data context — compact */}
        <div className="p-2 border-t shrink-0">
          <div className="rounded-lg bg-gradient-to-br from-violet-500/[0.06] to-blue-500/[0.04] border border-violet-500/10 px-2.5 py-2">
            <div className="flex items-center gap-1 mb-1.5">
              <Database className="size-2.5 text-violet-500" />
              <span className="text-[9px] font-bold uppercase tracking-wider text-violet-600/80 dark:text-violet-400/80">Connected Data</span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
              {[
                { label: "Prog", count: dataStats.programmes },
                { label: "Miles", count: dataStats.milestones },
                { label: "Supp", count: dataStats.support },
                { label: "Certs", count: dataStats.certs },
              ].map(s => (
                <div key={s.label} className="flex items-center justify-between">
                  <span className="text-[9px] text-muted-foreground">{s.label}</span>
                  <span className="text-[9px] font-bold tabular-nums">{s.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════ */}
      {/* MAIN: Chat Area                                         */}
      {/* ═══════════════════════════════════════════════════════ */}
      <div className="flex-1 min-w-0 flex flex-col bg-background relative min-h-0">

        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.015]" style={{
          backgroundImage: "radial-gradient(circle, currentColor 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }} />

        {/* Header */}
        <div className="relative h-11 shrink-0 border-b flex items-center px-4 gap-2.5 bg-background/80 backdrop-blur-sm z-10">
          <div className="relative">
            <div className="size-7 rounded-lg bg-gradient-to-br from-violet-500/15 to-blue-500/15 ring-1 ring-violet-500/10 flex items-center justify-center">
              <Sparkles className="size-3.5 text-violet-600 dark:text-violet-300" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 size-2 rounded-full bg-emerald-500 ring-2 ring-background" />
          </div>
          <div className="min-w-0">
            <h2 className="text-xs font-bold tracking-tight">Programme AI</h2>
            <p className="text-[9px] text-muted-foreground/70">Gemini · Full database access</p>
          </div>
          <div className="ml-auto shrink-0">
            <div className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[9px] font-semibold flex items-center gap-1">
              <span className="size-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Online
            </div>
          </div>
        </div>

        {/* Messages area */}
        <div
          ref={chatContainerRef}
          onScroll={handleScroll}
          className="flex-1 min-h-0 overflow-y-auto relative z-0"
        >
          {!activeConv || activeConv.messages.length === 0 ? (
            /* ── Welcome state ── */
            <div className="h-full flex flex-col items-center justify-center px-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
                className="text-center w-full max-w-md"
              >
                {/* Animated icon */}
                <div className="relative mx-auto mb-5 size-16">
                  <motion.div
                    className="absolute inset-0 rounded-2xl bg-gradient-to-br from-violet-500/20 to-blue-500/20 blur-xl"
                    animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.7, 0.4] }}
                    transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  />
                  <div className="relative size-16 rounded-2xl bg-gradient-to-br from-violet-500/10 to-blue-500/10 border border-violet-500/15 flex items-center justify-center">
                    <Sparkles className="size-7 text-violet-500/80" />
                  </div>
                </div>

                <h2 className="text-lg font-bold tracking-tight mb-1">
                  Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}
                </h2>
                <p className="text-xs text-muted-foreground mb-6 max-w-xs mx-auto">
                  Ask me about milestones, budgets, risks, or anything in your programme data.
                </p>

                {/* Suggested prompts */}
                <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                  {SUGGESTED_PROMPTS.map((prompt, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 + i * 0.04, type: "spring", stiffness: 300, damping: 25 }}
                      onClick={() => sendMessage(prompt.text)}
                      className="group text-left rounded-lg border border-border/50 bg-card/50 hover:bg-card hover:border-primary/20 hover:shadow-sm px-3 py-2.5 transition-all duration-200"
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="text-xs">{prompt.icon}</span>
                        <span className="text-[11px] font-semibold text-foreground group-hover:text-primary transition-colors">{prompt.title}</span>
                      </div>
                      <span className="text-[10px] text-muted-foreground/70 leading-snug line-clamp-2 group-hover:text-muted-foreground transition-colors">
                        {prompt.text}
                      </span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </div>
          ) : (
            /* ── Messages list ── */
            <div className="max-w-4xl mx-auto px-5 py-4 space-y-4">
              {activeConv.messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              <AnimatePresence>
                {isLoading && <TypingIndicator />}
              </AnimatePresence>
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Scroll-to-bottom */}
        <AnimatePresence>
          {showScrollBtn && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={scrollToBottom}
              className="absolute bottom-20 left-1/2 -translate-x-1/2 size-8 rounded-full bg-card border shadow-lg flex items-center justify-center hover:bg-muted transition-colors z-20"
            >
              <ArrowDown className="size-3.5 text-muted-foreground" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* ── Input area ── */}
        <div className="relative shrink-0 border-t bg-background/80 backdrop-blur-sm px-4 py-2 z-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-2 rounded-xl border border-border/50 bg-card shadow-sm focus-within:border-primary/30 focus-within:shadow-md transition-all px-3 py-1.5">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  // Auto-resize
                  const el = e.target;
                  el.style.height = "0";
                  el.style.height = Math.min(el.scrollHeight, 112) + "px";
                }}
                onKeyDown={handleKeyDown}
                placeholder="Ask about your programmes..."
                rows={1}
                className="flex-1 resize-none bg-transparent text-sm outline-none placeholder:text-muted-foreground/40 leading-snug py-1"
                style={{ height: "28px", maxHeight: "112px" }}
              />
              <Button
                size="icon-sm"
                onClick={() => sendMessage()}
                disabled={!input.trim() || isLoading}
                className="shrink-0 rounded-lg size-7 bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white shadow-sm disabled:opacity-30 disabled:from-muted disabled:to-muted transition-all"
              >
                {isLoading ? <Loader2 className="size-3.5 animate-spin" /> : <Send className="size-3" />}
              </Button>
            </div>
            <p className="text-[9px] text-muted-foreground/40 text-center mt-1">
              Enter to send · Shift+Enter for new line
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
