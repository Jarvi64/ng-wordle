import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AppLayout } from "./components/layout/AppLayout";
import { Dashboard } from "./pages/Dashboard";
import { CapabilityMaster } from "./pages/master/CapabilityMaster";
import { BusinessUnitMaster } from "./pages/master/BusinessUnitMaster";
import { ProgrammeMaster } from "./pages/master/ProgrammeMaster";
import { ProgrammeDetail } from "./pages/ProgrammeDetail";
import { GanttPage } from "./pages/GanttPage";
import { CEOReview } from "./pages/CEOReview";
import { AiAssistant } from "./pages/AiAssistant";

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/capabilities" element={<CapabilityMaster />} />
          <Route path="/business-units" element={<BusinessUnitMaster />} />
          <Route path="/programmes" element={<ProgrammeMaster />} />
          <Route path="/programmes/:id" element={<ProgrammeDetail />} />
          <Route path="/gantt" element={<GanttPage />} />
          <Route path="/ceo-review" element={<CEOReview />} />
          <Route path="/ai-assistant" element={<AiAssistant />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
