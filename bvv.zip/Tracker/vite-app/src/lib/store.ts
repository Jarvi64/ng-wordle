import { create } from 'zustand';

// ── Master Types ──────────────────────────────────────────────
export type User = { userid: string; name: string; email: string };
export type Capability = { capabilityid: string; name: string; description: string };
export type BusinessUnit = { businessunitid: string; name: string; description: string; capabilityid: string };
export type Programme = { programmeid: string; name: string; notes: string; lastreportingweek: string; poc1userid: string; poc2userid: string; businessid: string };

// ── Programme-level Types ─────────────────────────────────────
export type ProgrammeOrgNode = {
  programmeorgnodeid: string;
  programmeid: string;
  displayname: string;
  title: string;
  sortorder: number;
  active: string;
  parentnodeid: string | null;
};

export type Milestone = {
  milestoneid: string;
  programmeid: string;
  name: string;
  startdate: string;
  originaltargetedcompletiondate: string;
  targetedcompletiondate: string;
  ownerorgnodeid: string;
  status: string;
  remarks: string;
  changecount: number;
  lastchangereason: string;
};

export type SupportRequired = {
  supportrequiredid: string;
  programmeid: string;
  supporttext: string;
  category: string;
  criticality: string;
  ownerorgnodeid: string;
  deadline: string;
  status: string;
};

export type DateChangeLog = {
  datechangelogid: string;
  programmeid: string;
  module: 
    | "milestone"
    | "support_required"
    | "partner_deliverable"
    | "capex"
    | "opex"
    | "certification"
    | "supply_chain";
  recordid: string;
  recordname: string;
  fieldname: string;
  olddate: string;
  newdate: string;
  reason: string;
  changedon: string;
};

export type ManpowerGapHiringPlan = {
  manpowergaphiringplansid: string;
  programmeid: string;
  role: string;
  requiredqty: number;
  filledqty: number;
  sourcingchannel: string;
  targetjoindate: string;
  priority: string;
  remarks: string;
};

export type WeeklyUpdate = {
  weeklyupdateid: string;
  programmeid: string;
  weekkey: string; // e.g. "2026-W14"
  submittedon: string; // ISO datetime
  status: string; // Draft / Submitted
};

export type WeeklyUpdateItem = {
  weeklyupdateitemid: string;
  weeklyupdateid: string;
  category: string;
  entrytype: string; // "positive" | "negative"
  description: string;
};

export type PartnerDeliverable = {
  partnerdeliverableid: string;
  programmeid: string;
  partnername: string;
  deliverable: string;
  targetedc: string; // ISO string
  currentedc: string; // ISO string
  status: string;
  riskremarks: string;
  ownerorgnodeid: string;
};

export type CapexBudget = {
  capexbudgetid: string;
  programmeid: string;
  item: string;
  budgetcr: number;
  actualcr: number;
  commisiongdate: string;
  ownerorgnodeid: string;
};

export type OpexBudget = {
  programmebudgetid: string;
  programmeid: string;
  item: string;
  supplier: string;
  unitcostcr: number;
  targetcostcr: number;
  deadline: string;
  ownerorgnodeid: string;
};

export type Certification = {
  certificationid: string;
  programmeid: string;
  name: string;
  ownerorgnodeid: string;
  status: string;
  validitydate: string;
  currentedc: string;
  riskremarks: string;
};

export type SupplyChainReadiness = {
  supplychainreadinessid: string;
  programmeid: string;
  item: string;
  supplier: string;
  actualcostcr: number;
  targetcostcr: number;
  variancecr: number;
  status: string;
  riskremarks: string;
  dateoforder: string;
  dateofdelivery: string;
  leadtime: string;
  ownerorgnodeid: string;
};

// ── Constants ─────────────────────────────────────────────────
export const MILESTONE_STATUSES = ['Not Started', 'In Progress', 'Completed', 'Delayed', 'At Risk'] as const;
export const SUPPORT_CATEGORIES = ['Program', 'Engineering', 'SCM', 'Partner', 'Manpower', 'Certifications', 'Infra/Project', 'Supply Chain', 'Finance'] as const;
export const SUPPORT_CRITICALITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export const SUPPORT_STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'] as const;
export const SOURCING_CHANNELS = ['IJP', 'External'] as const;
export const HIRING_PRIORITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export const WEEKLY_CATEGORIES = ['Program', 'Engineering', 'SCM', 'Partner', 'Manpower', 'Certifications', 'Infra/Project', 'Supply Chain', 'Finance'] as const;

// ── Store Interface ───────────────────────────────────────────
interface AppState {
  users: User[];
  capabilities: Capability[];
  businessUnits: BusinessUnit[];
  programmes: Programme[];
  programmeOrgNodes: ProgrammeOrgNode[];
  milestones: Milestone[];
  supportRequired: SupportRequired[];
  dateChangeLogs: DateChangeLog[];
  manpowerPlans: ManpowerGapHiringPlan[];
  weeklyUpdates: WeeklyUpdate[];
  weeklyUpdateItems: WeeklyUpdateItem[];
  partnerDeliverables: PartnerDeliverable[];
  capexBudgets: CapexBudget[];
  opexBudgets: OpexBudget[];
  certifications: Certification[];
  supplyChains: SupplyChainReadiness[];

  // Master CRUD
  addCapability: (cap: Omit<Capability, 'capabilityid'>) => void;
  updateCapability: (id: string, cap: Partial<Capability>) => void;
  deleteCapability: (id: string) => void;

  addBusinessUnit: (bu: Omit<BusinessUnit, 'businessunitid'>) => void;
  updateBusinessUnit: (id: string, bu: Partial<BusinessUnit>) => void;
  deleteBusinessUnit: (id: string) => void;

  addProgramme: (prog: Omit<Programme, 'programmeid'>) => void;
  updateProgramme: (id: string, prog: Partial<Programme>) => void;
  deleteProgramme: (id: string) => void;

  // Programme-level CRUD
  addMilestone: (m: Omit<Milestone, 'milestoneid' | 'changecount' | 'lastchangereason'>) => void;
  updateMilestone: (id: string, m: Partial<Milestone>) => void;
  deleteMilestone: (id: string) => void;

  addSupportRequired: (s: Omit<SupportRequired, 'supportrequiredid'>) => void;
  updateSupportRequired: (id: string, s: Partial<SupportRequired>) => void;
  deleteSupportRequired: (id: string) => void;

  addManpowerPlan: (p: Omit<ManpowerGapHiringPlan, 'manpowergaphiringplansid'>) => void;
  updateManpowerPlan: (id: string, p: Partial<ManpowerGapHiringPlan>) => void;
  deleteManpowerPlan: (id: string) => void;

  // Org nodes CRUD
  addOrgNode: (n: Omit<ProgrammeOrgNode, 'programmeorgnodeid'>) => void;
  updateOrgNode: (id: string, n: Partial<ProgrammeOrgNode>) => void;
  deleteOrgNode: (id: string) => void;

  // Weekly Updates
  addWeeklyUpdate: (u: Omit<WeeklyUpdate, 'weeklyupdateid'>) => void;
  updateWeeklyUpdate: (id: string, u: Partial<WeeklyUpdate>) => void;
  deleteWeeklyUpdate: (id: string) => void;

  // Weekly Update Items
  addWeeklyUpdateItem: (item: Omit<WeeklyUpdateItem, 'weeklyupdateitemid'>) => void;
  updateWeeklyUpdateItem: (id: string, item: Partial<WeeklyUpdateItem>) => void;
  deleteWeeklyUpdateItem: (id: string) => void;
  bulkSetWeeklyUpdateItems: (weeklyupdateid: string, items: Omit<WeeklyUpdateItem, 'weeklyupdateitemid'>[]) => void;

  // Partner Deliverables
  addPartnerDeliverable: (d: Omit<PartnerDeliverable, 'partnerdeliverableid'>) => void;
  updatePartnerDeliverable: (id: string, d: Partial<PartnerDeliverable>) => void;
  deletePartnerDeliverable: (id: string) => void;

  // Budgets
  addCapexBudget: (c: Omit<CapexBudget, 'capexbudgetid'>) => void;
  updateCapexBudget: (id: string, c: Partial<CapexBudget>) => void;
  deleteCapexBudget: (id: string) => void;

  addOpexBudget: (o: Omit<OpexBudget, 'programmebudgetid'>) => void;
  updateOpexBudget: (id: string, o: Partial<OpexBudget>) => void;
  deleteOpexBudget: (id: string) => void;

  // Certifications
  addCertification: (c: Omit<Certification, 'certificationid'>) => void;
  updateCertification: (id: string, c: Partial<Certification>) => void;
  deleteCertification: (id: string) => void;

  // Supply Chain Readiness
  addSupplyChain: (s: Omit<SupplyChainReadiness, 'supplychainreadinessid'>) => void;
  updateSupplyChain: (id: string, s: Partial<SupplyChainReadiness>) => void;
  deleteSupplyChain: (id: string) => void;

  // Date change log (append-only)
  addDateChangeLog: (log: Omit<DateChangeLog, 'datechangelogid' | 'changedon'>) => void;
}

// ── Seed Data ─────────────────────────────────────────────────
const DUMMY_USERS: User[] = [
  { userid: 'usr_1', name: 'Alice Smith', email: 'alice@example.com' },
  { userid: 'usr_2', name: 'Bob Jones', email: 'bob@example.com' },
  { userid: 'usr_3', name: 'Charlie Davis', email: 'charlie@example.com' },
  { userid: 'usr_4', name: 'Diana Prince', email: 'diana@example.com' },
];

const DUMMY_CAPABILITIES: Capability[] = [
  { capabilityid: 'cap_1', name: 'Software Engineering', description: 'Core software development functions' },
  { capabilityid: 'cap_2', name: 'Marketing', description: 'Global marketing and brand management' },
];

const DUMMY_BUSINESS_UNITS: BusinessUnit[] = [
  { businessunitid: 'bu_1', name: 'Web Applications', description: 'Frontend and Backend Apps', capabilityid: 'cap_1' },
  { businessunitid: 'bu_2', name: 'Mobile Experiences', description: 'iOS and Android Apps', capabilityid: 'cap_1' },
  { businessunitid: 'bu_3', name: 'Digital Marketing', description: 'Social media and Ads', capabilityid: 'cap_2' },
];

const DUMMY_PROGRAMMES: Programme[] = [
  { programmeid: 'prog_1', name: 'Programme Alpha', notes: 'Main flagship web rewrite', lastreportingweek: '2026-W14', poc1userid: 'usr_1', poc2userid: 'usr_2', businessid: 'bu_1' },
  { programmeid: 'prog_2', name: 'Project Zephyr', notes: 'Customer pipeline expansion', lastreportingweek: '2026-W13', poc1userid: 'usr_3', poc2userid: 'usr_4', businessid: 'bu_3' },
];

const DUMMY_ORG_NODES: ProgrammeOrgNode[] = [
  { programmeorgnodeid: 'org_1', programmeid: 'prog_1', displayname: 'Alice Smith', title: 'Programme Director', sortorder: 1, active: 'Yes', parentnodeid: null },
  { programmeorgnodeid: 'org_2', programmeid: 'prog_1', displayname: 'Bob Jones', title: 'Tech Lead', sortorder: 2, active: 'Yes', parentnodeid: 'org_1' },
  { programmeorgnodeid: 'org_3', programmeid: 'prog_1', displayname: 'Charlie Davis', title: 'Delivery Manager', sortorder: 3, active: 'Yes', parentnodeid: 'org_1' },
  { programmeorgnodeid: 'org_4', programmeid: 'prog_2', displayname: 'Diana Prince', title: 'Programme Lead', sortorder: 1, active: 'Yes', parentnodeid: null },
  { programmeorgnodeid: 'org_5', programmeid: 'prog_2', displayname: 'Alice Smith', title: 'Engineering Lead', sortorder: 2, active: 'Yes', parentnodeid: 'org_4' },
];

const DUMMY_MILESTONES: Milestone[] = [
  { milestoneid: 'ms_1', programmeid: 'prog_1', name: 'Requirements Sign-off', startdate: '2026-01-15', originaltargetedcompletiondate: '2026-02-28', targetedcompletiondate: '2026-03-10', ownerorgnodeid: 'org_1', status: 'Completed', remarks: 'Signed off with minor changes', changecount: 1, lastchangereason: 'Stakeholder review delayed' },
  { milestoneid: 'ms_2', programmeid: 'prog_1', name: 'Architecture Review', startdate: '2026-02-01', originaltargetedcompletiondate: '2026-03-15', targetedcompletiondate: '2026-03-15', ownerorgnodeid: 'org_2', status: 'In Progress', remarks: '', changecount: 0, lastchangereason: '' },
  { milestoneid: 'ms_3', programmeid: 'prog_1', name: 'Beta Release', startdate: '2026-03-01', originaltargetedcompletiondate: '2026-05-30', targetedcompletiondate: '2026-06-15', ownerorgnodeid: 'org_2', status: 'At Risk', remarks: 'Dependency on partner API', changecount: 2, lastchangereason: 'Partner integration delay' },
  { milestoneid: 'ms_4', programmeid: 'prog_2', name: 'Market Research Phase', startdate: '2026-02-01', originaltargetedcompletiondate: '2026-03-31', targetedcompletiondate: '2026-03-31', ownerorgnodeid: 'org_4', status: 'Completed', remarks: '', changecount: 0, lastchangereason: '' },
  { milestoneid: 'ms_5', programmeid: 'prog_2', name: 'Campaign Launch', startdate: '2026-04-01', originaltargetedcompletiondate: '2026-05-15', targetedcompletiondate: '2026-05-15', ownerorgnodeid: 'org_5', status: 'Not Started', remarks: 'Pending budget approval', changecount: 0, lastchangereason: '' },
];

const DUMMY_SUPPORT: SupportRequired[] = [
  { supportrequiredid: 'sup_1', programmeid: 'prog_1', supporttext: 'Need dedicated DevOps engineer for CI/CD pipeline setup', category: 'Engineering', criticality: 'High', ownerorgnodeid: 'org_2', deadline: '2026-04-15', status: 'Open' },
  { supportrequiredid: 'sup_2', programmeid: 'prog_1', supporttext: 'Partner API documentation access required', category: 'Partner', criticality: 'Critical', ownerorgnodeid: 'org_3', deadline: '2026-04-10', status: 'In Progress' },
  { supportrequiredid: 'sup_3', programmeid: 'prog_2', supporttext: 'Budget allocation for ad spend Q2', category: 'Finance', criticality: 'Medium', ownerorgnodeid: 'org_4', deadline: '2026-04-20', status: 'Open' },
];

const DUMMY_MANPOWER: ManpowerGapHiringPlan[] = [
  { manpowergaphiringplansid: 'mp_1', programmeid: 'prog_1', role: 'Senior Backend Engineer', requiredqty: 3, filledqty: 2, sourcingchannel: 'IJP', targetjoindate: '2026-05-01', priority: 'High', remarks: 'Need Java/Spring expertise' },
  { manpowergaphiringplansid: 'mp_2', programmeid: 'prog_1', role: 'DevOps Engineer', requiredqty: 2, filledqty: 0, sourcingchannel: 'External', targetjoindate: '2026-04-15', priority: 'Critical', remarks: 'CI/CD pipeline setup' },
  { manpowergaphiringplansid: 'mp_3', programmeid: 'prog_1', role: 'QA Automation Lead', requiredqty: 1, filledqty: 1, sourcingchannel: 'IJP', targetjoindate: '2026-03-15', priority: 'Medium', remarks: '' },
  { manpowergaphiringplansid: 'mp_4', programmeid: 'prog_2', role: 'Digital Marketing Manager', requiredqty: 2, filledqty: 1, sourcingchannel: 'External', targetjoindate: '2026-05-10', priority: 'High', remarks: 'Campaign planning' },
];

const now = new Date();
const twoDaysAgo = new Date(now.getTime() - 2 * 86400000).toISOString();
const tenDaysAgo = new Date(now.getTime() - 10 * 86400000).toISOString();

const DUMMY_DATE_LOGS: DateChangeLog[] = [
  { datechangelogid: 'dcl_1', programmeid: 'prog_1', module: 'milestone', recordid: 'ms_1', recordname: 'Requirements Sign-off', fieldname: 'targetedcompletiondate', olddate: '2026-02-28', newdate: '2026-03-10', reason: 'Stakeholder review delayed', changedon: twoDaysAgo },
  { datechangelogid: 'dcl_2', programmeid: 'prog_1', module: 'milestone', recordid: 'ms_3', recordname: 'Beta Release', fieldname: 'targetedcompletiondate', olddate: '2026-05-30', newdate: '2026-06-10', reason: 'Resource constraints', changedon: tenDaysAgo },
  { datechangelogid: 'dcl_3', programmeid: 'prog_1', module: 'milestone', recordid: 'ms_3', recordname: 'Beta Release', fieldname: 'targetedcompletiondate', olddate: '2026-06-10', newdate: '2026-06-15', reason: 'Partner integration delay', changedon: twoDaysAgo },
];

const DUMMY_WEEKLY_UPDATES: WeeklyUpdate[] = [
  { weeklyupdateid: 'wu_1', programmeid: 'prog_1', weekkey: '2026-W13', submittedon: '2026-03-28T10:30:00Z', status: 'Submitted' },
  { weeklyupdateid: 'wu_2', programmeid: 'prog_1', weekkey: '2026-W14', submittedon: '2026-04-04T14:15:00Z', status: 'Submitted' },
];

const DUMMY_WEEKLY_ITEMS: WeeklyUpdateItem[] = [
  { weeklyupdateitemid: 'wui_1', weeklyupdateid: 'wu_1', category: 'Program', entrytype: 'positive', description: 'Requirements sign-off achieved ahead of schedule' },
  { weeklyupdateitemid: 'wui_2', weeklyupdateid: 'wu_1', category: 'Program', entrytype: 'negative', description: 'Stakeholder availability remains a bottleneck' },
  { weeklyupdateitemid: 'wui_3', weeklyupdateid: 'wu_1', category: 'Engineering', entrytype: 'positive', description: 'CI/CD pipeline setup completed' },
  { weeklyupdateitemid: 'wui_4', weeklyupdateid: 'wu_1', category: 'Engineering', entrytype: 'negative', description: 'Tech debt backlog growing — needs prioritisation' },
  { weeklyupdateitemid: 'wui_5', weeklyupdateid: 'wu_1', category: 'SCM', entrytype: 'positive', description: 'Vendor shortlisting completed for Phase 2' },
  { weeklyupdateitemid: 'wui_6', weeklyupdateid: 'wu_1', category: 'Manpower', entrytype: 'negative', description: 'DevOps position still unfilled after 4 weeks' },
  { weeklyupdateitemid: 'wui_7', weeklyupdateid: 'wu_1', category: 'Finance', entrytype: 'positive', description: 'Q2 budget approved' },
  { weeklyupdateitemid: 'wui_8', weeklyupdateid: 'wu_2', category: 'Program', entrytype: 'positive', description: 'Requirements sign-off achieved ahead of schedule' },
  { weeklyupdateitemid: 'wui_9', weeklyupdateid: 'wu_2', category: 'Program', entrytype: 'positive', description: 'Architecture review meeting scheduled for next week' },
  { weeklyupdateitemid: 'wui_10', weeklyupdateid: 'wu_2', category: 'Program', entrytype: 'negative', description: 'Stakeholder availability remains a bottleneck' },
  { weeklyupdateitemid: 'wui_11', weeklyupdateid: 'wu_2', category: 'Engineering', entrytype: 'positive', description: 'CI/CD pipeline setup completed' },
  { weeklyupdateitemid: 'wui_12', weeklyupdateid: 'wu_2', category: 'Engineering', entrytype: 'positive', description: 'Code review process standardised' },
  { weeklyupdateitemid: 'wui_13', weeklyupdateid: 'wu_2', category: 'Engineering', entrytype: 'negative', description: 'Beta release delayed due to partner API integration' },
  { weeklyupdateitemid: 'wui_14', weeklyupdateid: 'wu_2', category: 'Partner', entrytype: 'negative', description: 'API documentation access still pending from partner' },
  { weeklyupdateitemid: 'wui_15', weeklyupdateid: 'wu_2', category: 'Manpower', entrytype: 'negative', description: 'DevOps position still unfilled after 5 weeks' },
  { weeklyupdateitemid: 'wui_16', weeklyupdateid: 'wu_2', category: 'Manpower', entrytype: 'positive', description: 'QA Automation Lead onboarded successfully' },
  { weeklyupdateitemid: 'wui_17', weeklyupdateid: 'wu_2', category: 'Finance', entrytype: 'positive', description: 'Q2 budget approved' },
  { weeklyupdateitemid: 'wui_18', weeklyupdateid: 'wu_2', category: 'Infra/Project', entrytype: 'positive', description: 'Dev environment provisioning completed' },
];

const DUMMY_PARTNER_DELIVERABLES: PartnerDeliverable[] = [
  { partnerdeliverableid: 'pd_1', programmeid: 'prog_1', partnername: 'AWS', deliverable: 'Cloud Infrastructure Setup & Security Audit', targetedc: '2026-05-01', currentedc: '2026-05-15', status: 'In Progress', riskremarks: 'Waiting on compliance team', ownerorgnodeid: 'org_2' }
];

const DUMMY_CAPEX: CapexBudget[] = [
  { capexbudgetid: 'capx_1', programmeid: 'prog_1', item: 'Assembly Line Conveyors', budgetcr: 4.5, actualcr: 4.65, commisiongdate: '2026-07-01', ownerorgnodeid: 'org_1' }
];

const DUMMY_OPEX: OpexBudget[] = [
  { programmebudgetid: 'opx_1', programmeid: 'prog_1', item: 'Software Licensing', supplier: 'Microsoft', unitcostcr: 0.1, targetcostcr: 5.0, deadline: '2026-12-31', ownerorgnodeid: 'org_1' }
];

const DUMMY_CERTIFICATIONS: Certification[] = [
  { certificationid: 'cert_1', programmeid: 'prog_1', name: 'ISO 9001 Compliance Audit', status: 'In Review', validitydate: '2027-01-01', currentedc: '2026-11-01', riskremarks: '', ownerorgnodeid: 'org_3' }
];

const DUMMY_SUPPLY_CHAIN: SupplyChainReadiness[] = [
  { supplychainreadinessid: 'scr_1', programmeid: 'prog_1', item: 'Raw Steel Sheets', supplier: 'Tata Steel', actualcostcr: 12.5, targetcostcr: 12.0, variancecr: -0.5, status: 'In Transit', riskremarks: 'Delay in shipping port', dateoforder: '2026-02-15', dateofdelivery: '2026-04-30', leadtime: '10 Weeks', ownerorgnodeid: 'org_1' }
];

// ── Helpers ───────────────────────────────────────────────────
const generateId = (prefix: string) => `${prefix}_${Math.random().toString(36).substr(2, 9)}`;

export const useAppStore = create<AppState>((set) => ({
  users: DUMMY_USERS,
  capabilities: DUMMY_CAPABILITIES,
  businessUnits: DUMMY_BUSINESS_UNITS,
  programmes: DUMMY_PROGRAMMES,
  programmeOrgNodes: DUMMY_ORG_NODES,
  milestones: DUMMY_MILESTONES,
  supportRequired: DUMMY_SUPPORT,
  dateChangeLogs: DUMMY_DATE_LOGS,
  manpowerPlans: DUMMY_MANPOWER,
  weeklyUpdates: DUMMY_WEEKLY_UPDATES,
  weeklyUpdateItems: DUMMY_WEEKLY_ITEMS,
  partnerDeliverables: DUMMY_PARTNER_DELIVERABLES,
  capexBudgets: DUMMY_CAPEX,
  opexBudgets: DUMMY_OPEX,
  certifications: DUMMY_CERTIFICATIONS,
  supplyChains: DUMMY_SUPPLY_CHAIN,

  // ── Master CRUD ──
  addCapability: (cap) => set((state) => ({ capabilities: [...state.capabilities, { ...cap, capabilityid: generateId('cap') }] })),
  updateCapability: (id, cap) => set((state) => ({ capabilities: state.capabilities.map((c) => (c.capabilityid === id ? { ...c, ...cap } : c)) })),
  deleteCapability: (id) => set((state) => ({ capabilities: state.capabilities.filter((c) => c.capabilityid !== id) })),

  addBusinessUnit: (bu) => set((state) => ({ businessUnits: [...state.businessUnits, { ...bu, businessunitid: generateId('bu') }] })),
  updateBusinessUnit: (id, bu) => set((state) => ({ businessUnits: state.businessUnits.map((b) => (b.businessunitid === id ? { ...b, ...bu } : b)) })),
  deleteBusinessUnit: (id) => set((state) => ({ businessUnits: state.businessUnits.filter((b) => b.businessunitid !== id) })),

  addProgramme: (prog) => set((state) => ({ programmes: [...state.programmes, { ...prog, programmeid: generateId('prog') }] })),
  updateProgramme: (id, prog) => set((state) => ({ programmes: state.programmes.map((p) => (p.programmeid === id ? { ...p, ...prog } : p)) })),
  deleteProgramme: (id) => set((state) => ({ programmes: state.programmes.filter((p) => p.programmeid !== id) })),

  // ── Milestones ──
  addMilestone: (m) => set((state) => ({
    milestones: [...state.milestones, { ...m, milestoneid: generateId('ms'), changecount: 0, lastchangereason: '' }],
  })),
  updateMilestone: (id, m) => set((state) => ({
    milestones: state.milestones.map((ms) => (ms.milestoneid === id ? { ...ms, ...m } : ms)),
  })),
  deleteMilestone: (id) => set((state) => ({
    milestones: state.milestones.filter((ms) => ms.milestoneid !== id),
  })),

  // ── Support Required ──
  addSupportRequired: (s) => set((state) => ({
    supportRequired: [...state.supportRequired, { ...s, supportrequiredid: generateId('sup') }],
  })),
  updateSupportRequired: (id, s) => set((state) => ({
    supportRequired: state.supportRequired.map((sr) => (sr.supportrequiredid === id ? { ...sr, ...s } : sr)),
  })),
  deleteSupportRequired: (id) => set((state) => ({
    supportRequired: state.supportRequired.filter((sr) => sr.supportrequiredid !== id),
  })),

  // ── Manpower Plans ──
  addManpowerPlan: (p) => set((state) => ({
    manpowerPlans: [...state.manpowerPlans, { ...p, manpowergaphiringplansid: generateId('mp') }],
  })),
  updateManpowerPlan: (id, p) => set((state) => ({
    manpowerPlans: state.manpowerPlans.map((mp) => (mp.manpowergaphiringplansid === id ? { ...mp, ...p } : mp)),
  })),
  deleteManpowerPlan: (id) => set((state) => ({
    manpowerPlans: state.manpowerPlans.filter((mp) => mp.manpowergaphiringplansid !== id),
  })),

  // ── Org Nodes ──
  addOrgNode: (n) => set((state) => ({
    programmeOrgNodes: [...state.programmeOrgNodes, { ...n, programmeorgnodeid: generateId('org') }],
  })),
  updateOrgNode: (id, n) => set((state) => ({
    programmeOrgNodes: state.programmeOrgNodes.map((node) => (node.programmeorgnodeid === id ? { ...node, ...n } : node)),
  })),
  deleteOrgNode: (id) => set((state) => ({
    programmeOrgNodes: state.programmeOrgNodes.filter((node) => node.programmeorgnodeid !== id),
  })),

  // ── Weekly Updates ──
  addWeeklyUpdate: (u) => set((state) => ({
    weeklyUpdates: [...state.weeklyUpdates, { ...u, weeklyupdateid: generateId('wu') }],
  })),
  updateWeeklyUpdate: (id, u) => set((state) => ({
    weeklyUpdates: state.weeklyUpdates.map((wu) => (wu.weeklyupdateid === id ? { ...wu, ...u } : wu)),
  })),
  deleteWeeklyUpdate: (id) => set((state) => ({
    weeklyUpdates: state.weeklyUpdates.filter((wu) => wu.weeklyupdateid !== id),
    weeklyUpdateItems: state.weeklyUpdateItems.filter((i) => i.weeklyupdateid !== id),
  })),

  // ── Weekly Update Items ──
  addWeeklyUpdateItem: (item) => set((state) => ({
    weeklyUpdateItems: [...state.weeklyUpdateItems, { ...item, weeklyupdateitemid: generateId('wui') }],
  })),
  updateWeeklyUpdateItem: (id, item) => set((state) => ({
    weeklyUpdateItems: state.weeklyUpdateItems.map((i) => (i.weeklyupdateitemid === id ? { ...i, ...item } : i)),
  })),
  deleteWeeklyUpdateItem: (id) => set((state) => ({
    weeklyUpdateItems: state.weeklyUpdateItems.filter((i) => i.weeklyupdateitemid !== id),
  })),
  bulkSetWeeklyUpdateItems: (weeklyupdateid, newItems) =>
    set((state) => {
      const filtered = state.weeklyUpdateItems.filter((i) => i.weeklyupdateid !== weeklyupdateid);
      const toAdd = newItems.map((n) => ({ ...n, weeklyupdateitemid: generateId('wui') }));
      return { weeklyUpdateItems: [...filtered, ...toAdd] };
    }),

  // Extended Tabs
  addPartnerDeliverable: (d) => set((s) => ({ partnerDeliverables: [...s.partnerDeliverables, { ...d, partnerdeliverableid: generateId('pd') }] })),
  updatePartnerDeliverable: (id, updates) => set((s) => ({
    partnerDeliverables: s.partnerDeliverables.map((x) => x.partnerdeliverableid === id ? { ...x, ...updates } : x)
  })),
  deletePartnerDeliverable: (id) => set((s) => ({ partnerDeliverables: s.partnerDeliverables.filter((x) => x.partnerdeliverableid !== id) })),

  addCapexBudget: (c) => set((s) => ({ capexBudgets: [...s.capexBudgets, { ...c, capexbudgetid: generateId('capx') }] })),
  updateCapexBudget: (id, updates) => set((s) => ({
    capexBudgets: s.capexBudgets.map((x) => x.capexbudgetid === id ? { ...x, ...updates } : x)
  })),
  deleteCapexBudget: (id) => set((s) => ({ capexBudgets: s.capexBudgets.filter((x) => x.capexbudgetid !== id) })),

  addOpexBudget: (o) => set((s) => ({ opexBudgets: [...s.opexBudgets, { ...o, programmebudgetid: generateId('opx') }] })),
  updateOpexBudget: (id, updates) => set((s) => ({
    opexBudgets: s.opexBudgets.map((x) => x.programmebudgetid === id ? { ...x, ...updates } : x)
  })),
  deleteOpexBudget: (id) => set((s) => ({ opexBudgets: s.opexBudgets.filter((x) => x.programmebudgetid !== id) })),

  addCertification: (c) => set((s) => ({ certifications: [...s.certifications, { ...c, certificationid: generateId('cert') }] })),
  updateCertification: (id, updates) => set((s) => ({
    certifications: s.certifications.map((x) => x.certificationid === id ? { ...x, ...updates } : x)
  })),
  deleteCertification: (id) => set((s) => ({ certifications: s.certifications.filter((x) => x.certificationid !== id) })),

  addSupplyChain: (sc) => set((s) => ({ supplyChains: [...s.supplyChains, { ...sc, supplychainreadinessid: generateId('scr') }] })),
  updateSupplyChain: (id, updates) => set((s) => ({
    supplyChains: s.supplyChains.map((x) => x.supplychainreadinessid === id ? { ...x, ...updates } : x)
  })),
  deleteSupplyChain: (id) => set((s) => ({ supplyChains: s.supplyChains.filter((x) => x.supplychainreadinessid !== id) })),

  // Date logs
  addDateChangeLog: (log) =>
    set((state) => ({
      dateChangeLogs: [
        ...state.dateChangeLogs,
        { ...log, datechangelogid: generateId('dcl'), changedon: new Date().toISOString() },
      ],
    })),
}));
