import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useAppStore } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  Clock,
  Flag,
  LayoutGrid,
  Search,
  TrendingDown,
  TrendingUp,
  Zap,
} from "lucide-react";

// ── Types & colour maps ──────────────────────────────────────────
type Health = "On Track" | "In Progress" | "Delayed" | "At Risk" | "No Data";

const HEALTH_DOT: Record<Health, string> = {
  "On Track":    "bg-emerald-500",
  "In Progress": "bg-blue-500",
  "Delayed":     "bg-amber-500",
  "At Risk":     "bg-red-500",
  "No Data":     "bg-slate-400",
};
const HEALTH_BADGE: Record<Health, string> = {
  "On Track":    "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
  "Delayed":     "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  "At Risk":     "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
  "No Data":     "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
};
const HEALTH_BAR: Record<Health, string> = {
  "On Track":    "#10b981",
  "In Progress": "#0874B0",
  "Delayed":     "#f59e0b",
  "At Risk":     "#ef4444",
  "No Data":     "#94a3b8",
};
const HEALTH_ORDER: Health[] = ["At Risk", "Delayed", "In Progress", "On Track", "No Data"];

// ── Grid column template (shared between header + rows) ──────────
const COLS = "16px minmax(160px,1fr) 96px minmax(140px,1.2fr) 200px 200px 80px 20px";

function getHealth(msStatuses: string[]): Health {
  if (!msStatuses.length) return "No Data";
  if (msStatuses.includes("At Risk")) return "At Risk";
  if (msStatuses.includes("Delayed")) return "Delayed";
  if (msStatuses.every((s) => s === "Completed")) return "On Track";
  if (msStatuses.includes("In Progress") || msStatuses.includes("Not Started")) return "In Progress";
  return "No Data";
}

// ── Capability group header ──────────────────────────────────────
function GroupHeader({
  label, count, atRisk, open, onToggle,
}: {
  label: string; count: number; atRisk: number; open: boolean; onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg bg-muted/60 hover:bg-muted transition-colors text-left"
    >
      <ChevronDown className={`size-4 text-muted-foreground transition-transform duration-200 ${open ? "" : "-rotate-90"}`} />
      <LayoutGrid className="size-3.5 text-primary" />
      <span className="text-sm font-semibold flex-1">{label}</span>
      <span className="text-xs text-muted-foreground">{count} programme{count !== 1 ? "s" : ""}</span>
      {atRisk > 0 && (
        <Badge className="bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300 text-[10px]">
          {atRisk} at risk
        </Badge>
      )}
    </button>
  );
}

// ── Programme row ────────────────────────────────────────────────
function ProgrammeRow({
  prog, health, buName, poc1,
  msTotal, msCompleted, msAtRisk,
  openSupport, critSupport, recentChanges, capexVariance,
}: {
  prog: ReturnType<typeof useAppStore.getState>["programmes"][0];
  health: Health; buName: string; poc1: string;
  msTotal: number; msCompleted: number; msAtRisk: number;
  openSupport: number; critSupport: number; recentChanges: number;
  capexVariance: number | null;
}) {
  const msPercent = msTotal > 0 ? Math.round((msCompleted / msTotal) * 100) : 0;
  const barColor  = HEALTH_BAR[health];

  return (
    <Link
      to={`/programmes/${prog.programmeid}`}
      className="group grid items-center gap-x-4 px-4 py-3 rounded-xl border bg-card hover:bg-muted/20 hover:shadow-md transition-all duration-150"
      style={{ gridTemplateColumns: COLS }}
    >
      {/* 1. Health dot */}
      <span className={`size-2.5 rounded-full ${HEALTH_DOT[health]}`} />

      {/* 2. Name + BU */}
      <div className="min-w-0">
        <p className="text-sm font-semibold truncate group-hover:text-primary transition-colors">
          {prog.name}
        </p>
        <p className="text-[10px] text-muted-foreground truncate">{buName}</p>
      </div>

      {/* 3. Health badge */}
      <div>
        <Badge className={`${HEALTH_BADGE[health]} text-[10px] px-2 py-0.5 font-semibold`}>
          {health}
        </Badge>
      </div>

      {/* 4. Milestone progress */}
      <div className="min-w-0">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] text-muted-foreground">
            {msCompleted} of {msTotal} done
          </span>
          <span className="text-[10px] font-bold ml-2 shrink-0">{msPercent}%</span>
        </div>
        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
          <div className="h-full rounded-full" style={{ width: `${msPercent}%`, background: barColor }} />
        </div>
      </div>

      {/* 5. Risk & Support — labelled */}
      <div className="flex flex-col gap-1 min-w-0">
        <span className={`flex items-center gap-1.5 text-[11px] font-medium ${msAtRisk > 0 ? "text-red-600" : "text-muted-foreground"}`}>
          <AlertTriangle className="size-3 shrink-0" />
          {msAtRisk > 0 ? `${msAtRisk} milestone${msAtRisk > 1 ? "s" : ""} at risk` : "No milestones at risk"}
        </span>
        <span className={`flex items-center gap-1.5 text-[11px] font-medium ${
          critSupport > 0 ? "text-rose-600" : openSupport > 0 ? "text-amber-600" : "text-muted-foreground"
        }`}>
          <Zap className="size-3 shrink-0" />
          {openSupport > 0
            ? `${openSupport} open support${critSupport > 0 ? ` · ${critSupport} critical` : ""}`
            : "No open support items"}
        </span>
      </div>

      {/* 6. Changes & Budget — labelled */}
      <div className="flex flex-col gap-1 min-w-0">
        <span className={`flex items-center gap-1.5 text-[11px] font-medium ${recentChanges > 0 ? "text-violet-600" : "text-muted-foreground"}`}>
          <Clock className="size-3 shrink-0" />
          {recentChanges > 0 ? `${recentChanges} date change${recentChanges > 1 ? "s" : ""} this week` : "No recent date changes"}
        </span>
        {capexVariance !== null ? (
          <span className={`flex items-center gap-1.5 text-[11px] font-medium ${capexVariance >= 0 ? "text-emerald-600" : "text-red-600"}`}>
            {capexVariance >= 0
              ? <TrendingUp className="size-3 shrink-0" />
              : <TrendingDown className="size-3 shrink-0" />}
            CAPEX {capexVariance >= 0 ? "+" : ""}{capexVariance.toFixed(1)} CR
          </span>
        ) : (
          <span className="text-[11px] text-muted-foreground">No budget data</span>
        )}
      </div>

      {/* 7. Week + POC */}
      <div className="text-right min-w-0">
        <p className="text-[11px] font-semibold">{prog.lastreportingweek}</p>
        <p className="text-[10px] text-muted-foreground truncate">{poc1}</p>
      </div>

      {/* 8. Hover arrow */}
      <ArrowRight className="size-4 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
    </Link>
  );
}

// ── Main Dashboard ───────────────────────────────────────────────
export function Dashboard() {
  const {
    programmes, capabilities, businessUnits, users,
    milestones, supportRequired, dateChangeLogs, capexBudgets,
  } = useAppStore();

  const [search, setSearch]           = useState("");
  const [openGroups, setOpenGroups]   = useState<Record<string, boolean>>({});
  const [filterHealth, setFilterHealth] = useState<Health | "All">("All");

  const today       = new Date();
  const sevenDaysAgo = new Date(today.getTime() - 7 * 86400000);

  // ── Per-programme stats ──────────────────────────────────────
  const progData = useMemo(() => programmes.map((p) => {
    const pid = p.programmeid;
    const pMs   = milestones.filter((m) => m.programmeid === pid);
    const msCompleted = pMs.filter((m) => m.status === "Completed").length;
    const msAtRisk    = pMs.filter((m) => m.status === "At Risk" || m.status === "Delayed").length;
    const health      = getHealth(pMs.map((m) => m.status));

    const pSup    = supportRequired.filter((s) => s.programmeid === pid && s.status !== "Closed" && s.status !== "Resolved");
    const critSup = pSup.filter((s) => s.criticality === "Critical").length;

    const recentChanges = dateChangeLogs.filter(
      (l) => l.programmeid === pid && new Date(l.changedon) >= sevenDaysAgo
    ).length;

    const pCap   = capexBudgets.filter((c) => c.programmeid === pid);
    const capexV = pCap.length
      ? pCap.reduce((a, c) => a + c.budgetcr, 0) - pCap.reduce((a, c) => a + c.actualcr, 0)
      : null;

    const buObj   = businessUnits.find((b) => b.businessunitid === p.businessid);
    const buName  = buObj?.name ?? "—";
    const capId   = buObj?.capabilityid ?? "";
    const capName = capabilities.find((c) => c.capabilityid === capId)?.name ?? "Uncategorised";
    const poc1    = users.find((u) => u.userid === p.poc1userid)?.name ?? "—";

    return { prog: p, health, buName, capName, poc1, msTotal: pMs.length, msCompleted, msAtRisk, openSupport: pSup.length, critSupport: critSup, recentChanges, capexVariance: capexV };
  }), [programmes, milestones, supportRequired, dateChangeLogs, capexBudgets, businessUnits, capabilities, users]);

  // ── Global KPIs ──────────────────────────────────────────────
  const totalOnTrack    = progData.filter((d) => d.health === "On Track").length;
  const totalAtRisk     = progData.filter((d) => d.health === "At Risk").length;
  const totalCritSup    = progData.reduce((a, d) => a + d.critSupport, 0);
  const totalChanges    = progData.reduce((a, d) => a + d.recentChanges, 0);

  // ── Filter ───────────────────────────────────────────────────
  const filtered = useMemo(() => progData.filter((d) => {
    const q = search.toLowerCase();
    const matchSearch = !q
      || d.prog.name.toLowerCase().includes(q)
      || d.buName.toLowerCase().includes(q)
      || d.capName.toLowerCase().includes(q)
      || d.poc1.toLowerCase().includes(q);
    const matchHealth = filterHealth === "All" || d.health === filterHealth;
    return matchSearch && matchHealth;
  }), [progData, search, filterHealth]);

  // ── Group by capability ──────────────────────────────────────
  const grouped = useMemo(() => {
    const map = new Map<string, typeof filtered>();
    filtered.forEach((d) => {
      if (!map.has(d.capName)) map.set(d.capName, []);
      map.get(d.capName)!.push(d);
    });
    map.forEach((items) =>
      items.sort((a, b) => HEALTH_ORDER.indexOf(a.health) - HEALTH_ORDER.indexOf(b.health))
    );
    return map;
  }, [filtered]);

  const isOpen     = (name: string) => openGroups[name] !== false;
  const toggleGroup = (name: string) => setOpenGroups((p) => ({ ...p, [name]: !isOpen(name) }));

  return (
    <div className="space-y-5 pb-10">

      {/* ── Page header ── */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Programme Command Centre</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          All programmes at a glance — click any row to open its detail view
        </p>
      </div>

      {/* ── KPI strip ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total Programmes",  value: programmes.length, icon: LayoutGrid,   accent: "#0874B0",  sub: `Across ${capabilities.length} capabilities` },
          { label: "On Track",          value: totalOnTrack,      icon: CheckCircle2, accent: "#10b981",  sub: `${Math.round((totalOnTrack / Math.max(programmes.length, 1)) * 100)}% of portfolio` },
          { label: "At Risk",           value: totalAtRisk,       icon: AlertTriangle,accent: totalAtRisk > 0 ? "#ef4444" : "#10b981", sub: "Requires immediate attention" },
          { label: "Critical Support",  value: totalCritSup,      icon: Zap,          accent: totalCritSup > 0 ? "#BD3661" : "#10b981", sub: `+ ${totalChanges} date changes this week` },
        ].map((s) => (
          <Card key={s.label} className="relative overflow-hidden">
            <div className="absolute inset-0 opacity-[0.05]" style={{ background: `radial-gradient(circle at top right, ${s.accent}, transparent 65%)` }} />
            <CardContent className="pt-3 pb-3 px-4">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">{s.label}</span>
                <div className="size-7 rounded-lg flex items-center justify-center" style={{ background: `${s.accent}22` }}>
                  <s.icon className="size-3.5" style={{ color: s.accent }} />
                </div>
              </div>
              <div className="text-2xl font-bold tracking-tight">{s.value}</div>
              <p className="text-[10px] text-muted-foreground mt-0.5">{s.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Portfolio health bar ── */}
      <Card>
        <CardContent className="py-3 px-4">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="size-3.5 text-primary" />
            <span className="text-xs font-semibold">Portfolio Health — click a segment to filter</span>
          </div>
          <div className="flex h-3 rounded-full overflow-hidden gap-px">
            {HEALTH_ORDER.map((h) => {
              const count = progData.filter((d) => d.health === h).length;
              const pct   = programmes.length > 0 ? (count / programmes.length) * 100 : 0;
              if (pct === 0) return null;
              return (
                <button
                  key={h}
                  title={`${h}: ${count}`}
                  className="h-full first:rounded-l-full last:rounded-r-full hover:opacity-80 transition-opacity"
                  style={{ width: `${pct}%`, background: HEALTH_BAR[h] }}
                  onClick={() => setFilterHealth((prev) => prev === h ? "All" : h)}
                />
              );
            })}
          </div>
          <div className="flex items-center gap-5 mt-2 flex-wrap">
            {HEALTH_ORDER.map((h) => {
              const count = progData.filter((d) => d.health === h).length;
              if (count === 0) return null;
              return (
                <button
                  key={h}
                  onClick={() => setFilterHealth((prev) => prev === h ? "All" : h)}
                  className={`flex items-center gap-1.5 text-[11px] transition-opacity ${filterHealth !== "All" && filterHealth !== h ? "opacity-30" : ""}`}
                >
                  <span className={`size-2 rounded-full ${HEALTH_DOT[h]}`} />
                  <span className="text-muted-foreground">{h}</span>
                  <span className="font-bold">{count}</span>
                </button>
              );
            })}
            {filterHealth !== "All" && (
              <button onClick={() => setFilterHealth("All")} className="text-[11px] text-primary underline ml-auto">
                Clear filter
              </button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Search ── */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
        <Input
          placeholder="Search programmes, capabilities, business units or POC…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* ── Column header — same grid as rows ── */}
      <div
        className="hidden sm:grid items-center gap-x-4 px-4 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground border-b"
        style={{ gridTemplateColumns: COLS }}
      >
        <span />
        <span>Programme / BU</span>
        <span>Health</span>
        <span>Milestone Progress</span>
        <span>Risk & Support</span>
        <span>Changes & Budget</span>
        <span className="text-right">Week · POC</span>
        <span />
      </div>

      {/* ── Grouped rows ── */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Flag className="size-10 mx-auto opacity-20 mb-3" />
          <p className="text-sm">No programmes match your search.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {Array.from(grouped.entries()).map(([capName, items]) => {
            const open   = isOpen(capName);
            const atRisk = items.filter((d) => d.health === "At Risk").length;
            return (
              <div key={capName}>
                <GroupHeader
                  label={capName} count={items.length} atRisk={atRisk}
                  open={open} onToggle={() => toggleGroup(capName)}
                />
                {open && (
                  <div className="space-y-1.5 mt-1.5 animate-in fade-in slide-in-from-top-1 duration-150">
                    {items.map((d) => (
                      <ProgrammeRow
                        key={d.prog.programmeid}
                        prog={d.prog} health={d.health} buName={d.buName} poc1={d.poc1}
                        msTotal={d.msTotal} msCompleted={d.msCompleted} msAtRisk={d.msAtRisk}
                        openSupport={d.openSupport} critSupport={d.critSupport}
                        recentChanges={d.recentChanges} capexVariance={d.capexVariance}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
