import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, AlertTriangle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { DatePicker } from "@/components/ui/date-picker";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DateChangePopover } from "@/components/ui/date-change-popover";

const STATUSES = ["Pending", "In Review", "Approved", "Rejected", "Expired"];

const STATUS_COLORS: Record<string, string> = {
  "Pending": "bg-muted text-muted-foreground",
  "In Review": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "Approved": "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  "Rejected": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  "Expired": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
};

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  status: z.string().min(1, "Status is required"),
  validitydate: z.string().min(1, "Validity Date is required"),
  currentedc: z.string().min(1, "Current EDC is required"),
  riskremarks: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export function CertificationsTab({ programmeId }: { programmeId: string }) {
  const {
    certifications,
    programmeOrgNodes,
    addCertification,
    updateCertification,
    deleteCertification,
    addDateChangeLog,
    dateChangeLogs,
  } = useAppStore();

  const items = certifications.filter((s) => s.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter(
    (n) => n.programmeid === programmeId && n.active === "Yes",
  );

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Date change Tracking
  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDateChangeData, setPendingDateChangeData] = useState<{
    formData: FormData;
    changes: { field: string; oldDate: string; newDate: string }[];
  } | null>(null);
  const [showReasonDialog, setShowReasonDialog] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const openAddDialog = () => {
    reset({ name: "", ownerorgnodeid: "", validitydate: "", currentedc: "", status: "Pending", riskremarks: "" });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((s) => s.certificationid === id);
    if (item) {
      reset({ ...item, riskremarks: item.riskremarks || "" });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (editingId) {
      const existing = items.find((s) => s.certificationid === editingId);
      if (existing) {
        const changes = [];
        if (existing.validitydate !== data.validitydate) {
          changes.push({ field: "validitydate", oldDate: existing.validitydate, newDate: data.validitydate });
        }
        if (existing.currentedc !== data.currentedc) {
          changes.push({ field: "currentedc", oldDate: existing.currentedc, newDate: data.currentedc });
        }

        if (changes.length > 0) {
          setPendingDateChangeData({ formData: data, changes });
          setShowReasonDialog(true);
          return;
        }
      }
    }
    await saveItem(data);
  };

  const saveItem = async (data: FormData, reason?: string) => {
    setIsSaving(true);
    try {
      if (editingId) {
        updateCertification(editingId, data);
        if (pendingDateChangeData && reason) {
          for (const change of pendingDateChangeData.changes) {
            addDateChangeLog({
              programmeid: programmeId,
              module: "certification",
              recordid: editingId,
              recordname: data.name,
              fieldname: change.field,
              olddate: change.oldDate,
              newdate: change.newDate,
              reason: reason,
            });
          }
        }
        toast.success("Certification updated");
      } else {
        addCertification({ ...data, programmeid: programmeId, riskremarks: data.riskremarks || "" });
        toast.success("Certification added");
      }
      setIsDialogOpen(false);
      setPendingDateChangeData(null);
      setDateChangeReason("");
    } catch (e) {
      toast.error("Failed to save");
    } finally {
      setIsSaving(false);
    }
  };

  const confirmDateChange = async () => {
    if (dateChangeReason.trim().length < 5) return toast.error("Please provide a valid reason");
    if (pendingDateChangeData) {
      await saveItem(pendingDateChangeData.formData, dateChangeReason);
      setShowReasonDialog(false);
    }
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      deleteCertification(deleteTarget);
      toast.success("Deleted successfully");
      setDeleteTarget(null);
    } catch (e) {
      toast.error("Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  const getOwnerName = (nodeId: string) => {
    const node = programmeOrgNodes.find((n) => n.programmeorgnodeid === nodeId);
    return node ? node.displayname : "Unknown";
  };

  return (
    <div className="space-y-4 mt-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium leading-none">Certifications & Approvals Tracker</h3>
        <Button onClick={openAddDialog} size="sm">
          <Plus className="size-4 mr-2" />
          Add Certification
        </Button>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Certification Name</TableHead>
              <TableHead>Validity Date</TableHead>
              <TableHead>Current EDC</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[80px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No certifications recorded.</TableCell></TableRow>
            ) : (
              items.map((item) => {
                const validityLogs = dateChangeLogs.filter((l) => l.recordid === item.certificationid && l.module === "certification" && l.fieldname === "validitydate");
                const currentLogs = dateChangeLogs.filter((l) => l.recordid === item.certificationid && l.module === "certification" && l.fieldname === "currentedc");
                return (
                <TableRow key={item.certificationid}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>
                    {validityLogs.length > 0 ? (
                      <DateChangePopover logs={validityLogs}>
                        {item.validitydate}
                        <AlertTriangle className="size-3.5 text-amber-500" />
                      </DateChangePopover>
                    ) : (
                      item.validitydate
                    )}
                  </TableCell>
                  <TableCell>
                    {currentLogs.length > 0 ? (
                      <DateChangePopover logs={currentLogs}>
                        {item.currentedc}
                        <AlertTriangle className="size-3.5 text-amber-500" />
                      </DateChangePopover>
                    ) : (
                      item.currentedc
                    )}
                  </TableCell>
                  <TableCell>{getOwnerName(item.ownerorgnodeid)}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={STATUS_COLORS[item.status] || ""}>{item.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-muted" onClick={() => openEditDialog(item.certificationid)}>
                        <Pencil className="size-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/10" onClick={() => setDeleteTarget(item.certificationid)}>
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Certification" : "Add Certification"}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4 px-1">
            <Field>
              <Label>Certification Name</Label>
              <Input {...register("name")} placeholder="e.g. ISO 9001" />
              {errors.name && <FieldError>{errors.name.message}</FieldError>}
            </Field>

            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Validity Date</Label>
                <Controller
                  control={control}
                  name="validitydate"
                  render={({ field }) => <DatePicker value={field.value} onChange={field.onChange} />}
                />
                {errors.validitydate && <FieldError>{errors.validitydate.message}</FieldError>}
              </Field>
              <Field>
                <Label>Current EDC</Label>
                <Controller
                  control={control}
                  name="currentedc"
                  render={({ field }) => <DatePicker value={field.value} onChange={field.onChange} />}
                />
                {errors.currentedc && <FieldError>{errors.currentedc.message}</FieldError>}
              </Field>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Owner (Org Node)</Label>
                <Controller
                  control={control}
                  name="ownerorgnodeid"
                  render={({ field }) => (
                    <Combobox value={field.value} onValueChange={field.onChange} items={orgNodes.map((n) => n.programmeorgnodeid)}>
                      <ComboboxInput placeholder="Select owner..." />
                      <ComboboxContent>
                        <ComboboxList>
                          {(id) => {
                            const n = orgNodes.find((x) => x.programmeorgnodeid === id);
                            return <ComboboxItem key={id} value={id}>{n?.displayname}</ComboboxItem>;
                          }}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  )}
                />
                {errors.ownerorgnodeid && <FieldError>{errors.ownerorgnodeid.message}</FieldError>}
              </Field>
              <Field>
                <Label>Status</Label>
                <Controller
                  control={control}
                  name="status"
                  render={({ field }) => (
                    <Combobox value={field.value} onValueChange={field.onChange} items={STATUSES}>
                      <ComboboxInput placeholder="Select status..." />
                      <ComboboxContent>
                        <ComboboxList>
                          {(s) => <ComboboxItem key={s} value={s}>{s}</ComboboxItem>}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  )}
                />
                {errors.status && <FieldError>{errors.status.message}</FieldError>}
              </Field>
            </div>

            <Field>
              <Label>Risk / Remarks (Optional)</Label>
              <Textarea {...register("riskremarks")} rows={2} />
            </Field>

            <DialogFooter className="mt-6">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={isSaving}>Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={showReasonDialog} onOpenChange={(open) => !open && setShowReasonDialog(false)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Date Change Justification</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {pendingDateChangeData?.changes.map((c, i) => (
              <div key={i} className="text-sm p-3 bg-muted/40 rounded-md border">
                <strong>{c.field}:</strong> <span className="line-through">{c.oldDate}</span> {" -> "} 
                <span className="font-semibold text-primary">{c.newDate}</span>
              </div>
            ))}
            <div className="space-y-2">
              <Label>Reason</Label>
              <Textarea value={dateChangeReason} onChange={(e) => setDateChangeReason(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReasonDialog(false)}>Cancel</Button>
            <Button onClick={confirmDateChange} disabled={isSaving || dateChangeReason.trim().length < 5}>Confirm Change</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Certification?</AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button variant="destructive" onClick={confirmDelete} disabled={isDeleting}>Delete</Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
