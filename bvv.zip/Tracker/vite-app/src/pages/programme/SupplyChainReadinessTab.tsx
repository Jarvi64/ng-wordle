import { useState, useMemo } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, AlertTriangle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { DatePicker } from "@/components/ui/date-picker";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DateChangePopover } from "@/components/ui/date-change-popover";

const STATUSES = ["Sourcing", "Ordered", "In Transit", "Delivered", "Delayed"];

const schema = z.object({
  item: z.string().min(1, "Item is required"),
  supplier: z.string().min(1, "Supplier is required"),
  actualcostcr: z.coerce.number().min(0, "Must be positive"),
  targetcostcr: z.coerce.number().min(0, "Must be positive"),
  status: z.string().min(1, "Status is required"),
  dateoforder: z.string().min(1, "Order date is required"),
  dateofdelivery: z.string().min(1, "Delivery date is required"),
  leadtime: z.string().min(1, "Lead time is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  riskremarks: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export function SupplyChainReadinessTab({ programmeId }: { programmeId: string }) {
  const {
    supplyChains,
    programmeOrgNodes,
    addSupplyChain,
    updateSupplyChain,
    deleteSupplyChain,
    addDateChangeLog,
    dateChangeLogs,
  } = useAppStore();

  const items = supplyChains.filter((s) => s.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter((n) => n.programmeid === programmeId && n.active === "Yes");

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Totals calculations
  const totalTarget = items.reduce((acc, i) => acc + i.targetcostcr, 0);
  const totalActual = items.reduce((acc, i) => acc + i.actualcostcr, 0);
  const totalVariance = totalTarget - totalActual;

  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDateChangeData, setPendingDateChangeData] = useState<{
    formData: FormData;
    changes: { field: string; oldDate: string; newDate: string }[];
  } | null>(null);
  const [showReasonDialog, setShowReasonDialog] = useState(false);

  const { register, handleSubmit, reset, control, watch, formState: { errors } } = useForm<FormData>({ 
    resolver: zodResolver(schema) 
  });

  // Calculate Variance dynamically on the form
  const watchActual = watch("actualcostcr", 0);
  const watchTarget = watch("targetcostcr", 0);
  const currentVariance = useMemo(() => watchTarget - watchActual, [watchActual, watchTarget]);

  const openAddDialog = () => {
    reset({
      item: "", supplier: "", actualcostcr: 0, targetcostcr: 0,
      status: "Sourcing", dateoforder: "", dateofdelivery: "",
      leadtime: "", ownerorgnodeid: "", riskremarks: ""
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((s) => s.supplychainreadinessid === id);
    if (item) {
      reset({ ...item, riskremarks: item.riskremarks || "" });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (editingId) {
      const existing = items.find((s) => s.supplychainreadinessid === editingId);
      if (existing) {
        const changes = [];
        if (existing.dateoforder !== data.dateoforder) {
          changes.push({ field: "dateoforder", oldDate: existing.dateoforder, newDate: data.dateoforder });
        }
        if (existing.dateofdelivery !== data.dateofdelivery) {
          changes.push({ field: "dateofdelivery", oldDate: existing.dateofdelivery, newDate: data.dateofdelivery });
        }

        if (changes.length > 0) {
          setPendingDateChangeData({ formData: data, changes });
          setShowReasonDialog(true);
          return;
        }
      }
    }
    await saveItem(data);
  };

  const saveItem = async (data: FormData, reason?: string) => {
    setIsSaving(true);
    try {
      const variancecr = data.targetcostcr - data.actualcostcr;
      const payload = { ...data, variancecr, programmeid: programmeId, riskremarks: data.riskremarks || "" };

      if (editingId) {
        updateSupplyChain(editingId, payload);
        if (pendingDateChangeData && reason) {
          for (const change of pendingDateChangeData.changes) {
            addDateChangeLog({
              programmeid: programmeId,
              module: "supply_chain",
              recordid: editingId,
              recordname: data.item,
              fieldname: change.field,
              olddate: change.oldDate,
              newdate: change.newDate,
              reason: reason,
            });
          }
        }
        toast.success("Supply chain updated");
      } else {
        addSupplyChain(payload);
        toast.success("Supply chain added");
      }
      setIsDialogOpen(false);
      setPendingDateChangeData(null);
      setDateChangeReason("");
    } catch (e) {
      toast.error("Failed to save");
    } finally {
      setIsSaving(false);
    }
  };

  const confirmDateChange = async () => {
    if (dateChangeReason.trim().length < 5) return toast.error("Please provide a valid reason");
    if (pendingDateChangeData) {
      await saveItem(pendingDateChangeData.formData, dateChangeReason);
      setShowReasonDialog(false);
    }
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      deleteSupplyChain(deleteTarget);
      toast.success("Deleted successfully");
      setDeleteTarget(null);
    } catch (e) {
      toast.error("Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  const getOwnerName = (nodeId: string) => {
    const node = programmeOrgNodes.find((n) => n.programmeorgnodeid === nodeId);
    return node ? node.displayname : "Unknown";
  };

  return (
    <div className="space-y-4 mt-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium leading-none">Supply Chain Readiness</h3>
        <Button onClick={openAddDialog} size="sm">
          <Plus className="size-4 mr-2" />
          Add Supply Item
        </Button>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Item</TableHead>
              <TableHead>Supplier</TableHead>
              <TableHead>Target (CR)</TableHead>
              <TableHead>Actual (CR)</TableHead>
              <TableHead>Variance</TableHead>
              <TableHead>Order Date</TableHead>
              <TableHead>Delivery Date</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[80px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">No supply chain items recorded.</TableCell></TableRow>
            ) : (
              items.map((item) => {
                const deliveryLogs = dateChangeLogs.filter((l) => l.recordid === item.supplychainreadinessid && l.module === "supply_chain" && l.fieldname === "dateofdelivery");
                const hasHistory = deliveryLogs.length > 0;
                const variance = item.targetcostcr - item.actualcostcr;
                
                return (
                  <TableRow key={item.supplychainreadinessid}>
                    <TableCell className="font-medium">{item.item}</TableCell>
                    <TableCell>{item.supplier}</TableCell>
                    <TableCell>{item.targetcostcr.toFixed(2)}</TableCell>
                    <TableCell>{item.actualcostcr.toFixed(2)}</TableCell>
                    <TableCell className={variance < 0 ? 'text-red-500 font-medium' : 'text-emerald-500 font-medium'}>
                      {variance.toFixed(2)}
                    </TableCell>
                    <TableCell>{item.dateoforder}</TableCell>
                    <TableCell>
                      {hasHistory ? (
                        <DateChangePopover logs={deliveryLogs}>
                          <div className="flex items-center gap-1.5 text-amber-600 font-medium cursor-pointer hover:underline">
                            {item.dateofdelivery}
                            <AlertTriangle className="size-3.5 text-amber-500" />
                          </div>
                        </DateChangePopover>
                      ) : (
                        item.dateofdelivery
                      )}
                    </TableCell>
                    <TableCell>{getOwnerName(item.ownerorgnodeid)}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{item.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-muted" onClick={() => openEditDialog(item.supplychainreadinessid)}>
                          <Pencil className="size-4 text-muted-foreground" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/10" onClick={() => setDeleteTarget(item.supplychainreadinessid)}>
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
            {items.length > 0 && (
              <TableRow className="bg-muted/50 font-bold border-t-2">
                <TableCell colSpan={2}>Total Supply Chain</TableCell>
                <TableCell>{totalTarget.toFixed(2)}</TableCell>
                <TableCell>{totalActual.toFixed(2)}</TableCell>
                <TableCell className={totalVariance < 0 ? 'text-red-500 font-medium' : 'text-emerald-500 font-medium'}>
                  {totalVariance.toFixed(2)}
                </TableCell>
                <TableCell colSpan={4}></TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Supply Item" : "Add Supply Item"}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4 px-1">
            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Item Name</Label>
                <Input {...register("item")} />
                {errors.item && <FieldError>{errors.item.message}</FieldError>}
              </Field>
              <Field>
                <Label>Supplier</Label>
                <Input {...register("supplier")} />
                {errors.supplier && <FieldError>{errors.supplier.message}</FieldError>}
              </Field>
            </div>

            <div className="grid grid-cols-3 gap-4 p-4 border rounded-lg bg-muted/20">
              <Field>
                <Label>Target Cost (CR)</Label>
                <Input type="number" step="0.01" {...register("targetcostcr")} />
                {errors.targetcostcr && <FieldError>{errors.targetcostcr.message}</FieldError>}
              </Field>
              <Field>
                <Label>Actual Cost (CR)</Label>
                <Input type="number" step="0.01" {...register("actualcostcr")} />
                {errors.actualcostcr && <FieldError>{errors.actualcostcr.message}</FieldError>}
              </Field>
              <Field>
                <Label className="text-muted-foreground">Variance (Auto-calc)</Label>
                <div className={`mt-2 font-mono text-lg ${currentVariance < 0 ? 'text-red-500' : 'text-emerald-500'}`}>
                  {currentVariance.toFixed(2)}
                </div>
              </Field>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Order Date</Label>
                <Controller
                  control={control}
                  name="dateoforder"
                  render={({ field }) => <DatePicker value={field.value} onChange={field.onChange} />}
                />
                {errors.dateoforder && <FieldError>{errors.dateoforder.message}</FieldError>}
              </Field>
              <Field>
                <Label>Delivery Date</Label>
                <Controller
                  control={control}
                  name="dateofdelivery"
                  render={({ field }) => <DatePicker value={field.value} onChange={field.onChange} />}
                />
                {errors.dateofdelivery && <FieldError>{errors.dateofdelivery.message}</FieldError>}
              </Field>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <Field>
                <Label>Lead Time</Label>
                <Input {...register("leadtime")} placeholder="e.g. 4 Weeks" />
                {errors.leadtime && <FieldError>{errors.leadtime.message}</FieldError>}
              </Field>
              <Field>
                <Label>Status</Label>
                <Controller
                  control={control}
                  name="status"
                  render={({ field }) => (
                    <Combobox value={field.value} onValueChange={field.onChange} items={STATUSES}>
                      <ComboboxInput placeholder="Select status..." />
                      <ComboboxContent>
                        <ComboboxList>
                          {(s) => <ComboboxItem key={s} value={s}>{s}</ComboboxItem>}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  )}
                />
                {errors.status && <FieldError>{errors.status.message}</FieldError>}
              </Field>
              <Field>
                <Label>Owner (Org Node)</Label>
                <Controller
                  control={control}
                  name="ownerorgnodeid"
                  render={({ field }) => (
                    <Combobox value={field.value} onValueChange={field.onChange} items={orgNodes.map((n) => n.programmeorgnodeid)}>
                      <ComboboxInput placeholder="Select owner..." />
                      <ComboboxContent>
                        <ComboboxList>
                          {(id) => {
                            const n = orgNodes.find((x) => x.programmeorgnodeid === id);
                            return <ComboboxItem key={id} value={id}>{n?.displayname}</ComboboxItem>;
                          }}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  )}
                />
                {errors.ownerorgnodeid && <FieldError>{errors.ownerorgnodeid.message}</FieldError>}
              </Field>
            </div>

            <Field>
              <Label>Risk / Remarks (Optional)</Label>
              <Textarea {...register("riskremarks")} rows={2} />
            </Field>

            <DialogFooter className="mt-6">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={isSaving}>Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={showReasonDialog} onOpenChange={(open) => !open && setShowReasonDialog(false)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Date Change Justification</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {pendingDateChangeData?.changes.map((c, i) => (
              <div key={i} className="text-sm p-3 bg-muted/40 rounded-md border">
                <strong>{c.field}:</strong> <span className="line-through">{c.oldDate}</span> {" -> "} 
                <span className="font-semibold text-primary">{c.newDate}</span>
              </div>
            ))}
            <div className="space-y-2">
              <Label>Reason</Label>
              <Textarea value={dateChangeReason} onChange={(e) => setDateChangeReason(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReasonDialog(false)}>Cancel</Button>
            <Button onClick={confirmDateChange} disabled={isSaving || dateChangeReason.trim().length < 5}>Confirm Change</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Supply Item?</AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button variant="destructive" onClick={confirmDelete} disabled={isDeleting}>Delete</Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
