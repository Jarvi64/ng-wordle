import { useMemo } from "react";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  CircleDot,
  Clock,
  DollarSign,
  Flag,
  Package,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { differenceInDays } from "date-fns";

// ── Helpers ──────────────────────────────────────────────────────
function safeParse(ds: string | undefined): Date | null {
  if (!ds) return null;
  try {
    const d = new Date(ds.includes("T") ? ds : ds + "T00:00:00");
    return isNaN(d.getTime()) ? null : d;
  } catch {
    return null;
  }
}

// ── Colour maps ──────────────────────────────────────────────────
const MS_COLOR: Record<string, string> = {
  "Not Started": "#94a3b8",
  "In Progress": "#0874B0",
  "Completed":   "#10b981",
  "Delayed":     "#f59e0b",
  "At Risk":     "#ef4444",
};

const MS_BADGE: Record<string, string> = {
  "Not Started": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
  "Completed":   "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  "Delayed":     "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  "At Risk":     "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
};

const CRIT_ORDER: Record<string, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };
const CRIT_BADGE: Record<string, string> = {
  Critical: "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
  High:     "bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300",
  Medium:   "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  Low:      "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
};

// ── Sub-components ────────────────────────────────────────────────
function KpiCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  accent: string;
}) {
  return (
    <Card className="relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{ background: `radial-gradient(circle at top right, ${accent}, transparent 65%)` }}
      />
      <CardContent className="pt-3 pb-3 px-4">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">{label}</span>
          <div className="size-7 rounded-lg flex items-center justify-center" style={{ background: `${accent}22` }}>
            <Icon className="size-3.5" style={{ color: accent }} />
          </div>
        </div>
        <div className="text-2xl font-bold tracking-tight">{value}</div>
        {sub && <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>}
      </CardContent>
    </Card>
  );
}

function SectionHeader({
  icon: Icon,
  title,
  count,
  accent,
}: {
  icon: React.ElementType;
  title: string;
  count?: number;
  accent?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="size-4" style={{ color: accent ?? "currentColor" }} />
      <span className="font-semibold text-sm">{title}</span>
      {count !== undefined && (
        <Badge className="ml-auto tabular-nums text-[10px] px-1.5 py-0 bg-muted text-muted-foreground">
          {count}
        </Badge>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────
export function ProgrammeDashboardTab({ programmeId }: { programmeId: string }) {
  const {
    milestones,
    certifications,
    supportRequired,
    dateChangeLogs,
    manpowerPlans,
    capexBudgets,
    opexBudgets,
    supplyChains,
    partnerDeliverables,
    programmeOrgNodes,
    weeklyUpdates,
    weeklyUpdateItems,
  } = useAppStore();

  const today = new Date();
  const thirtyDays = new Date(today.getTime() + 30 * 86400000);
  const sevenDaysAgo = new Date(today.getTime() - 7 * 86400000);

  // ── Scoped data ─────────────────────────────────────────────
  const pMilestones     = milestones.filter((m) => m.programmeid === programmeId);
  const pCerts          = certifications.filter((c) => c.programmeid === programmeId);
  const pSupport        = supportRequired.filter((s) => s.programmeid === programmeId);
  const pLogs           = dateChangeLogs.filter((l) => l.programmeid === programmeId);
  const pManpower       = manpowerPlans.filter((m) => m.programmeid === programmeId);
  const pCapex          = capexBudgets.filter((c) => c.programmeid === programmeId);
  const pOpex           = opexBudgets.filter((o) => o.programmeid === programmeId);
  const pSC             = supplyChains.filter((s) => s.programmeid === programmeId);
  const pPartner        = partnerDeliverables.filter((d) => d.programmeid === programmeId);
  const orgNodes        = programmeOrgNodes.filter((n) => n.programmeid === programmeId && n.active === "Yes");

  const ownerName = (id: string) => orgNodes.find((n) => n.programmeorgnodeid === id)?.displayname ?? "—";

  // ── Milestone stats ──────────────────────────────────────────
  const msCompleted  = pMilestones.filter((m) => m.status === "Completed").length;
  const msAtRisk     = pMilestones.filter((m) => m.status === "At Risk" || m.status === "Delayed");
  const msCompletion = pMilestones.length > 0 ? Math.round((msCompleted / pMilestones.length) * 100) : 0;

  const msByStatus = useMemo(() => {
    const counts: Record<string, number> = {};
    pMilestones.forEach((m) => { counts[m.status] = (counts[m.status] ?? 0) + 1; });
    return counts;
  }, [pMilestones]);

  // ── Upcoming milestones + certs (next 30 days) ───────────────
  const upcomingDeadlines = useMemo(() => {
    const items: { label: string; date: Date; daysLeft: number; type: string; status: string; badge: string }[] = [];
    pMilestones.forEach((m) => {
      if (m.status === "Completed") return;
      const d = safeParse(m.targetedcompletiondate);
      if (d && d >= today && d <= thirtyDays) {
        items.push({ label: m.name, date: d, daysLeft: differenceInDays(d, today), type: "Milestone", status: m.status, badge: MS_BADGE[m.status] ?? "" });
      }
    });
    pCerts.forEach((c) => {
      if (c.status === "Approved" || c.status === "Expired") return;
      const d = safeParse(c.validitydate);
      if (d && d >= today && d <= thirtyDays) {
        items.push({ label: c.name, date: d, daysLeft: differenceInDays(d, today), type: "Certification", status: c.status, badge: "" });
      }
    });
    return items.sort((a, b) => a.daysLeft - b.daysLeft);
  }, [pMilestones, pCerts]);

  // ── Support ──────────────────────────────────────────────────
  const openSupport = pSupport
    .filter((s) => s.status !== "Closed" && s.status !== "Resolved")
    .sort((a, b) => (CRIT_ORDER[a.criticality] ?? 3) - (CRIT_ORDER[b.criticality] ?? 3));

  // ── Budget ───────────────────────────────────────────────────
  const totalCapexBudget = pCapex.reduce((a, c) => a + c.budgetcr, 0);
  const totalCapexActual = pCapex.reduce((a, c) => a + c.actualcr, 0);
  const capexVariance    = totalCapexBudget - totalCapexActual;
  const totalOpexTarget  = pOpex.reduce((a, o) => a + o.targetcostcr, 0);
  const totalOpexUnit    = pOpex.reduce((a, o) => a + o.unitcostcr, 0);

  // ── Hiring ──────────────────────────────────────────────────
  const hiringGap    = pManpower.reduce((a, p) => a + Math.max(0, p.requiredqty - p.filledqty), 0);
  const hiringTotal  = pManpower.reduce((a, p) => a + p.requiredqty, 0);
  const hiringFilled = hiringTotal - hiringGap;

  // ── Supply chain ─────────────────────────────────────────────
  const scDelayed   = pSC.filter((s) => s.status === "Delayed").length;
  const scDelivered = pSC.filter((s) => s.status === "Delivered").length;

  // ── Recent date changes ──────────────────────────────────────
  const recentChanges = pLogs
    .filter((l) => new Date(l.changedon) >= sevenDaysAgo)
    .sort((a, b) => new Date(b.changedon).getTime() - new Date(a.changedon).getTime());

  // ── Latest weekly update ─────────────────────────────────────
  const latestUpdate = weeklyUpdates
    .filter((u) => u.programmeid === programmeId)
    .sort((a, b) => b.weekkey.localeCompare(a.weekkey))[0];

  const latestUpdateItems = latestUpdate
    ? weeklyUpdateItems.filter((i) => i.weeklyupdateid === latestUpdate.weeklyupdateid)
    : [];

  const positiveItems = latestUpdateItems.filter((i) => i.entrytype === "positive");
  const negativeItems = latestUpdateItems.filter((i) => i.entrytype === "negative");

  return (
    <div className="space-y-5">

      {/* ── KPI Strip ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard icon={Flag}        label="Milestones"      value={`${msCompletion}%`}    sub={`${msCompleted}/${pMilestones.length} completed`}   accent="#0874B0" />
        <KpiCard icon={AlertTriangle} label="At Risk"        value={msAtRisk.length}       sub={msAtRisk.length > 0 ? "Needs attention" : "All clear"} accent={msAtRisk.length > 0 ? "#ef4444" : "#10b981"} />
        <KpiCard icon={Zap}         label="Open Support"    value={openSupport.length}    sub={`${openSupport.filter(s => s.criticality === "Critical").length} critical`} accent={openSupport.filter(s => s.criticality === "Critical").length > 0 ? "#BD3661" : "#75679C"} />
        <KpiCard icon={ShieldCheck} label="Certifications"  value={`${pCerts.filter(c => c.status === "Approved").length}/${pCerts.length}`} sub="Approved / Total" accent="#75679C" />
        <KpiCard icon={Users}       label="Hiring Gap"      value={hiringGap}             sub={`${hiringFilled}/${hiringTotal} filled`}             accent={hiringGap > 0 ? "#f59e0b" : "#10b981"} />
        <KpiCard icon={Clock}       label="Date Changes"    value={recentChanges.length}  sub="In last 7 days"                                     accent={recentChanges.length > 0 ? "#75679C" : "#94a3b8"} />
      </div>

      {/* ── Row 2: Milestones + Upcoming ── */}
      <div className="grid gap-4 lg:grid-cols-3">

        {/* Milestone breakdown */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={Flag} title="Milestone Status" accent="#0874B0" count={pMilestones.length} />
          </CardHeader>
          <CardContent className="pb-4 space-y-2.5">
            {Object.entries(MS_COLOR).map(([status, color]) => {
              const count = msByStatus[status] ?? 0;
              const pct = pMilestones.length > 0 ? (count / pMilestones.length) * 100 : 0;
              return (
                <div key={status} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-20 shrink-0">{status}</span>
                  <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
                  </div>
                  <span className="text-xs font-semibold w-4 text-right">{count}</span>
                </div>
              );
            })}
            {/* Overall progress */}
            <div className="pt-2 border-t">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-muted-foreground">Overall completion</span>
                <span className="font-bold">{msCompletion}%</span>
              </div>
              <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${msCompletion}%` }} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming deadlines */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={CalendarDays} title="Upcoming in 30 Days" accent="#0874B0" count={upcomingDeadlines.length} />
          </CardHeader>
          <CardContent className="pb-2">
            {upcomingDeadlines.length === 0 ? (
              <div className="flex flex-col items-center py-6 text-muted-foreground gap-2">
                <CheckCircle2 className="size-8 opacity-25" />
                <p className="text-sm">No deadlines in the next 30 days</p>
              </div>
            ) : (
              <ScrollArea className="max-h-48">
                <div className="space-y-1.5 pr-1">
                  {upcomingDeadlines.map((item, i) => (
                    <div key={i} className="flex items-center gap-3 px-2.5 py-2 rounded-lg hover:bg-muted/40 transition-colors">
                      <div className={`size-1.5 rounded-full shrink-0 ${item.type === "Milestone" ? "bg-blue-500" : "bg-indigo-500"}`} />
                      <span className="text-xs text-muted-foreground w-20 shrink-0">{item.type}</span>
                      <span className="text-sm flex-1 truncate font-medium">{item.label}</span>
                      <span className={`text-xs font-bold shrink-0 ${item.daysLeft <= 7 ? "text-amber-600" : "text-muted-foreground"}`}>
                        {item.daysLeft === 0 ? "Today!" : `${item.daysLeft}d`}
                      </span>
                      {item.badge && <Badge className={`${item.badge} text-[9px] shrink-0`}>{item.status}</Badge>}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Row 3: At Risk + Support ── */}
      <div className="grid gap-4 lg:grid-cols-2">

        {/* At Risk Milestones */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={AlertTriangle} title="At Risk & Delayed Milestones" accent="#ef4444" count={msAtRisk.length} />
          </CardHeader>
          <CardContent className="pb-3">
            {msAtRisk.length === 0 ? (
              <div className="flex flex-col items-center py-5 text-muted-foreground gap-2">
                <CheckCircle2 className="size-7 opacity-25" />
                <p className="text-sm">All milestones are on track</p>
              </div>
            ) : (
              <ScrollArea className="max-h-52">
                <div className="space-y-1.5 pr-1">
                  {msAtRisk.map((m) => {
                    const d = safeParse(m.targetedcompletiondate);
                    const daysLeft = d ? differenceInDays(d, today) : null;
                    const delayed = m.targetedcompletiondate !== m.originaltargetedcompletiondate;
                    return (
                      <div key={m.milestoneid} className="flex items-center gap-3 px-2.5 py-2 rounded-lg bg-muted/30 border hover:bg-muted/50 transition-colors">
                        <CircleDot className="size-3.5 shrink-0" style={{ color: MS_COLOR[m.status] }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold truncate">{m.name}</p>
                          <p className="text-[10px] text-muted-foreground">{ownerName(m.ownerorgnodeid)}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <Badge className={`${MS_BADGE[m.status] ?? ""} text-[9px]`}>{m.status}</Badge>
                          {daysLeft !== null && (
                            <p className={`text-[10px] mt-0.5 font-medium ${daysLeft < 0 ? "text-red-500" : "text-muted-foreground"}`}>
                              {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d left`}
                            </p>
                          )}
                          {delayed && <p className="text-[9px] text-amber-500">⚠ date shifted</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Support required */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={Zap} title="Open Support Items" accent="#BD3661" count={openSupport.length} />
          </CardHeader>
          <CardContent className="pb-3">
            {openSupport.length === 0 ? (
              <div className="flex flex-col items-center py-5 text-muted-foreground gap-2">
                <CheckCircle2 className="size-7 opacity-25" />
                <p className="text-sm">No open support items</p>
              </div>
            ) : (
              <ScrollArea className="max-h-52">
                <div className="space-y-1.5 pr-1">
                  {openSupport.map((s) => {
                    const d = safeParse(s.deadline);
                    const daysLeft = d ? differenceInDays(d, today) : null;
                    return (
                      <div key={s.supportrequiredid} className="flex items-start gap-2.5 px-2.5 py-2 rounded-lg bg-muted/30 border hover:bg-muted/50 transition-colors">
                        <AlertTriangle className="size-3.5 mt-0.5 shrink-0 text-amber-500" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium leading-snug line-clamp-2">{s.supporttext}</p>
                          <p className="text-[10px] text-muted-foreground mt-0.5">{s.category} · {ownerName(s.ownerorgnodeid)}</p>
                        </div>
                        <div className="shrink-0 text-right">
                          <Badge className={`${CRIT_BADGE[s.criticality] ?? ""} text-[9px]`}>{s.criticality}</Badge>
                          {daysLeft !== null && (
                            <p className={`text-[10px] mt-0.5 ${daysLeft < 0 ? "text-red-500" : "text-muted-foreground"}`}>
                              {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d`}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Row 4: Budget + Supply Chain + Hiring ── */}
      <div className="grid gap-4 lg:grid-cols-3">

        {/* CAPEX/OPEX */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={DollarSign} title="Budget Summary" accent="#10b981" />
          </CardHeader>
          <CardContent className="pb-4 space-y-3">
            <div className="rounded-lg bg-muted/40 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground font-medium">CAPEX Budget</span>
                <span className="font-bold">{totalCapexBudget.toFixed(1)} CR</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground font-medium">CAPEX Actual</span>
                <span className="font-bold">{totalCapexActual.toFixed(1)} CR</span>
              </div>
              <div className="h-px bg-border" />
              <div className={`flex items-center justify-between text-xs font-bold ${capexVariance >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                <div className="flex items-center gap-1">
                  {capexVariance >= 0 ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
                  CAPEX Variance
                </div>
                <span>{capexVariance >= 0 ? "+" : ""}{capexVariance.toFixed(2)} CR</span>
              </div>
            </div>
            {pOpex.length > 0 && (
              <div className="rounded-lg bg-muted/40 p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground font-medium">OPEX Target</span>
                  <span className="font-bold">{totalOpexTarget.toFixed(1)} CR</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground font-medium">OPEX Unit Cost</span>
                  <span className="font-bold">{totalOpexUnit.toFixed(1)} CR</span>
                </div>
              </div>
            )}
            {totalCapexBudget === 0 && pOpex.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">No budget data yet</p>
            )}
          </CardContent>
        </Card>

        {/* Supply chain */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={Package} title="Supply Chain" accent="#0874B0" count={pSC.length}>
            </SectionHeader>
          </CardHeader>
          <CardContent className="pb-3">
            {pSC.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No supply chain items</p>
            ) : (
              <>
                {/* Quick summary */}
                <div className="grid grid-cols-3 gap-2 mb-3">
                  {[
                    { label: "Delivered", count: scDelivered, color: "#10b981" },
                    { label: "Delayed",   count: scDelayed,   color: "#ef4444" },
                    { label: "Other",     count: pSC.length - scDelivered - scDelayed, color: "#94a3b8" },
                  ].map((s) => (
                    <div key={s.label} className="rounded-lg bg-muted/40 p-2 text-center">
                      <div className="text-lg font-bold" style={{ color: s.color }}>{s.count}</div>
                      <div className="text-[10px] text-muted-foreground">{s.label}</div>
                    </div>
                  ))}
                </div>
                <ScrollArea className="max-h-32">
                  <div className="space-y-1 pr-1">
                    {pSC.map((sc) => (
                      <div key={sc.supplychainreadinessid} className="flex items-center gap-2.5 text-xs">
                        <div className={`size-1.5 rounded-full shrink-0 ${sc.status === "Delivered" ? "bg-emerald-500" : sc.status === "Delayed" ? "bg-red-500" : "bg-slate-400"}`} />
                        <span className="flex-1 truncate">{sc.item}</span>
                        <span className="text-muted-foreground truncate max-w-20">{sc.supplier}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </>
            )}
          </CardContent>
        </Card>

        {/* Hiring */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={Users} title="Manpower & Hiring" accent="#75679C" />
          </CardHeader>
          <CardContent className="pb-4">
            {pManpower.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No manpower plans</p>
            ) : (
              <>
                <div className="flex items-end gap-1.5 mb-3">
                  <span className="text-3xl font-bold">{hiringGap}</span>
                  <span className="text-xs text-muted-foreground mb-1">open positions of {hiringTotal}</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden mb-3">
                  <div className="h-full rounded-full bg-violet-500" style={{ width: `${hiringTotal > 0 ? (hiringFilled / hiringTotal) * 100 : 0}%` }} />
                </div>
                <ScrollArea className="max-h-28">
                  <div className="space-y-2 pr-1">
                    {pManpower.map((p) => {
                      const pct = p.requiredqty > 0 ? Math.round((p.filledqty / p.requiredqty) * 100) : 100;
                      return (
                        <div key={p.manpowergaphiringplansid}>
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="text-xs font-medium truncate max-w-[140px]">{p.role}</span>
                            <span className="text-[10px] text-muted-foreground">{p.filledqty}/{p.requiredqty}</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                            <div className="h-full rounded-full bg-violet-500" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Row 5: Partner deliverables + Certifications + Recent changes ── */}
      <div className="grid gap-4 lg:grid-cols-3">

        {/* Partner deliverables at risk */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={BarChart3} title="Partner Deliverables" accent="#f59e0b" count={pPartner.length} />
          </CardHeader>
          <CardContent className="pb-3">
            {pPartner.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No partner deliverables</p>
            ) : (
              <ScrollArea className="max-h-48">
                <div className="space-y-1.5 pr-1">
                  {pPartner.map((pd) => {
                    const d = safeParse(pd.currentedc);
                    const daysLeft = d ? differenceInDays(d, today) : null;
                    const isDelayed = pd.currentedc !== pd.targetedc;
                    return (
                      <div key={pd.partnerdeliverableid} className="flex items-start gap-2.5 px-2.5 py-2 rounded-lg bg-muted/30 border">
                        <div className={`size-1.5 rounded-full mt-1.5 shrink-0 ${isDelayed ? "bg-amber-500" : "bg-slate-400"}`} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium truncate">{pd.deliverable}</p>
                          <p className="text-[10px] text-muted-foreground">{pd.partnername}</p>
                        </div>
                        <div className="shrink-0 text-right">
                          {daysLeft !== null && (
                            <p className={`text-[10px] font-semibold ${daysLeft < 0 ? "text-red-500" : daysLeft <= 14 ? "text-amber-600" : "text-muted-foreground"}`}>
                              {daysLeft < 0 ? `${Math.abs(daysLeft)}d late` : `${daysLeft}d`}
                            </p>
                          )}
                          {isDelayed && <p className="text-[9px] text-amber-500">shifted</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Certifications */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={ShieldCheck} title="Certifications" accent="#75679C" count={pCerts.length} />
          </CardHeader>
          <CardContent className="pb-3">
            {pCerts.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No certifications tracked</p>
            ) : (
              <ScrollArea className="max-h-48">
                <div className="space-y-1.5 pr-1">
                  {pCerts.map((c) => {
                    const d = safeParse(c.validitydate);
                    const daysLeft = d ? differenceInDays(d, today) : null;
                    const isExpiring = daysLeft !== null && daysLeft >= 0 && daysLeft <= 30;
                    return (
                      <div key={c.certificationid} className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg bg-muted/30 border">
                        <div className={`size-1.5 rounded-full shrink-0 ${c.status === "Approved" ? "bg-emerald-500" : c.status === "Expired" ? "bg-red-500" : c.status === "In Review" ? "bg-indigo-500" : "bg-slate-400"}`} />
                        <span className="text-xs flex-1 truncate font-medium">{c.name}</span>
                        {isExpiring && (
                          <span className="text-[10px] text-amber-600 font-semibold shrink-0">{daysLeft}d</span>
                        )}
                        <Badge className={`text-[9px] shrink-0 ${c.status === "Approved" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300" : c.status === "Expired" ? "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300" : "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300"}`}>
                          {c.status}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Recent date changes */}
        <Card>
          <CardHeader className="pb-2 pt-4">
            <SectionHeader icon={Clock} title="Recent Date Changes" accent="#75679C" count={recentChanges.length} />
          </CardHeader>
          <CardContent className="pb-3">
            {recentChanges.length === 0 ? (
              <div className="flex flex-col items-center py-5 text-muted-foreground gap-2">
                <CheckCircle2 className="size-7 opacity-25" />
                <p className="text-sm">No changes in 7 days</p>
              </div>
            ) : (
              <ScrollArea className="max-h-48">
                <div className="space-y-1.5 pr-1">
                  {recentChanges.map((log) => (
                    <div key={log.datechangelogid} className="px-2.5 py-2 rounded-lg bg-amber-50/60 dark:bg-amber-950/10 border border-amber-200/60 dark:border-amber-800/20">
                      <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-0.5">
                        <span className="capitalize font-medium text-foreground">{log.module.replace("_", " ")}</span>
                        <span>·</span>
                        <span>{log.fieldname}</span>
                      </div>
                      <p className="text-xs font-semibold truncate">{log.recordname}</p>
                      <div className="flex items-center gap-1.5 mt-0.5 text-[10px]">
                        <span className="line-through text-muted-foreground">{log.olddate}</span>
                        <ArrowRight className="size-2.5 text-muted-foreground" />
                        <span className="font-semibold">{log.newdate}</span>
                      </div>
                      {log.reason && (
                        <p className="text-[10px] text-muted-foreground italic truncate mt-0.5">"{log.reason}"</p>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Latest Weekly Update ── */}
      {latestUpdate && (
        <Card>
          <CardHeader className="pb-2 pt-4">
            <div className="flex items-center gap-2">
              <SectionHeader icon={BarChart3} title={`Latest Weekly Update — ${latestUpdate.weekkey}`} accent="#0874B0" />
              <Badge className="ml-auto text-[10px]" variant="secondary">{latestUpdate.status}</Badge>
            </div>
          </CardHeader>
          <CardContent className="pb-4">
            {latestUpdateItems.length === 0 ? (
              <p className="text-xs text-muted-foreground">No items in this update.</p>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                {positiveItems.length > 0 && (
                  <div>
                    <p className="text-[10px] font-semibold text-emerald-600 uppercase tracking-wider mb-1.5">Positives</p>
                    <div className="space-y-1">
                      {positiveItems.map((item) => (
                        <div key={item.weeklyupdateitemid} className="flex items-start gap-2 text-xs">
                          <span className="text-emerald-500 mt-0.5 shrink-0">✓</span>
                          <span>{item.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {negativeItems.length > 0 && (
                  <div>
                    <p className="text-[10px] font-semibold text-red-600 uppercase tracking-wider mb-1.5">Concerns</p>
                    <div className="space-y-1">
                      {negativeItems.map((item) => (
                        <div key={item.weeklyupdateitemid} className="flex items-start gap-2 text-xs">
                          <span className="text-red-500 mt-0.5 shrink-0">✗</span>
                          <span>{item.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
