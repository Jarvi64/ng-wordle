import { useState } from "react";
import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { Badge } from "@/components/ui/badge";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

const schema = z.object({
  name: z.string().min(2, "Name is required"),
  notes: z.string().optional(),
  lastreportingweek: z.string().min(1, "Week code is required"),
  poc1userid: z.string().min(1, "POC 1 is required"),
  poc2userid: z.string().optional(),
  businessid: z.string().min(1, "Business Unit is required"),
});

type FormData = z.infer<typeof schema>;

export function ProgrammeMaster() {
  const {
    programmes,
    businessUnits,
    users,
    addProgramme,
    updateProgramme,
    deleteProgramme,
  } = useAppStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const businessUnitNames = businessUnits.map((b) => b.name);
  const userNames = users.map((u) => u.name);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const openAddDialog = () => {
    reset({
      name: "",
      notes: "",
      lastreportingweek: "",
      poc1userid: "",
      poc2userid: "",
      businessid: "",
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = programmes.find((b) => b.programmeid === id);
    if (item) {
      reset({ ...item });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    const finalData = {
      ...data,
      poc2userid: data.poc2userid || "",
      notes: data.notes || "",
    };
    setIsSaving(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      if (editingId) {
        updateProgramme(editingId, finalData);
        toast.success("Programme updated successfully");
      } else {
        addProgramme(finalData);
        toast.success("Programme added successfully");
      }
      setIsDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      deleteProgramme(deleteTarget);
      toast.success("Programme deleted successfully");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete programme");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-foreground">
            Programmes
          </h2>
          <p className="text-muted-foreground mt-1">
            Manage individual tracking programmes.
          </p>
        </div>

        <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddDialog}>
              <Plus data-icon="inline-start" />
              Add Programme
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Edit Programme" : "Add Programme"}
              </DialogTitle>
              <DialogDescription className="sr-only">
                Make changes to your programme data here.
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="max-h-[70vh] pr-4 pb-4">
              <form onSubmit={handleSubmit(onSubmit)}>
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field
                      className="col-span-2 md:col-span-1"
                      data-invalid={!!errors.name || undefined}
                    >
                      <Label htmlFor="prog-name">Programme Name</Label>
                      <Input
                        id="prog-name"
                        {...register("name")}
                        placeholder="e.g., Project Zephyr"
                        aria-invalid={!!errors.name || undefined}
                      />
                      {errors.name && (
                        <FieldError>{errors.name.message}</FieldError>
                      )}
                    </Field>

                    <Field
                      className="col-span-2 md:col-span-1"
                      data-invalid={!!errors.lastreportingweek || undefined}
                    >
                      <Label htmlFor="prog-week">Reporting Week</Label>
                      <Input
                        id="prog-week"
                        {...register("lastreportingweek")}
                        placeholder="e.g., 2026-W14"
                        aria-invalid={!!errors.lastreportingweek || undefined}
                      />
                      {errors.lastreportingweek && (
                        <FieldError>
                          {errors.lastreportingweek.message}
                        </FieldError>
                      )}
                    </Field>

                    <Field
                      className="col-span-2"
                      data-invalid={!!errors.businessid || undefined}
                    >
                      <Label>Business Unit</Label>
                      <Controller
                        control={control}
                        name="businessid"
                        render={({ field }) => {
                          const selectedName =
                            businessUnits.find(
                              (b) => b.businessunitid === field.value,
                            )?.name ?? null;
                          return (
                            <Combobox
                              value={selectedName}
                              onValueChange={(name: string | null) => {
                                const bu = businessUnits.find(
                                  (b) => b.name === name,
                                );
                                field.onChange(bu?.businessunitid ?? "");
                              }}
                              items={businessUnitNames}
                            >
                              <ComboboxInput placeholder="Select a business unit" />
                              <ComboboxContent>
                                <ComboboxEmpty>
                                  No business units found.
                                </ComboboxEmpty>
                                <ComboboxList>
                                  {(name: string) => (
                                    <ComboboxItem key={name} value={name}>
                                      {name}
                                    </ComboboxItem>
                                  )}
                                </ComboboxList>
                              </ComboboxContent>
                            </Combobox>
                          );
                        }}
                      />
                      {errors.businessid && (
                        <FieldError>{errors.businessid.message}</FieldError>
                      )}
                    </Field>

                    <Field
                      className="col-span-2 md:col-span-1"
                      data-invalid={!!errors.poc1userid || undefined}
                    >
                      <Label>Primary POC</Label>
                      <Controller
                        control={control}
                        name="poc1userid"
                        render={({ field }) => {
                          const selectedName =
                            users.find((u) => u.userid === field.value)?.name ??
                            null;
                          return (
                            <Combobox
                              value={selectedName}
                              onValueChange={(name: string | null) => {
                                const user = users.find(
                                  (u) => u.name === name,
                                );
                                field.onChange(user?.userid ?? "");
                              }}
                              items={userNames}
                            >
                              <ComboboxInput placeholder="Select POC 1" />
                              <ComboboxContent>
                                <ComboboxEmpty>No users found.</ComboboxEmpty>
                                <ComboboxList>
                                  {(name: string) => (
                                    <ComboboxItem key={name} value={name}>
                                      {name}
                                    </ComboboxItem>
                                  )}
                                </ComboboxList>
                              </ComboboxContent>
                            </Combobox>
                          );
                        }}
                      />
                      {errors.poc1userid && (
                        <FieldError>{errors.poc1userid.message}</FieldError>
                      )}
                    </Field>

                    <Field className="col-span-2 md:col-span-1">
                      <Label>Secondary POC (Optional)</Label>
                      <Controller
                        control={control}
                        name="poc2userid"
                        render={({ field }) => {
                          const selectedName =
                            users.find((u) => u.userid === field.value)?.name ??
                            null;
                          return (
                            <Combobox
                              value={selectedName}
                              onValueChange={(name: string | null) => {
                                if (!name) {
                                  field.onChange("");
                                  return;
                                }
                                const user = users.find(
                                  (u) => u.name === name,
                                );
                                field.onChange(user?.userid ?? "");
                              }}
                              items={userNames}
                            >
                              <ComboboxInput
                                placeholder="Select POC 2"
                                showClear
                              />
                              <ComboboxContent>
                                <ComboboxEmpty>No users found.</ComboboxEmpty>
                                <ComboboxList>
                                  {(name: string) => (
                                    <ComboboxItem key={name} value={name}>
                                      {name}
                                    </ComboboxItem>
                                  )}
                                </ComboboxList>
                              </ComboboxContent>
                            </Combobox>
                          );
                        }}
                      />
                    </Field>

                    <Field className="col-span-2">
                      <Label htmlFor="prog-notes">Notes</Label>
                      <Textarea
                        id="prog-notes"
                        {...register("notes")}
                        placeholder="Any context or updates..."
                        className="min-h-[100px]"
                      />
                    </Field>
                  </div>
                </FieldGroup>

                <DialogFooter className="mt-6">
                  <DialogClose asChild>
                    <Button type="button" variant="outline" disabled={isSaving}>
                      Cancel
                    </Button>
                  </DialogClose>
                  <Button type="submit" disabled={isSaving}>
                    {isSaving && <Spinner data-icon="inline-start" />}
                    Save
                  </Button>
                </DialogFooter>
              </form>
            </ScrollArea>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Programme</TableHead>
              <TableHead>Business Unit</TableHead>
              <TableHead>Primary POC</TableHead>
              <TableHead>Last Week</TableHead>
              <TableHead className="w-[120px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {programmes.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="h-24 text-center text-muted-foreground"
                >
                  No programmes found.
                </TableCell>
              </TableRow>
            ) : (
              programmes.map((item) => {
                const buName =
                  businessUnits.find(
                    (b) => b.businessunitid === item.businessid,
                  )?.name || "Unknown";
                const poc1Name =
                  users.find((u) => u.userid === item.poc1userid)?.name ||
                  "Unknown";
                return (
                  <TableRow key={item.programmeid}>
                    <TableCell className="font-medium text-foreground">
                      <Link
                        to={`/programmes/${item.programmeid}`}
                        className="hover:underline hover:text-primary transition-colors"
                      >
                        {item.name}
                      </Link>
                    </TableCell>
                    <TableCell>{buName}</TableCell>
                    <TableCell>{poc1Name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {item.lastreportingweek}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right flex items-center justify-end gap-2 text-muted-foreground">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(item.programmeid)}
                      >
                        <Pencil />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => setDeleteTarget(item.programmeid)}
                      >
                        <Trash2 />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Controlled delete confirmation dialog */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this programme. This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
