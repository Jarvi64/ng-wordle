import { useState } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useAppStore } from "@/lib/store";
import {
  CalendarDays,
  ChevronRight,
  DollarSign,
  Flag,
  GitFork,
  History,
  LayoutGrid,
  Package,
  RefreshCw,
  ShieldCheck,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { NoiseBackground } from "@/components/ui/noise-background";
import { FloatingDock } from "@/components/ui/floating-dock";

import { WeeklyUpdatesTab } from "./programme/WeeklyUpdatesTab";
import { OrganisationTab } from "./programme/OrganisationTab";
import { MilestonesTab } from "./programme/MilestonesTab";
import { SupportRequiredTab } from "./programme/SupportRequiredTab";
import { DateChangeLogsTab } from "./programme/DateChangeLogsTab";
import { PartnerDeliverablesTab } from "./programme/PartnerDeliverablesTab";
import { BudgetTab } from "./programme/BudgetTab";
import { CertificationsTab } from "./programme/CertificationsTab";
import { SupplyChainReadinessTab } from "./programme/SupplyChainReadinessTab";
import { ProgrammeDashboardTab } from "./programme/ProgrammeDashboardTab";
import { FinancialSnapshotTab } from "./programme/FinancialSnapshotTab";
import { printProgrammeReport } from "@/lib/printReport";

// ── Avatar chip ──────────────────────────────────────────────
function PocChip({ label, name }: { label: string; name: string }) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
  return (
    <div className="flex items-center gap-2">
      <div className="size-7 rounded-full bg-primary/15 text-primary flex items-center justify-center text-[11px] font-bold shrink-0 ring-1 ring-primary/25">
        {initials}
      </div>
      <div className="leading-tight">
        <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">{label}</p>
        <p className="text-sm font-semibold text-foreground">{name}</p>
      </div>
    </div>
  );
}

// Map date-change module names → tab values
const MODULE_TAB_MAP: Record<string, string> = {
  milestone:           "milestones",
  support_required:    "support",
  partner_deliverable: "partner",
  capex:               "budget",
  opex:                "budget",
  certification:       "certifications",
  supply_chain:        "supplychain",
};

function AnimatedTabContent({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15, scale: 0.985 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 350, damping: 30 }}
    >
      {children}
    </motion.div>
  );
}

// ── Tab definitions ──────────────────────────────────────────
const TAB_DEFS = [
  { value: "overview",       label: "Overview",        icon: LayoutGrid },
  { value: "weekly",         label: "Weekly Updates",   icon: RefreshCw },
  { value: "organisation",   label: "Org Chart",        icon: GitFork },
  { value: "milestones",     label: "Milestones",       icon: Flag },
  { value: "partner",        label: "Partner & ToT",    icon: Users },
  { value: "budget",         label: "Budget",           icon: DollarSign },
  { value: "certifications", label: "Certifications",   icon: ShieldCheck },
  { value: "supplychain",    label: "Supply Chain",     icon: Package },
  { value: "support",        label: "Support",          icon: Zap },
  { value: "financial",      label: "Financial",        icon: TrendingUp },
  { value: "datechangelogs", label: "Date Logs",        icon: History },
] as const;

// ── Tab content renderer ──────────────────────────────────────
function TabPanel({ activeTab, programmeId }: { activeTab: string; programmeId: string }) {
  const panelMap: Record<string, React.ReactNode> = {
    overview:       <ProgrammeDashboardTab programmeId={programmeId} />,
    weekly:         <WeeklyUpdatesTab programmeId={programmeId} />,
    organisation:   <OrganisationTab programmeId={programmeId} />,
    milestones:     <MilestonesTab programmeId={programmeId} />,
    partner:        <PartnerDeliverablesTab programmeId={programmeId} />,
    budget:         <BudgetTab programmeId={programmeId} />,
    certifications: <CertificationsTab programmeId={programmeId} />,
    supplychain:    <SupplyChainReadinessTab programmeId={programmeId} />,
    support:        <SupportRequiredTab programmeId={programmeId} />,
    financial:      <FinancialSnapshotTab programmeId={programmeId} />,
    datechangelogs: <DateChangeLogsTab programmeId={programmeId} />,
  };

  return (
    <AnimatedTabContent key={activeTab}>
      {panelMap[activeTab] ?? <p>Unknown tab</p>}
    </AnimatedTabContent>
  );
}

// ── Main component ────────────────────────────────────────────
export function ProgrammeDetail() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState("overview");

  const {
    programmes,
    businessUnits,
    users,
    dateChangeLogs,
    milestones,
    certifications,
    supportRequired,
    capexBudgets,
    programmeOrgNodes,
  } = useAppStore();

  const programme = programmes.find((p) => p.programmeid === id);
  if (!programme) return <Navigate to="/programmes" replace />;

  const programmeId = programme.programmeid;

  const buName =
    businessUnits.find((b) => b.businessunitid === programme.businessid)?.name ?? "—";
  const poc1 = users.find((u) => u.userid === programme.poc1userid)?.name ?? "—";
  const poc2 = users.find((u) => u.userid === programme.poc2userid)?.name ?? "—";

  const recentLogs = dateChangeLogs.filter((l) => {
    if (l.programmeid !== programme.programmeid) return false;
    return new Date(l.changedon) >= new Date(Date.now() - 7 * 86400000);
  });

  const tabsWithChanges = new Set(
    recentLogs.map((l) => MODULE_TAB_MAP[l.module]).filter(Boolean)
  );

  // Build FloatingDock items
  const dockItems = TAB_DEFS.map((tab) => {
    const isActive = activeTab === tab.value;
    const hasChange = tabsWithChanges.has(tab.value);
    const Icon = tab.icon;

    return {
      title: tab.label + (hasChange ? " •" : ""),
      icon: (
        <div className="relative h-full w-full flex items-center justify-center">
          <Icon
            className={`h-[60%] w-[60%] transition-colors ${
              isActive
                ? "text-primary"
                : "text-neutral-500 dark:text-neutral-300"
            }`}
          />
          {hasChange && !isActive && (
            <span className="absolute -top-0.5 -right-0.5 size-1.5 rounded-full bg-amber-500" />
          )}
        </div>
      ),
      onClick: () => setActiveTab(tab.value),
      active: isActive,
    };
  });

  return (
    <div className="flex flex-col gap-0">
      {/* ── Programme Hero Header ───────────────────────────── */}
      <div className="border-b bg-background">
        <div className="px-6 py-3 flex items-center gap-4 flex-wrap">
          {/* Left: Breadcrumb → Title → Badge */}
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <Link to="/programmes" className="text-xs text-muted-foreground hover:text-foreground transition-colors shrink-0">
              Programmes
            </Link>
            <ChevronRight className="size-3 text-muted-foreground shrink-0" />
            <h1 className="text-lg font-bold tracking-tight text-foreground leading-tight truncate">
              {programme.name}
            </h1>
            <Badge
              className="text-[10px] px-2 py-0.5 font-semibold shrink-0"
              style={{ background: "var(--color-primary)", color: "white", opacity: 0.9 }}
            >
              {buName}
            </Badge>
            {programme.notes && (
              <span className="text-xs text-muted-foreground truncate max-w-[260px] hidden lg:inline" title={programme.notes}>
                — {programme.notes}
              </span>
            )}
          </div>

          {/* Right: compact meta strip */}
          <div className="flex items-center gap-3 shrink-0 flex-wrap">
            <div className="flex items-center gap-1 text-[11px] text-muted-foreground border-r pr-3">
              <CalendarDays className="size-3" />
              <span className="font-semibold text-foreground">{programme.lastreportingweek}</span>
            </div>
            <PocChip label="POC 1" name={poc1} />
            {poc2 !== "—" && (
              <>
                <div className="w-px h-6 bg-border" />
                <PocChip label="POC 2" name={poc2} />
              </>
            )}
            <NoiseBackground
              containerClassName="w-fit p-0.5 rounded-full"
              gradientColors={["rgb(117,103,156)", "rgb(8,116,176)", "rgb(189,54,97)"]}
            >
              <button
                onClick={() =>
                  printProgrammeReport({
                    programme,
                    milestones: milestones.filter((m) => m.programmeid === programmeId),
                    certifications: certifications.filter((c) => c.programmeid === programmeId),
                    supportRequired: supportRequired.filter((s) => s.programmeid === programmeId),
                    capexBudgets: capexBudgets.filter((c) => c.programmeid === programmeId),
                    dateChangeLogs: dateChangeLogs.filter((l) => l.programmeid === programmeId),
                    orgNodes: programmeOrgNodes.filter((n) => n.programmeid === programmeId),
                    users,
                    businessUnits,
                  })
                }
                className="h-full w-full cursor-pointer rounded-full bg-linear-to-r from-neutral-100 via-neutral-100 to-white px-3 py-1.5 text-xs font-medium text-black shadow-[0px_2px_0px_0px_var(--color-neutral-50)_inset,0px_0.5px_1px_0px_var(--color-neutral-400)] transition-all duration-100 active:scale-98 dark:from-black dark:via-black dark:to-neutral-900 dark:text-white dark:shadow-[0px_1px_0px_0px_var(--color-neutral-950)_inset,0px_1px_0px_0px_var(--color-neutral-800)]"
              >
                Export →
              </button>
            </NoiseBackground>
          </div>
        </div>
      </div>

      {/* ── Tab Content ───────────────────────────────────────── */}
      <div className="px-6 pt-5 pb-24">
        <TabPanel activeTab={activeTab} programmeId={programmeId} />
      </div>

      {/* ── Floating Dock — fixed at bottom center ────────────── */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50">
        <FloatingDock
          items={dockItems}
          desktopClassName="bg-background/90 backdrop-blur-md border border-border/60 shadow-2xl"
        />
      </div>
    </div>
  );
}
