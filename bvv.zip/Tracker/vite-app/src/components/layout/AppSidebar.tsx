import { useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Layers, Briefcase, LayoutGrid,
  GanttChartSquare, Eye, ChevronRight,
} from "lucide-react";
import { motion, AnimatePresence, useMotionValue, useSpring } from "framer-motion";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const NAV_ITEMS = [
  { title: "Dashboard",      url: "/",              icon: LayoutDashboard },
  { title: "Capabilities",   url: "/capabilities",  icon: Layers },
  { title: "Business Units", url: "/business-units", icon: Briefcase },
  { title: "Programmes",     url: "/programmes",    icon: LayoutGrid },
  { title: "Gantt Chart",    url: "/gantt",         icon: GanttChartSquare },
  { title: "CEO Review",     url: "/ceo-review",    icon: Eye },
];

const MOCK_USER = { name: "Alice Smith", email: "alice@adani.com" };

const hoverBgVariants = {
  rest:    { opacity: 0 },
  hovered: { opacity: 1, transition: { duration: 0.15 } },
};
const iconVariants = {
  rest:    { scale: 1, rotate: 0 },
  hovered: { scale: 1.15, rotate: 5, transition: { type: "spring" as const, stiffness: 420, damping: 18 } },
};
const iconActiveVariants = {
  rest:    { scale: 1 },
  hovered: { scale: 1.08, transition: { type: "spring" as const, stiffness: 420, damping: 18 } },
};

// ── Individual nav item ───────────────────────────────────────────
function NavItem({
  item, isActive, isCollapsed, itemRef,
}: {
  item: (typeof NAV_ITEMS)[0];
  isActive: boolean;
  isCollapsed: boolean;
  itemRef: (el: HTMLDivElement | null) => void;
}) {
  return (
    <div ref={itemRef} className="relative px-2">
      <motion.div initial="rest" whileHover="hovered" animate="rest">
        <Link
          to={item.url}
          title={isCollapsed ? item.title : undefined}
          className={`relative flex items-center gap-3 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring/50 ${
            isCollapsed ? "justify-center px-0 py-3" : "px-3 py-2.5"
          }`}
        >
          {/* Active background */}
          {isActive && (
            <motion.div
              layoutId="sidebar-active-bg"
              className="absolute inset-0 rounded-xl"
              style={{
                background:
                  "linear-gradient(135deg, rgba(117,103,156,0.18) 0%, rgba(8,116,176,0.14) 100%)",
              }}
              transition={{ type: "spring" as const, stiffness: 450, damping: 38 }}
            />
          )}

          {/* Per-item hover background */}
          {!isActive && (
            <motion.div
              variants={hoverBgVariants}
              className="absolute inset-0 rounded-xl bg-sidebar-foreground/[0.06]"
            />
          )}

          {/* Icon */}
          <motion.div
            variants={isActive ? iconActiveVariants : iconVariants}
            className="relative z-10 shrink-0"
          >
            <item.icon
              className={`size-[18px] transition-colors duration-200 ${
                isActive
                  ? "text-sidebar-primary dark:text-violet-300"
                  : "text-sidebar-foreground/50"
              }`}
            />
          </motion.div>

          {/* Label — simple CSS transition instead of AnimatePresence to avoid jitter */}
          <span
            className={`relative z-10 text-sm truncate transition-all duration-200 overflow-hidden whitespace-nowrap ${
              isActive
                ? "font-semibold text-sidebar-foreground"
                : "font-medium text-sidebar-foreground/65"
            } ${isCollapsed ? "w-0 opacity-0" : "w-auto opacity-100"}`}
          >
            {item.title}
          </span>

          {/* Trailing chevron */}
          {isActive && !isCollapsed && (
            <div className="relative z-10 ml-auto transition-opacity duration-200">
              <ChevronRight className="size-3 text-sidebar-foreground/35" />
            </div>
          )}
        </Link>
      </motion.div>
    </div>
  );
}

// ── Main sidebar ──────────────────────────────────────────────────
export function AppSidebar() {
  const location = useLocation();
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";

  const initials = MOCK_USER.name.split(" ").map((n) => n[0]).join("").toUpperCase();

  // ── Single accent bar tracking via DOM measurement ──
  const navContainerRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);
  const barY = useMotionValue(-100);
  const barH = useMotionValue(22);
  const springY = useSpring(barY, { stiffness: 380, damping: 38 });

  const activeIndex = NAV_ITEMS.findIndex((item) =>
    item.url === "/"
      ? location.pathname === "/"
      : location.pathname === item.url || location.pathname.startsWith(item.url + "/")
  );

  // Re-measure bar position whenever activeIndex or collapsed state changes
  useEffect(() => {
    const measure = () => {
      if (isCollapsed || activeIndex < 0) return;
      const container = navContainerRef.current;
      const itemEl = itemRefs.current[activeIndex];
      if (!container || !itemEl) return;

      const containerRect = container.getBoundingClientRect();
      const itemRect = itemEl.getBoundingClientRect();
      const BAR_H = 22;
      const y = itemRect.top - containerRect.top + (itemRect.height - BAR_H) / 2;
      barY.set(y);
      barH.set(BAR_H);
    };

    // Measure immediately and again after sidebar transition finishes
    measure();
    const timer = setTimeout(measure, 220);
    return () => clearTimeout(timer);
  }, [activeIndex, location.pathname, isCollapsed, barY, barH]);

  return (
    <Sidebar variant="sidebar" collapsible="icon">

      {/* ── Header ── */}
      <SidebarHeader className="pb-0 pt-4 px-3">
        <SidebarMenu>
          <SidebarMenuItem>
            <div className={`flex items-center py-1.5 transition-all duration-200 ${isCollapsed ? "justify-center px-0" : "gap-2.5 px-2"}`}>
              <img
                src="https://www.adanidefence.com/-/media/Project/Defence/images/mainlogo.png"
                alt="Adani Defence"
                className={`h-7 w-auto object-contain dark:brightness-0 dark:invert transition-all duration-200 ${isCollapsed ? "max-w-[28px]" : ""}`}
              />
            </div>
          </SidebarMenuItem>
        </SidebarMenu>
        <div
          className="mt-3 mx-2 h-px"
          style={{
            background:
              "linear-gradient(90deg, transparent, color-mix(in oklch, var(--sidebar-primary) 40%, transparent), transparent)",
          }}
        />
      </SidebarHeader>

      {/* ── Nav (no "Navigation" label) ── */}
      <SidebarContent className="pt-3">
        <div ref={navContainerRef} className="relative">
          {/* Single accent bar */}
          {!isCollapsed && activeIndex >= 0 && (
            <motion.span
              className="pointer-events-none absolute left-2 w-[3px] rounded-full bg-sidebar-primary z-20"
              style={{ top: springY, height: barH }}
            />
          )}

          <div className="space-y-0.5">
            {NAV_ITEMS.map((item, i) => {
              const isActive = activeIndex === i;
              return (
                <NavItem
                  key={item.title}
                  item={item}
                  isActive={isActive}
                  isCollapsed={isCollapsed}
                  itemRef={(el) => { itemRefs.current[i] = el; }}
                />
              );
            })}
          </div>
        </div>
      </SidebarContent>

      {/* ── Footer ── */}
      <SidebarFooter className="pb-4 pt-2">
        <div
          className="mx-3 mb-3 h-px"
          style={{
            background:
              "linear-gradient(90deg, transparent, color-mix(in oklch, var(--sidebar-foreground) 15%, transparent), transparent)",
          }}
        />
        <div className="px-3">
          <motion.div initial="rest" whileHover="hovered" animate="rest">
            <motion.div
              variants={{
                rest:    { scale: 1 },
                hovered: { scale: 1.015, transition: { type: "spring" as const, stiffness: 400, damping: 22 } },
              }}
              className={`relative flex items-center gap-3 rounded-xl px-2.5 py-2 cursor-pointer ${
                isCollapsed ? "justify-center px-0" : ""
              }`}
            >
              <motion.div
                variants={hoverBgVariants}
                className="absolute inset-0 rounded-xl bg-sidebar-foreground/[0.05] pointer-events-none"
              />
              {/* Avatar with gradient ring */}
              <div className="relative shrink-0 size-8">
                <div
                  className="absolute inset-0 rounded-full"
                  style={{ padding: "1.5px", background: "linear-gradient(135deg, var(--sidebar-primary), #60a5fa)" }}
                >
                  <div className="w-full h-full rounded-full bg-sidebar" />
                </div>
                <div
                  className="relative size-8 rounded-full flex items-center justify-center z-10"
                  style={{ background: "linear-gradient(135deg, color-mix(in oklch, var(--sidebar-primary) 60%, transparent), rgba(8,116,176,0.4))" }}
                >
                  <span className="text-xs font-bold text-sidebar-primary-foreground">{initials}</span>
                </div>
              </div>

              {/* Name / email — CSS transition instead of AnimatePresence */}
              <div
                className={`min-w-0 flex-1 transition-all duration-200 overflow-hidden ${
                  isCollapsed ? "w-0 opacity-0" : "w-auto opacity-100"
                }`}
              >
                <p className="text-sm font-semibold text-sidebar-foreground/90 truncate leading-snug">
                  {MOCK_USER.name}
                </p>
                <p className="text-[10px] text-sidebar-foreground/45 truncate">
                  {MOCK_USER.email}
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
