import React, { useState, useCallback, useRef } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { SidebarProvider, useSidebar } from "@/components/ui/sidebar";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppSidebar } from "./AppSidebar";
import { motion, AnimatePresence } from "framer-motion";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { HugeiconsIcon } from "@hugeicons/react";
import { SidebarLeftIcon } from "@hugeicons/core-free-icons";

/**
 * Sidebar behaviour:
 *   Click hamburger → persistent open  (pinned = true,  sidebar stays open)
 *   Click again     → close            (pinned = false, sidebar collapses)
 *   When closed     → hover to expand temporarily, leave to collapse
 */
function SidebarWithHover() {
  const location = useLocation();
  const { open, setOpen, isMobile } = useSidebar();

  // "pinned" = user explicitly opened via button → stays open until clicked again
  const [pinned, setPinned] = useState(true);
  const hoverTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Hover handlers (only active when NOT pinned) ──
  const handleMouseEnter = useCallback(() => {
    if (pinned || isMobile) return;
    if (hoverTimer.current) { clearTimeout(hoverTimer.current); hoverTimer.current = null; }
    setOpen(true);
  }, [pinned, isMobile, setOpen]);

  const handleMouseLeave = useCallback(() => {
    if (pinned || isMobile) return;
    hoverTimer.current = setTimeout(() => setOpen(false), 250);
  }, [pinned, isMobile, setOpen]);

  // ── Single button handler ──
  const handleToggle = useCallback(() => {
    if (pinned) {
      // Was pinned-open → close and unpin
      setPinned(false);
      setOpen(false);
    } else {
      // Was unpinned (hover mode) → pin open
      setPinned(true);
      if (hoverTimer.current) { clearTimeout(hoverTimer.current); hoverTimer.current = null; }
      setOpen(true);
    }
  }, [pinned, setOpen]);

  return (
    <>
      {/* Hover zone wraps the sidebar */}
      <div
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className="shrink-0"
      >
        <AppSidebar />
      </div>

      <div className="flex min-h-screen flex-col w-full bg-background transition-all">
        <header className="sticky top-0 z-10 flex h-12 items-center gap-3 border-b bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60 w-full">
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={handleToggle}
            title={pinned ? "Close sidebar" : "Pin sidebar open"}
          >
            <HugeiconsIcon icon={SidebarLeftIcon} strokeWidth={2} />
            <span className="sr-only">Toggle Sidebar</span>
          </Button>

          <div className="flex flex-1 items-center gap-4">
            <h1 className="text-sm font-semibold sm:text-base text-foreground tracking-tight">Programme Tracker</h1>
          </div>
        </header>

        <main className="flex-1 overflow-x-hidden p-6 w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="h-full max-w-[1400px] mx-auto w-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </>
  );
}

export function AppLayout() {
  return (
    <TooltipProvider>
      <SidebarProvider>
        <SidebarWithHover />
        <Toaster position="bottom-right" richColors theme="light" />
      </SidebarProvider>
    </TooltipProvider>
  );
}
