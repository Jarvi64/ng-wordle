import { useState } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useAppStore } from "@/lib/store";
import {
  BarChart3,
  CalendarDays,
  ChevronRight,
  DollarSign,
  Flag,
  GitFork,
  History,
  LayoutGrid,
  Package,
  RefreshCw,
  ShieldCheck,
  Users,
  Zap,
} from "lucide-react";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { NoiseBackground } from "@/components/ui/noise-background";

import { WeeklyUpdatesTab } from "./programme/WeeklyUpdatesTab";
import { OrganisationTab } from "./programme/OrganisationTab";
import { MilestonesTab } from "./programme/MilestonesTab";
import { SupportRequiredTab } from "./programme/SupportRequiredTab";
import { DateChangeLogsTab } from "./programme/DateChangeLogsTab";
import { PartnerDeliverablesTab } from "./programme/PartnerDeliverablesTab";
import { BudgetTab } from "./programme/BudgetTab";
import { CertificationsTab } from "./programme/CertificationsTab";
import { SupplyChainReadinessTab } from "./programme/SupplyChainReadinessTab";
import { ProgrammeDashboardTab } from "./programme/ProgrammeDashboardTab";
import { printProgrammeReport } from "@/lib/printReport";

// ── Avatar chip ──────────────────────────────────────────────
function PocChip({ label, name }: { label: string; name: string }) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
  return (
    <div className="flex items-center gap-2">
      <div className="size-7 rounded-full bg-primary/15 text-primary flex items-center justify-center text-[11px] font-bold shrink-0 ring-1 ring-primary/25">
        {initials}
      </div>
      <div className="leading-tight">
        <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">{label}</p>
        <p className="text-sm font-semibold text-foreground">{name}</p>
      </div>
    </div>
  );
}

// ── Stat pill ────────────────────────────────────────────────
function StatPill({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: number | string;
  color: string;
}) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/50 border">
      <Icon className="size-3.5 shrink-0" style={{ color }} />
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-xs font-bold ml-auto">{value}</span>
    </div>
  );
}

// Map date-change module names → tab values
const MODULE_TAB_MAP: Record<string, string> = {
  milestone:           "milestones",
  support_required:    "support",
  partner_deliverable: "partner",
  capex:               "budget",
  opex:                "budget",
  certification:       "certifications",
  supply_chain:        "supplychain",
};


function ChangeDot() {
  return (
    <span className="absolute -top-0.5 -right-0.5 flex size-2">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
      <span className="relative inline-flex rounded-full size-2 bg-amber-500" />
    </span>
  );
}

function AnimatedTabContent({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15, scale: 0.985 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 350, damping: 30 }}
    >
      {children}
    </motion.div>
  );
}

export function ProgrammeDetail() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState("overview");

  const {
    programmes,
    businessUnits,
    users,
    dateChangeLogs,
    milestones,
    certifications,
    supportRequired,
    capexBudgets,
    programmeOrgNodes,
  } = useAppStore();

  const programme = programmes.find((p) => p.programmeid === id);
  if (!programme) return <Navigate to="/programmes" replace />;

  const programmeId = programme.programmeid;

  const buName =
    businessUnits.find((b) => b.businessunitid === programme.businessid)?.name ?? "—";
  const poc1 = users.find((u) => u.userid === programme.poc1userid)?.name ?? "—";
  const poc2 = users.find((u) => u.userid === programme.poc2userid)?.name ?? "—";

  const recentLogs = dateChangeLogs.filter((l) => {
    if (l.programmeid !== programme.programmeid) return false;
    return new Date(l.changedon) >= new Date(Date.now() - 7 * 86400000);
  });

  // Which tabs have recent date changes (last 7 days)
  const tabsWithChanges = new Set(
    recentLogs.map((l) => MODULE_TAB_MAP[l.module]).filter(Boolean)
  );

  // Quick stats for the header strip
  const msCount = milestones.filter((m) => m.programmeid === programmeId).length;
  const msAtRisk = milestones.filter(
    (m) => m.programmeid === programmeId && (m.status === "At Risk" || m.status === "Delayed")
  ).length;
  const certCount = certifications.filter((c) => c.programmeid === programmeId).length;
  const supportOpen = supportRequired.filter(
    (s) => s.programmeid === programmeId && s.status !== "Closed" && s.status !== "Resolved"
  ).length;

  const TABS = [
    { value: "overview", label: "Overview", icon: LayoutGrid },
    { value: "weekly", label: "Weekly Updates", icon: RefreshCw },
    { value: "organisation", label: "Org Chart", icon: GitFork },
    { value: "milestones", label: "Milestones", icon: Flag, hasChanges: tabsWithChanges.has("milestones") },
    { value: "partner", label: "Partner & ToT", icon: Users, hasChanges: tabsWithChanges.has("partner") },
    { value: "budget", label: "Budget", icon: DollarSign, hasChanges: tabsWithChanges.has("budget") },
    { value: "certifications", label: "Certifications", icon: ShieldCheck, hasChanges: tabsWithChanges.has("certifications") },
    { value: "supplychain", label: "Supply Chain", icon: Package, hasChanges: tabsWithChanges.has("supplychain") },
    { value: "support", label: "Support", icon: Zap, hasChanges: tabsWithChanges.has("support") },
    { value: "datechangelogs", label: "Date Logs", icon: History, badge: recentLogs.length > 0 ? recentLogs.length : undefined },
  ];

  return (
    <div className="flex flex-col gap-0">
      {/* ── Programme Hero Header ───────────────────────────── */}
      <div className="border-b bg-background">

        {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground px-6 pt-4 pb-0">
          <Link to="/programmes" className="hover:text-foreground transition-colors">
            Programmes
          </Link>
          <ChevronRight className="size-3" />
          <span className="text-foreground font-medium">{programme.name}</span>
        </div>

        {/* Main header content */}
        <div className="px-6 pt-3 pb-4">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">

            {/* Left: Title + meta */}
            <div className="min-w-0">
              <div className="flex items-center gap-3 flex-wrap mb-2">
                <h1 className="text-2xl font-bold tracking-tight text-foreground leading-tight truncate">
                  {programme.name}
                </h1>
                <Badge
                  className="text-[10px] px-2 py-0.5 font-semibold shrink-0"
                  style={{
                    background: "var(--color-primary)",
                    color: "white",
                    opacity: 0.9,
                  }}
                >
                  {buName}
                </Badge>
              </div>

              {programme.notes && (
                <p className="text-sm text-muted-foreground max-w-xl leading-relaxed mb-3">
                  {programme.notes}
                </p>
              )}

              {/* Reporting week chip */}
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <CalendarDays className="size-3.5" />
                <span>Last reporting week:</span>
                <span className="font-semibold text-foreground">{programme.lastreportingweek}</span>
              </div>
            </div>

            {/* Right: POC cards + stats */}
            <div className="flex flex-col gap-3 shrink-0 lg:items-end">

              {/* POC row */}
              <div className="flex items-center gap-4 flex-wrap">
                <PocChip label="POC 1" name={poc1} />
                <div className="w-px h-8 bg-border hidden sm:block" />
                <PocChip label="POC 2" name={poc2} />
              </div>

              {/* Quick stats strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 lg:grid-cols-4">
                <StatPill icon={Flag} label="Milestones" value={msCount} color="#0874B0" />
                <StatPill
                  icon={BarChart3}
                  label="At Risk"
                  value={msAtRisk}
                  color={msAtRisk > 0 ? "#BD3661" : "#10b981"}
                />
                <StatPill icon={ShieldCheck} label="Certs" value={certCount} color="#75679C" />
                <StatPill
                  icon={LayoutGrid}
                  label="Support"
                  value={supportOpen}
                  color={supportOpen > 0 ? "#f59e0b" : "#10b981"}
                />
              </div>

              {/* Publish / Export button */}
              <NoiseBackground
                containerClassName="w-fit p-1 rounded-full"
                gradientColors={[
                  "rgb(117, 103, 156)",
                  "rgb(8, 116, 176)",
                  "rgb(189, 54, 97)",
                ]}
              >
                <button
                  onClick={() =>
                    printProgrammeReport({
                      programme,
                      milestones: milestones.filter((m) => m.programmeid === programmeId),
                      certifications: certifications.filter((c) => c.programmeid === programmeId),
                      supportRequired: supportRequired.filter((s) => s.programmeid === programmeId),
                      capexBudgets: capexBudgets.filter((c) => c.programmeid === programmeId),
                      dateChangeLogs: dateChangeLogs.filter((l) => l.programmeid === programmeId),
                      orgNodes: programmeOrgNodes.filter((n) => n.programmeid === programmeId),
                      users,
                      businessUnits,
                    })
                  }
                  className="h-full w-full cursor-pointer rounded-full bg-linear-to-r from-neutral-100 via-neutral-100 to-white px-4 py-2 text-sm font-medium text-black shadow-[0px_2px_0px_0px_var(--color-neutral-50)_inset,0px_0.5px_1px_0px_var(--color-neutral-400)] transition-all duration-100 active:scale-98 dark:from-black dark:via-black dark:to-neutral-900 dark:text-white dark:shadow-[0px_1px_0px_0px_var(--color-neutral-950)_inset,0px_1px_0px_0px_var(--color-neutral-800)]"
                >
                  Export Report →
                </button>
              </NoiseBackground>
            </div>
          </div>
        </div>

        {/* ── Tab Bar ── */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-4 py-2 border-b bg-muted/30">
            <TabsList className="h-auto p-1 bg-muted rounded-xl gap-0.5 flex-nowrap overflow-x-auto w-full justify-start [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              {TABS.map((tab) => {
                const isActive = activeTab === tab.value;
                return (
                  <TabsTrigger
                    key={tab.value}
                    value={tab.value}
                    className="relative flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors shrink-0 text-muted-foreground hover:text-foreground z-0 data-[state=active]:text-foreground"
                    style={{ boxShadow: "none", backgroundColor: "transparent" }}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="programme-tab-active-bg"
                        className="absolute inset-0 rounded-lg bg-background shadow-sm border border-border/50"
                        transition={{ type: "spring", stiffness: 450, damping: 35 }}
                        style={{ zIndex: -1 }}
                      />
                    )}
                    <motion.div
                      initial={false}
                      animate={{ scale: isActive ? 1.03 : 1 }}
                      className="flex items-center gap-1.5 relative z-10"
                    >
                      <tab.icon className={`size-3.5 transition-colors ${isActive ? "text-primary" : ""}`} />
                      {tab.label}
                    </motion.div>
                    {tab.hasChanges && (
                      <span className="relative z-10 -ml-0.5">
                        <ChangeDot />
                      </span>
                    )}
                    {tab.badge !== undefined && (
                      <span className="relative z-10 ml-0.5 inline-flex items-center justify-center size-4 rounded-full bg-destructive text-[9px] font-bold text-white leading-none">
                        {tab.badge}
                      </span>
                    )}
                  </TabsTrigger>
                );
              })}
            </TabsList>
          </div>

          <div className="px-6 pt-6 pb-8">
            <TabsContent value="overview" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><ProgrammeDashboardTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="weekly" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><WeeklyUpdatesTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="organisation" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><OrganisationTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="milestones" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><MilestonesTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="partner" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><PartnerDeliverablesTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="budget" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><BudgetTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="certifications" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><CertificationsTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="supplychain" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><SupplyChainReadinessTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="support" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><SupportRequiredTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
            <TabsContent value="datechangelogs" className="m-0 focus-visible:outline-none">
              <AnimatedTabContent><DateChangeLogsTab programmeId={programmeId} /></AnimatedTabContent>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}
